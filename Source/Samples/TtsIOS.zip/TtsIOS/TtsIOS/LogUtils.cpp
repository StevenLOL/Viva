//
//  LogUtils.cpp
//  TtsIOS
//
//  Created by Lion User on 28/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>
#include "LogUtils.h"

static const int kMaxLogLen = 16*1024;



/****************************************************
 * ios
 ***************************************************/
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)

#include <stdarg.h>
#include <stdio.h>

void Log(const char * pszFormat, ...)
{
    printf("TtsMpbile: ");
    char szBuf[kMaxLogLen];
    
    va_list ap;
    va_start(ap, pszFormat);
    vsprintf(szBuf, pszFormat, ap);
    va_end(ap);
    printf("%s", szBuf);
    printf("\n");
}

#endif  // CC_PLATFORM_IOS

/****************************************************
 * android
 ***************************************************/
#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)

#include <android/log.h>
#include <stdio.h>
#include <jni.h>

void Log(const char * pszFormat, ...)
{
	char buf[MAX_LEN];
    
	va_list args;
	va_start(args, pszFormat);    	
	vsprintf(buf, pszFormat, args);
	va_end(args);
    
	__android_log_print(ANDROID_LOG_DEBUG, "TttMobile debug info",  buf);
}


#endif // CC_PLATFORM_ANDROID