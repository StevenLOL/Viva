//
//  ttsIOS.h
//  TtsIOS
//
//  Created by Lion User on 28/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef TtsIOS_ttsIOS_h
#define TtsIOS_ttsIOS_h
class TtsIOS {
public:
    TtsIOS();
    static void Start();
    const char* getStr(){
        const char* ret = "aaa";
        return ret;
    };
    
};


#endif
