#include "TtsMobile.h"
#include "stdstring.h"
#include "MyConstants.h"
#include "TextHandle.h"
#include "Psola.h"
#include "LogUtils.h"

//#include "SimpleAudioEngine.h"
//using namespace cocos2d;

bool TtsMobile::dbValid = false;
CStdStringA TtsMobile::wavFile = "";

TtsMobile::TtsMobile()
{
	
	
	/*
	CTextHandle::CS_DBFileName = CStdStringA("/sdcard/tts/HalfSyl.dat");
	wavFile = CCFileUtils::getWriteablePath().append("result.wav");
	CTextHandle::CsDirectoryOfFile = "/sdcard/tts/";
	CTextHandle::CsNameOfSynFile = CCFileUtils::getWriteablePath().append("AnalysedPhrase.syn");
	
	CTextHandle::CsNameOfWavFile	= wavFile;
	CTextHandle::CsNameOfDebugFile	= wavFile + ".bug.log";
	CTextHandle::nF0_Begin			= 210;
	CTextHandle::fSpeakingRate = 1;

	CPsola::CsNameOfWavFile		= wavFile;
	CPsola::CsNameOfDebugFile	= wavFile + ".bug.log";
	CPsola::nF0_Begin			= 210;
	CPsola::fSpeakingRate = 1;
	*/
	
	
}
bool TtsMobile::Start(const char* input)
{

	bool mRet = false;
	//CCLog("Native Input:%s",input);
	if (!dbValid) 
	{
		/*Skip Reopen DB file*/
		dbValid = CPsola::DB_Open(CTextHandle::CS_DBFileName);
	}
	
	if (dbValid)
	{
		
		CStdStringA userinput = CStdStringA(input);
        userinput = userinput + ".";
		if (CPsola::TDPR_PlayText(userinput)) 
		{
			mRet = true;
		}
	
     
	}
	return mRet;
}
void TtsMobile::setResourcePath(const char* path)
{	
    Log("Set resouce path to:%s",path);
	CStdStringA mPath 				= CStdStringA(path) + "/";
	CTextHandle::CsDirectoryOfFile 	= mPath;
	CTextHandle::CS_DBFileName		= mPath+ "HalfSyl.mp3";

	CTextHandle::CsNameOfSynFile 	= mPath + "AnalysedPhrase.syn";
	CTextHandle::CsNameOfDebugFile 	= mPath + "log.txt";
	CPsola::CsNameOfDebugFile 		= mPath + "log.txt";
}
void TtsMobile::setWavPath(const char *path)
{
    CTextHandle::CsNameOfWavFile	= CStdStringA(path);
	CPsola::CsNameOfWavFile			= CStdStringA(path);
}

void TtsMobile::setParams(float f0_begin,float speakRate )
{
	CTextHandle::nF0_Begin 			= f0_begin;
	CPsola::nF0_Begin				= f0_begin;
	CTextHandle::fSpeakingRate 		= speakRate;
	CPsola::fSpeakingRate 			= speakRate;
	
	
}
void TtsMobile::setF0(float f0_begin)
{
    CTextHandle::nF0_Begin 			= f0_begin;
	CPsola::nF0_Begin				= f0_begin;
}
void TtsMobile::setSpeakingRate(float speakRate)
{
   	CTextHandle::fSpeakingRate 		= speakRate;
	CPsola::fSpeakingRate 			= speakRate; 
}