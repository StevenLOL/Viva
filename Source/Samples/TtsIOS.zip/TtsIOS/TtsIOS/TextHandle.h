// TextHandle.h: interface for the CTextHandle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXTHANDLE_H__8F3E95C0_3043_4186_A5B0_55396968604E__INCLUDED_)
#define AFX_TEXTHANDLE_H__8F3E95C0_3043_4186_A5B0_55396968604E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "MyConstants.h"
#include <vector>
using namespace std;

class CTextHandle  
{
	friend class CPsola;
public:
	/*
	CArray<UNITINFOFULL,UNITINFOFULL> DicSyllableArray;
	CArray<PHONESTRUCTINFO,PHONESTRUCTINFO> PhoneArray;
	CArray<PHONESTRUCTINFO,PHONESTRUCTINFO> InPhoneArray, MiPhoneArray,VoArray, FiPhoneArray;
	*/
	vector<UNITINFOFULL> DicSyllableArray;
	vector<PHONESTRUCTINFO> PhoneArray;
	vector<PHONESTRUCTINFO> InPhoneArray,MiPhoneArray,VoArray,FiPhoneArray;
	void UpdateSylInfo(int index, SYLLABLESTRUCT Syllable);
	static CStdStringA GetLastError(int *nErrorCode = NULL);
	static CStdStringA CsDirectoryOfFile;
	static CStdStringA CS_DBFileName;
	static CStdStringA CsNameOfWavFile,CsNameOfDebugFile;
    static CStdStringA CsNameOfSynFile;
	static int nF0_Begin;
	static float fSpeakingRate;
	BOOL ParseText(CStdStringA &cs);
	CTextHandle();
	virtual ~CTextHandle();
	static int nTypeOfPhrase;
	static BYTE bSettingUnitType;
	static BOOL BSettingInputText;
protected:
	BYTE EnergyModel(UNITINFOFULL Unit);
	BOOL ParseSylInfo(UNITINFOFULL &Syllable,SYLLABLESTRUCT *stSyl);
	BOOL ToneInPhrase(vector< float> &F0Array, BYTE ToneType, float fNorF0, int nSylLen);
	void F0ContourGeneration(vector<UNITINFOFULL> &SyllableArray);//(CArray<UNITINFOFULL, UNITINFOFULL> &SyllableArray);
	BOOL DurationModel(UNITINFOFULL Unit, float &Length, int &node);
	void LoadVowelAndTone();
	BOOL LoadPhoneme();
	void SyllableStructureAnalyse(UNITINFOFULL &SylOUT);
	BOOL LoadDictionary();
	BOOL SyllableAnalysis(UNITINFOFULL &DicSyllable);
	//BOOL SyllableAnalysis(CString &csSyllable, UNITINFOFULL &DicSyllable);
	BOOL SyllableAnalysis(CStdStringA &csSyllable, UNITINFOFULL &DicSyllable);
	BOOL IsNumeric(LPCTSTR lpBuf,WORD nLen);
	static CStdStringA m_csError;
	BOOL ParseSylInfo(CStdStringA &cs,SYLLABLESTRUCT *stSyl);
	int GetSylCount();
	BOOL GetSylInfo(WORD wIndex,SYLLABLESTRUCT &stSyl);
	void Empty();
	void RemoveAt(int i);
	static int m_nErrorCode;
	
	//CDWordArray m_pdwSyl;
	vector<DWORD> m_pdwSyl;
	//CStringArray VowelArray;
	//CStringArray VowelNoToneArray;
	vector<CStdStringA> VowelArray,VowelNoToneArray;
	
	//CByteArray ToneArray;
	vector<BYTE> ToneArray;
	float fRegister;
	

};

#endif // !defined(AFX_TEXTHANDLE_H__8F3E95C0_3043_4186_A5B0_55396968604E__INCLUDED_)
