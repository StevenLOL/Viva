#ifndef __MYCONSTANT__H__
#define __MYCONSTANT__H__ 
//#include "afxtempl.h"
//#include "cocos2d.h"
#include "stdstring.h"
#include "LogUtils.h"

#define PI 3.1415926535
#define BITSPERSAMPLE	16
#define BYTESPERSAMPLE  2
#define SAMPLERATE		UINT(16000)
 
////////////////////////////////////////
//////////////////For the Database
/////////////////////////////////////////
#define DATABASENAME "DSN=MYDATASOURCE"
#define DB_HEADERSIZE 50000// Size of the Header of Database file, for 35000 acoustic Units
#define DB_FILENAME	"Vn.mgr" // Default file name
#define DB_BYTESPERTAG 8
/////////	Structure of the file Db.mgr
/////////	2 Byte: Indicate the number of Acoustic unit contained in the Database
/////////	11998 byte next are for tags:
/////////	Each Tag contains 8 bytes : 
///////////////////////////		4 byte Name of Acoustic Unit, 
///////////////////////////		4 byte Position of Acoustic Unit in the Database file
///////////////////////////	Structure of the Data of One Acoustic Unit:
///////////////////////////		1 byte : BOOL, if = 1 -> Unit was delleted
///////////////////////////		2 byte : Position of transition point of the Unit
///////////////////////////		4 byte : Pointer to the location where contains the position of the Pitch marks
///////////////////////////		1 byte tiep de danh
///////////////////////////Luu y : Diphone luu trong co so du lieu phai co it nhat 5 dinh cuc dai

////////////////////////////////////////
//////////////////For CWaveFile Class
////////////////////////////////////////
#define WF_ERROR					0
#define WF_NOERROR					1	
#define WF_CANTOPEN					2
#define WF_TOOSHORT					3
#define WF_NOTPCMFILE				4
#define WF_INFONOTMATCH				5
#define WF_NOWAVEFILEATTACHED		6
#define WF_ERRORINSEPARATING		7
#define	WF_NODATASEPARATED			8
#define WF_NOTSUPPORTED				9
#define	WF_NODATAINDATACHUNK		10
#define	WF_CANNOTOPENOUTPUTDEVICE	11
#define	WF_CANNOTPREPAREHDR			12
#define	WF_CANNOTWRITEOUTPUTDEVICE	13
#define WF_ANOTHERISPLAYING			14
#define WF_BITSPERSAMPLENOTMATCH	15
#define	WF_NUMBERCHANNELSNOTMATCH	16	
#define WF_SAMPLERATENOTMATCH		17


///////////////////////////////////////
/////////////// For CSignalView Class
///////////////////////////////////////
#define LEFT_OFFSET		0
#define RIGHT_OFFSET	0
#define TOP_OFFSET		0
#define BOTTOM_OFFSET	0
#define IDC_STATIC_VIEW 11101
#define IDC_STATIC_SEL	11102
#define IDC_EDIT_VIEW   11103
#define IDC_EDIT_SEL	11104

///////////// These are messages using for transmit parameters for CSignalView class
//////////////Luu y : Phai dung ham SendMessage(WM_SHOWSIGNAL,...) khong duoc dung PostMessage

#define WM_SHOWSIGNAL			1111
#define WM_CHANGECHANNEL		1112
#define WM_PLAYSOUND			1113
#define WM_EXPORT_BITMAP		1114

#define COEF_SCALE		2//2
#define	COEF_XALIGN		1 //7/8
#define COEF_YALIGN		3/4
#define BUTTON_WIDTH	20

#define SCRB_FIRSTPOSITION		0

#define IDC_BTZOOMINTOCENTER	2222
#define IDC_BTZOOMOUT			2223
#define IDC_BTZOOMOUTFULL		2224

#define IDC_BTZOOMINVERTICAL	2225
#define IDC_BTZOOMOUTVERTICAL	2226

///////////////////////////////////////////
/////////////////////Danh cho lop CPsola
///////////////////////////////////////////
#define PSL_ACCENTGRAVE			1
#define PSL_ACCENTAIGU			2

#define PSL_TO_STEP				4/5
#define PSL_TO_EXTENT			(1-(double)PSL_TO_STEP)*2
#define PSL_MINFRAMENUMBER		5
#define PSL_SAFEBUFFER			20000//600
#define PSL_ENERGY_LEVELS		32

#define PSL_ERROR					0
#define PSL_NOERROR					1
#define PSL_NOTSUPPORTED			2
#define PSL_NOTFOUND_F0				3
#define PSL_PARAMNOTMATCH			4
#define PSL_NOTENOUGHAFRAME			5
#define PSL_NULLPOINTER				6
#define PSL_BUFFEROVERFLOW			7
#define PSL_SIGNALTOOSHORT			8
#define	PSL_TH_ERROR				9
#define PSL_DB_ERROR				10
#define PSL_WF_ERROR				11
#define PSL_PITCHNOTPAIRE			12
#define PSL_PERCENTOVERFLOW			13

#define DB_NOERROR					100
#define DB_CANNOTOPENDBFILE			101
#define DB_NULLPOINTER				102
#define DB_DBNOTOPENED				103
#define DB_UNITNOTFOUND			104
#define DB_INDEXOVERFLOW			105
#define DB_UNITEXISTED			106
#define DB_BUFFEROVERFLOW			107
#define DB_CANNOTCLEANUP			108
#define DB_CANNOTRELOAD				109

/////////////////////////////////////////////////////////////////////////
//			Bo xung ngay 21 thang 10								   //
//			Noi dung : Them hai flag de kiem tra kieu KET NOI		   //
/////////////////////////////////////////////////////////////////////////

#define CONNECT_WITH_F0_1			1
#define CONNECT_WITH_F0_2			2
#define CONNECT_WITHOUT_F0_1		4
#define CONNECT_WITHOUT_F0_2		8
typedef unsigned long       DWORD;

typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef char* LPSTR;
typedef const char* LPCSTR;
typedef long LONG;
typedef unsigned int UINT;
typedef LPCSTR LPCTSTR;
#ifndef bool
typedef int                 BOOL;
#define FALSE   0
#define TRUE    1
#endif
//#define NULL    0

// Structure of a Unit used to get/put the information of one Unit from/to the Database file
typedef struct TAGUNITINFO
{
	char	cUnitName[5];		// Name of Acoustic Unit
	WORD	wIndex;				// Index of Unit from 0 
	LPSTR	lpBuffer;			// Buffer contains Signal data of the Unit
	DWORD	dwDipLen;			// Length of the Unit in Byte
	int		nTranPoint;			// Position of transition point between voiced and unvoiced regions
	DWORD	*lpPitchMarks;
	int		nNumberPitchMarks;
	BYTE	UnitType;			// Type of Unit used for concatenation
								// Syllabe, Phone, AUnit,demi-syllable...
								// hoac kieu ket noi, 1 hoac 2
	// Bo xung cac thong tin cho viec xay dung CSDL moi ngay 01 thang 12 nam 2005
	BYTE	bTone;				// Context of the Unit including: 
	BYTE	bLeftTone;			//	1. Tone of Unit, Left Tone, Righ tone
	BYTE	bRightTone;			//  2. Name of Left/rigth Units
	char	cLeftUnitName[5];	
	char	cRightUnitName[5];
	WORD	wLeftIndex;			// Lay chi so cua don vi am da ket noi ben trai
	WORD	wRightIndex;		// Lay chi so cua don vi am se ket noi ben phai
	DWORD	dwLowFEnergy;
	DWORD	dwHighFEnergy;		//
	BYTE	bSameUnitIndex;		//
	// Ket thuc bo xung
	
	BOOL	bDeleted;
	WORD	wFlag;
} UNITINFO;

// Structure of a Unit used to get the context information of one Unit 
typedef struct TAGDIPSUPINFOS
{
	BYTE	bDeleted;
	WORD	wTranPoint;			//Diem phan biet 2 vung voiced va unvoiced
	DWORD	dwDipLen;			//Do dai AUnit tinh theo byte
	
	//01 thang 12 nam 2005
	BYTE	UnitType;
	BYTE	bTone;
	BYTE	bLeftTone;
	BYTE	bRightTone;
	char	cLeftUnitName[5];
	char	cRightUnitName[5];
	DWORD	dwLowFEnergy;
	DWORD	dwHighFEnergy;
	// Ket thuc bo xung
} DIPSUPINFOS;
///////////////////////////////////////////////////////////////////////////////////////
///			Bo xung ngay 15 thang 02 nam 2005										///
///			Noi dung: Cau truc nay dung de lay khoang cach cua cac Don vi am ket noi //
///////////////////////////////////////////////////////////////////////////////////////
// Structure of a Unit used to calculate the distance between the Unit and other adjacent units
typedef struct TAGDIPDISTANCEINFO
{
	char	cUnitName[5];		//Ten AUnit
	WORD	wIndex;				//chi so AUnit tinh tu 0
	BYTE	bSameUnitIndex;
	float	fDistArray[100];		//So don vi am toi uu
	float	fShortestPath;
	WORD	*wCurrentPath;
	WORD	wPathSize;
	float	fTargetCost;
	//CWordArray CurrentPath;
	/*TAGDIPDISTANCEINFO & operator = ( TAGDIPDISTANCEINFO & x )
	{
		memcpy(this->cUnitName,x.cUnitName,5);
		this->wIndex = x.wIndex;
		this->bSameUnitIndex = x.bSameUnitIndex;
		this->fShortestPath = x.fShortestPath;
		memcpy(this->fDistArray,x.fDistArray,20*sizeof(float));
		//this->CurrentPath.RemoveAll();
		this->CurrentPath.Copy(x.CurrentPath);
		return *this;
	}
	TAGDIPDISTANCEINFO(const TAGDIPDISTANCEINFO &s){
	}*/
	
} DIPDISINFO;
///////////////////////////////////////////////////////////////////////////////////////

#define DB_DIPNAME			1	//Flag for indicating: UnitName is being used 
#define DB_DIPINDEX			2	//Flag for indicating: Unit index is being used
#define DB_DIPBUFFER		4	//Flag for indicating: Unit buffer is being used to contain the signal data of the Unit, size of the buffer = dwlen;
#define DB_DIPLEN			8	//Flag for indicating: Unit length is returned
#define DB_DIPTRANPOINT		16	//Flag for indicating: Unit transition point is returned is being usedNeu co nay duoc dat se tra ve middle sample
#define DB_DIPMARKS			32
#define DB_DIPNUMBERMARKS	64
#define DB_DIPDELETED		128
#define DB_DIPALL			255
// Bo xung cho cac bien moi them vao
#define DB_CONTEXT			256
/*#define	DB_DIPTONE			256
#define	DB_DIPLEFTTONE		512
#define	DB_DIPRIGHTTONE		1024
#define	DB_DIPLEFTNAME		2048
#define	DB_DIPRIGHTNAME		4096
#define	DB_DIPLOWFENERGY	8192
#define	DB_DIPHIGHFENERGY	16384*/
// Bo xung ngay 13 thang 02 nam 2005
#define DB_LEFTCONTEXT		512	// Neu co nay duoc thiet lap thi Don vi am tim kiem co the lay duoc Context (ngu canh) ben trai
#define DB_RIGHCONTEXT		1024// Neu co nay duoc thiet lap thi Don vi am tim kiem co the lay duoc Context (ngu canh) ben phai

typedef struct TAGFRAMESTRUCT
{ 
	LPCSTR	lpFrame;			////Pointer point to the buffer which contains two periods of the Unit signal.
	LONG	lFrameLen;			////Length of the Two periods.
	LPSTR	lpBuffer;			////Pointer point to the new buffer which will contain data of new vowel
	LONG	lBufferMax;			////Maximum length of the new vowel
} FRAMESTRUCT;

typedef struct TAGPHONESTRUCT
{
	LPCSTR	lpPhone;			//Pointer point to the data region of Syllable
	LONG	lPhoneLen;			//Length of Data region
	LONG	lHandlePoint;		//Point, from that the data is processed
	LONG	lHandleLen;			//Length of region processed
	LPSTR	lpBuffer;			//Pointer point to a new buffer which contains the data of new syllable 
	LONG	lBufferMax;			//Maximum length of the new buffer
	LONG	lNewHandleLen;		//Lenght of new signal after controling F0 from HandleLen region
	int		nOldTo;				//F0 average of the region being processed
	float	fTransitionPoint;	// Bo xung ngay 11-9-2005 Luu giu vi tri (tinh theo %) cua diem chuyen giao (giua PAD va Van)
} PHONESTRUCT;

typedef struct TAGFRAMEPOSSTRUCT
{
	int nStartPoint;			//Start point of new Frames
	int nSignalLen;				//Length of buffer used for new Frames
	int *nPos;					//Array stores position of the frames
	int nCount;					//Maximum length of the Array
	int nNumberPos;				//Number of frames 
	int nAddition;
public:
	int nTransPoint;
} FRAMEPOSSTRUCT;

// Not use
typedef struct TAGCONNECTUNITSSTRUCT
{
	LPSTR	lpStartAUnit;     //Diphone ben trai
	int		nStartLen;			//Do dai diphone ben trai
	LPSTR	lpFinalAUnit;		//Diphone ben phai
	int		nFinalLen;			//Do dai diphone ben phai
	LPSTR	lpNewPhone;			//Buffer chua syllable moi
	int		nCount;				//Do dai buffer
	int		nTo;
} CONNECTUNITSSTRUCT;
// end of Not use

///////////////////////////////////////////
// Cau truc duoc sua doi                 //
// Ngay sua: 15/10/2004                  //
// Nguoi sua: Tran Do Dat				 //
// Noi dung sua: them cac Diphone vao    //
// Ngay sua: 27/10/2004					 //
// Noi dung: them bien so luong unit	 //
// Ngay sua: 31/08/2005					 //
// Noi dung: them bien nTon				 //
///////////////////////////////////////////
typedef struct TAGSYLLABLESTRUCT
{
	char	cFirstAUnit[5];	// Name of the first Unit acoustic 
	char	cSecondAUnit[5];	// Name of the second Unit 
	char	cThirdAUnit[5];	// Name of the third Unit 
	char	cFourthAUnit[5];	// Name of the fourth Unit
	int		nAUnit;			// Number of Units are concatenate for create one Syllable
	BYTE	bUnitIndex[4];		// Used to take the index of the Units concatenated 
	char	*lpNewSyllable;		// Buffer contain the data of new syllable
	int		nSyllableLen;		// Length of the Buffer
	int		*nFo;				// Pointer points to F0 array.
	int		nNumberFo;			// Number of F0 value in the array
	int		nEnergy;			// Level of Energy from 6 to 32 
	int		nTon;				// Code of 6 tones, from 1-8 ; 31/08/2005
//	int		nNumOfUnitPerSyl;	//So Unit tren de tao thanh syllable
	WORD	wFlag;
} SYLLABLESTRUCT;

///////////////////////////////////////////
// Cau truc duoc sua doi                 //
// Ngay sua: 15/10/2004                  //
// Nguoi sua: Tran Do Dat				 //
// Noi dung sua: them hai co Diphone 3,4 //
// Ngay sua: 27/10/2004                  //
// Noi dung sua: Them so unit cua Sylable //
///////////////////////////////////////////

//These marcro are used for the difinition of Flags, which are used in GetSylInfo function 
#define SYL_FIRSTUNIT	1
#define SYL_SECONDUNIT	2
#define SYL_THIRDUNIT	32
#define SYL_FOURTHUNIT	64
#define SYL_NUMBERFO		4
#define	SYL_FOARRAY			8
#define SYL_SYLLABLELEN		16
#define SYL_NUMOFUNIT		128 
#define SYL_ENERGY			256//test
#define SYL_TON				512

// Structure for wav file;
typedef struct TAGAPPENDWAVESTRUCT
{
	LPSTR	lpszFileName;		//Ten file
	LPSTR	lpSignal;			//Buffer chua tin hieu can them
	DWORD	dwLen;				//Do dai Buffer
	WORD	wBitsPerSample;		
	UINT	uSampleRate;
	WORD	wNumberChannels;
} APPENDWAVESTRUCT;

#define LPCREATETHREADSTRUCT CREATETHREADSTRUCT*

typedef struct  
{
	UINT	magic;  
	UINT	hdr_size; 
	UINT	data_size;//Chua kich thuoc vung du lieu (BYTE)
	UINT	encoding;  
	UINT	sample_rate;
	UINT	channels;  
	BYTE	*lpData;
	CStdStringA csFileName;
}AUDIOHEADER;
#define LPAUDIOHEADER AUDIOHEADER*

//////////////////////////////////
///////InputView Class
///////////////////////////////
#define IDC_EDIT_UNITS	1000
#define TH_CAPTIONWIDTH		100
///////////////////////////////
///////////////////////////////
///////////////////////////////
#define TH_NOERROR				0
#define TH_INDEXOVERFLOW		2
#define	TH_UNITNOTFOUND		3
#define	TH_UNITNOTPAIR		4
#define	TH_LENNOTNUMERIC		5
#define TH_FONOTNUMERIC			6
#define TH_SILENCELENNOTNUMERIC	7

///////////////////////////////////
///	For CPitchView Class
///////////////////////////////////
#define PV_SHOWPITCH			WM_USER+1111
///////////////////////////////////
///////////////////////////////////

//////////////////////////////////////////////////////////////////////
////////////This part is reserved for CBitmapEx class
//////////////////////////////////////////////////////////////////////

typedef struct TAGBMPHDR {
	WORD	Identifier;
	DWORD	FileSize;	
	DWORD	Reserved;	
	DWORD	BmpDataOffset;
	DWORD	BmpHdrSize;	
	DWORD	Width;			
	DWORD	Height;
	WORD	Planes;
	WORD	BitsPerPixel;
	DWORD	Compression;
	DWORD	BmpDataSize;
	DWORD	HResolution;
	DWORD	VResolution;
	DWORD	Colors;
	DWORD	ImportantColors;
	CStdStringA	csFilePath;
} BMPHDR;
////////////////////////////////////////////////////////////////////////
//	 This part is used for TextHandle Class 
//	 Adding : 19/12/2006
////////////////////////////////////////////////////////////////////////
//////////////////For the Database
/////////////////////////////////////////
// Structure of a Unit used to get/put the information of one Unit from/to the Database file


typedef struct TAGUNITINFOFULL 
{
	//char	cUnitName[20];		// Name of Acoustic Unit
	CStdStringA	cUnitName;		// Name of Acoustic Unit
	WORD	wIndex;				// Index of Unit from 0 
	int		nPhraseLen;
	LPSTR	lpBuffer;			// Buffer contains Signal data of the Unit
	DWORD	dwUnitLen;			// Length of the Unit in Byte
	BYTE	bTone;				// Context of the Unit including: 
	BYTE	bLeftTone;			//	1. Tone of Unit, Left Tone, Righ tone
	BYTE	bRightTone;			//  2. Name of Left/rigth Units
	CStdStringA	cLeftUnitName;	
	CStdStringA	cRightUnitName;

	char	cCarryingFile[40];
	double	dwEnergy;
	BYTE	bSameUnitIndex;		//
	int		*nF0;
	float	*fF0;
	BYTE	numOfF0;
	float	tgAnfa1;
	float	tgAnfa2;
	int		nRegister;		// Register of syllable
	float	fRelvReg;		// Relative register;
	
	float	PosInPhrase;
	float	PosInWord;
	float	PosInSyntagm;
	BOOL	Stress;
	BYTE	TypeOfPhrase;

	CStdStringA	csLeftPhone;
	CStdStringA csRightPhone;
	CStdStringA	csLeftPhoneType;
	CStdStringA csRightPhoneType;

	CStdStringA	csSound[4];		// Containing name of phonemes in a syllable
	CStdStringA csSoundType[4]; // Type of phoneme in the syllable
	BYTE	bNumOfSound;

	BYTE	bUnitType;//0 - 3 : Syllable, Demisyllable, Diphone, Phone, 
	CStdStringA	csSubUnit[4];
	BYTE	bNumOfSubUnit;
	
	// Ket thuc bo xung
	WORD	wFlag;
} UNITINFOFULL;

typedef struct TAG_PHONESTRUCTINFO
{
	CStdStringA	csPhoneId;		// Name of Acoustic Unit
	CStdStringA	csPhoneType;	// type of AU
	CStdStringA	csCharId;		// Character of AU
//	BYTE	ToneId;
	
	
} PHONESTRUCTINFO;

//////////////////For the List of Phoneme
////////////////////////////////////////
#define NUMOFINITIALCONSONANTS		22
#define NUMOFSEMIVOWELS				1
#define NUMOFVOWELS					16
#define NUMOFFINALSOUNDS			8
////////////////////////////////////////

////////////////////////////////////////////////////////////////////////


#endif