// MyDatabase.h: interface for the CMyDatabase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYDATABASE_H__63B190D5_F684_4455_8C8C_745E6D27F652__INCLUDED_)
#define AFX_MYDATABASE_H__63B190D5_F684_4455_8C8C_745E6D27F652__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <vector>
#include "MyConstants.h"
//#include "afxtempl.h"
//#include <afxcoll.h>
using namespace std;

class CMyDatabase  
{
	friend class CPsola;
public:
	void EmptyBestUnitArray();
	BYTE GetPosBestUnit(WORD index);
	DIPDISINFO GetBestUnit(WORD index);
	void ListSelUnit();
	BOOL SpectralDistance(UNITINFO Unit1, UNITINFO Unit2, float &fDistance);

	void GetUnitContext(SYLLABLESTRUCT CurrentSyl, SYLLABLESTRUCT LeftSyl, SYLLABLESTRUCT RightSyl, UNITINFO &Unit, BYTE BTypeOfPos, BYTE bPosInSyl);
	int FindNext(LPCTSTR lpszAUnitName, int nIndex);
	BOOL GetAUnitInfo(UNITINFO &info);
	static CStdStringA GetLastError(int *nErrorCode = NULL);
	CMyDatabase();
	virtual ~CMyDatabase();
	char * m_cHeader;
	//static void Close();
	//static BOOL Reload(); // bo xung static ngay 25 thang 11
		
protected:
	float ToneDistance(BYTE Tone1, BYTE Tone2);
	BOOL UpdateUnitInfo(UNITINFO UnitContext,WORD wIndex);
	DIPDISINFO Best_Units_Path;
	void ComputeShortestPathArray();
	BOOL DistanceMatrix();
	float ContextDistance(DIPDISINFO Unit1, DIPDISINFO Unit2);
	
	//CArray<DIPDISINFO,DIPDISINFO&> DIP_Best_Unit_Array; // Bo xung ngay 15 thang 02 nam 2005
	vector<DIPDISINFO> DIP_Best_Unit_Array;													// Luu tru cac don vi am duoc lua chon
	//CByteArray Num_Best_Unit_Array;						// Luu tru so luong cac don vi am cua cung 1 loai am
	vector<BYTE> Num_Best_Unit_Array;
	UNITINFO PreUnit;
	BOOL BestUnitSelection(UNITINFO &UnitContext);
	int Find(LPCTSTR lpszAUnitName);
	BOOL ReadSupInfo();
	static CStdStringA m_csError;
	static int m_nErrorCode;
	DWORD GetAUnitLen(WORD wIndex);
	DWORD GetElementLen(WORD wIndex); 
	int FindAll(LPCTSTR lpszAUnitName);
	DWORD GetAUnitLen(LPCTSTR lpAUnitName,WORD *wIndexAUnit = NULL);
	BOOL Clean();
	BOOL Reload(); // bo xung static ngay 25 thang 11


	BOOL Open(LPCTSTR lpszFileName);
	void Close();
	FILE* m_fAUnits;
	CStdStringA m_csFileName;
	//char * m_cHeader;
	DIPSUPINFOS * m_stSupInfo;
	BOOL m_bOpenedDB;
	BOOL CreateDatabase(LPCTSTR lpszFileName);
	void GetMFCCEnd(WORD wIndex, float* result);
	void GetMFCCBegin(WORD wIndex, float* result);
	float MFCCdistance(float* mfcc1, float* mfcc2);
};

#endif // !defined(AFX_MYDATABASE_H__63B190D5_F684_4455_8C8C_745E6D27F652__INCLUDED_)
