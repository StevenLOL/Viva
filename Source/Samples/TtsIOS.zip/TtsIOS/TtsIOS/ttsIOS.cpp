//
//  ttsIOS.cpp
//  TtsIOS
//
//  Created by Lion User on 28/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>
#include "ttsIOS.h"
TtsIOS::TtsIOS()
{
    
}
void TtsIOS::Start()
{
    
}