//
//  ViewController.h
//  TtsIOS
//
//  Created by Lion User on 28/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TtsMobile.h"
#import <AudioToolbox/AudioToolbox.h>
@interface ViewController : UIViewController
@property (retain, nonatomic) IBOutlet UITextField *textFieldData;
@property (retain, nonatomic) IBOutlet UITextField *textFieldF0;
@property (retain, nonatomic) IBOutlet UITextField *textFieldSpR;
@property (retain, nonatomic) IBOutlet UIButton *btnStart;
@property (retain, nonatomic) IBOutlet UISlider *slider;
@property (retain, nonatomic) IBOutlet UISlider *f0Slide;
@property (retain, nonatomic) IBOutlet UIStepper *steper;
- (IBAction)btnStartPerform:(id)sender;
- (IBAction)f0submit:(id)sender;
- (IBAction)sprSubmit:(id)sender;

- (IBAction)btnStartdown:(id)sender;
- (IBAction)onSlide:(id)sender;
- (IBAction)onF0Change:(id)sender;

- (void) removeData;

@end

