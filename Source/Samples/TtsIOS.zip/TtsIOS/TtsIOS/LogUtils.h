#if !defined(__TTS_LOG__)
#define __TTS_LOG__
#include "CCPlatformConfig.h"
void Log(const char * pszFormat, ...);
#endif