// MyDatabase.cpp: implementation of the CMyDatabase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MyDatabase.h"
#include "MyConstants.h"
#include "Psola.h"
#include "Math.h"
//#include "LogUtils.h"
//#include "afxtempl.h"

/*

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
*/

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
int			CMyDatabase::m_nErrorCode = DB_NOERROR;
CStdStringA	CMyDatabase::m_csError;

CMyDatabase::CMyDatabase(){
	this->m_bOpenedDB = FALSE;
	this->m_cHeader = new char [DB_HEADERSIZE];
	this->m_stSupInfo = new DIPSUPINFOS [2];
	//this->PreUnit.wIndex = -1; // Bo xung ngay 10 thang 02: luu giu ket qua am duoc chon
	
}

CMyDatabase::~CMyDatabase(){
	delete[] this->m_cHeader;
	delete[] this->m_stSupInfo;
}

BOOL CMyDatabase::CreateDatabase(LPCTSTR lpszFileName){
	FILE* fFile;
    //cocos2d::CCLog("Database path:%s",lpszFileName);
	if((fFile =fopen(lpszFileName,"wb"))==NULL){
		m_nErrorCode = DB_CANNOTOPENDBFILE;
		m_csError.Format("Can not open database file : %s",lpszFileName);
		return FALSE;
	}
	char *cHeader = new char [DB_HEADERSIZE];
	memset(cHeader,0,DB_HEADERSIZE);
	fwrite(cHeader,DB_HEADERSIZE,1,fFile);
	delete[] cHeader;
	fclose(fFile);
	return TRUE;
}

BOOL CMyDatabase::Open(LPCTSTR lpszFileName){
    Log("Open data base file %s",lpszFileName);
	if((m_fAUnits =fopen(lpszFileName,"rb"))==NULL)
    {
		if(!CreateDatabase(lpszFileName))
			return FALSE;
		m_fAUnits = fopen(lpszFileName,"rb");
	}
	m_csFileName.Format(("%s"),lpszFileName);
	this->m_bOpenedDB = TRUE;

	fread(m_cHeader,DB_HEADERSIZE,1,m_fAUnits);
	delete[] this->m_stSupInfo;
	this->m_stSupInfo = new DIPSUPINFOS [*(WORD*)(m_cHeader)];
	this->ReadSupInfo();

	return TRUE;
}

void CMyDatabase::Close(){
	if(this->m_bOpenedDB){
		this->m_bOpenedDB = FALSE;
		fclose(m_fAUnits);
	}
}


BOOL CMyDatabase::Reload(){
	if(!this->m_bOpenedDB) 
	{
		this->m_nErrorCode = DB_CANNOTRELOAD;
		return FALSE;
	}
	fseek(m_fAUnits,0,SEEK_SET);
	fread(m_cHeader,DB_HEADERSIZE,1,m_fAUnits);
	delete[] this->m_stSupInfo;
	this->m_stSupInfo = new DIPSUPINFOS [*(WORD*)(m_cHeader)];
	this->ReadSupInfo();
	return TRUE;
}


int CMyDatabase::FindAll(LPCTSTR lpszAUnitName)
{
	if(!this->m_bOpenedDB){
		m_nErrorCode = DB_DBNOTOPENED;
		return -1;
	}

	if(!lpszAUnitName){ 
		m_nErrorCode = DB_NULLPOINTER;
		return -1;
	}

	ASSERT(strlen(lpszAUnitName) < 5);

	char *lpszDBAUnitName = new char [5];
	lpszDBAUnitName[4] = '\0';
	BOOL	bFound = FALSE;
	int i;
	for(i = 0; i < *(WORD *)(m_cHeader);i++)
	{
		*(DWORD *)(lpszDBAUnitName) = *(DWORD *)(m_cHeader + i * 8 + 2);
		if(strcmp(lpszAUnitName,lpszDBAUnitName)==0){
			bFound = TRUE;
			break;
		}
	}
	delete[] lpszDBAUnitName;
	if(!bFound){
		m_nErrorCode = DB_UNITNOTFOUND;
		m_csError.Format("Acoustic Unit 1 \"%s\" not found",lpszAUnitName);
		return -1;
	}
	return i;
}




CStdStringA CMyDatabase::GetLastError(int *nErrorCode)
{
	if(nErrorCode) *nErrorCode = m_nErrorCode;
	switch(m_nErrorCode)
	{
		case DB_CANNOTOPENDBFILE	:	return m_csError;
		case DB_NULLPOINTER			:	return "Null pointer";
		case DB_DBNOTOPENED			:	return "Database is not opened yet";
		case DB_UNITNOTFOUND		:	return m_csError;
		case DB_INDEXOVERFLOW		:	return "Index overflow";
		case DB_BUFFEROVERFLOW		:	return "Buffer overflow";
		case DB_UNITEXISTED			:	return m_csError;
		case DB_CANNOTCLEANUP		:	return "Can not clean up! Be sure that it isn't being used";
		case DB_CANNOTRELOAD		:	return "Can not reload! Be sure that it isn't being used";
	}
	return "No Error";
}


DWORD CMyDatabase::GetElementLen(WORD wIndex)
{
	DWORD size;
	fseek(m_fAUnits,0,SEEK_END);
	size = ftell(m_fAUnits);
	if(wIndex == *(WORD *)(m_cHeader) - 1)
		return size - (*(DWORD *)(m_cHeader + wIndex * 8 + 4 + 2));
	return  (*(DWORD *)(m_cHeader + (wIndex + 1) * 8 + 4 + 2)) - (*(DWORD *)(m_cHeader + wIndex * 8 + 4 + 2));
}

BOOL CMyDatabase::GetAUnitInfo(UNITINFO &info)
{
	if(!this->m_bOpenedDB){
		m_nErrorCode = DB_DBNOTOPENED;
		return FALSE;
	}

	if(!(info.wFlag & DB_DIPINDEX) && !(info.wFlag & DB_DIPNAME))
	{
		m_nErrorCode = DB_UNITNOTFOUND;
		m_csError.Format("Acoustic Unit not found");
		return FALSE;
	}


	if(info.wFlag & DB_DIPINDEX)
	{
		if(info.wIndex > *(WORD *)(m_cHeader) - 1) {
			m_nErrorCode = DB_INDEXOVERFLOW;
			return FALSE;
		}
		memcpy(info.cUnitName,m_cHeader + info.wIndex * 8 + 2,4);
		info.cUnitName[4] = '\0';
	}
	else
	{// bat dau tim kiem o day
		int nIndex; BYTE nCount = 0;
		if(info.wFlag & DB_DIPDELETED)
			nIndex = FindAll(info.cUnitName);
		else
			nIndex = Find(info.cUnitName);
		if(nIndex == -1) return FALSE;
		else nCount ++;
		for(;;)
		{
			
			if(nCount == info.bSameUnitIndex) break;
			else 
			{
				nIndex = FindNext(info.cUnitName,nIndex);
				if (nIndex == -1) return FALSE;
				else nCount++;
			}
		}
		info.wIndex = (WORD)nIndex;
	}

	DWORD dwElementLen = GetElementLen(info.wIndex);

	char *m_cTemp = new char [dwElementLen];
	fseek(m_fAUnits,*(DWORD *)(m_cHeader + 8 * info.wIndex + 4 + 2),SEEK_SET);
	fread(m_cTemp,dwElementLen,1,m_fAUnits);

	if(info.wFlag & DB_DIPDELETED)
	{
		//info.bDeleted = m_cTemp[0];
		info.bDeleted = this->m_stSupInfo[info.wIndex].bDeleted;
	}

	if(info.wFlag & DB_DIPTRANPOINT)
	{
		//info.nTranPoint = *(WORD *)(m_cTemp+1);
		info.nTranPoint = this->m_stSupInfo[info.wIndex].wTranPoint;
	}

	if((info.wFlag & DB_DIPLEN)||(info.wFlag & DB_DIPBUFFER))
	{
		//info.dwDipLen = *(DWORD *)(m_cTemp + 3) - 8;
		info.dwDipLen = this->m_stSupInfo[info.wIndex].dwDipLen;
	}
	if(info.wFlag & DB_CONTEXT)
	{
		// Bo xung ngay 06 thang 12 nam 2005, lay cac thong tin ve context cua Unit
		info.UnitType	= this->m_stSupInfo[info.wIndex].UnitType;
		info.bTone		= this->m_stSupInfo[info.wIndex].bTone;
		info.bLeftTone	= this->m_stSupInfo[info.wIndex].bLeftTone;
		info.bRightTone	= this->m_stSupInfo[info.wIndex].bRightTone;
		info.dwLowFEnergy	= this->m_stSupInfo[info.wIndex].dwLowFEnergy;
		info.dwHighFEnergy	= this->m_stSupInfo[info.wIndex].dwHighFEnergy;
		memcpy(info.cLeftUnitName, m_stSupInfo[info.wIndex].cLeftUnitName,5);
		memcpy(info.cRightUnitName, m_stSupInfo[info.wIndex].cRightUnitName,5);
		// Ket thuc bo xung
	}

	if(info.wFlag & DB_DIPBUFFER)
	{
		info.lpBuffer = new char [info.dwDipLen];
		//memcpy(info.lpBuffer,m_cTemp + 8,info.dwDipLen);
		memcpy(info.lpBuffer,m_cTemp + 28,info.dwDipLen);
	}

	if((info.wFlag & DB_DIPNUMBERMARKS)||(info.wFlag & DB_DIPMARKS))
	{

		info.nNumberPitchMarks = (dwElementLen - 96 - 20 - (*(DWORD *)(m_cTemp + 3)))/(sizeof(DWORD)); 
	}// so diem Pitch

	if(info.wFlag & DB_DIPMARKS)
	{
		info.lpPitchMarks = new DWORD [info.nNumberPitchMarks];

		memcpy(info.lpPitchMarks,m_cTemp +20+ (*(DWORD *)(m_cTemp + 3)),info.nNumberPitchMarks * sizeof(DWORD));
	}

	delete[] m_cTemp;
	return TRUE;	
}

BOOL CMyDatabase::ReadSupInfo()
{
	if(!this->m_bOpenedDB){
		m_nErrorCode = DB_DBNOTOPENED;
		return FALSE;
	}
	for(int i = 0;i<*(WORD*)(m_cHeader);i++)
	{
		fseek(m_fAUnits,*(DWORD *)(m_cHeader + 8 * i + 4 + 2),SEEK_SET);
		char cTemp[28];//8];
		fread(cTemp,27,1,m_fAUnits);//7);
		m_stSupInfo[i].bDeleted = cTemp[0];
		m_stSupInfo[i].wTranPoint = *(WORD *)(cTemp + 1);
		m_stSupInfo[i].dwDipLen = *(DWORD *)(cTemp + 3)-8;

		// Bo xung ngay 06 thang 12 nam 2005, lay cac thong tin ve context cua Unit
		m_stSupInfo[i].UnitType = *(BYTE *)(cTemp + 7);
		m_stSupInfo[i].bTone	= *(BYTE *)(cTemp + 8);
		m_stSupInfo[i].bLeftTone	= *(BYTE *)(cTemp + 9);
		m_stSupInfo[i].bRightTone	= *(BYTE *)(cTemp + 10);
		m_stSupInfo[i].dwLowFEnergy	= *(DWORD *)(cTemp + 11);
		m_stSupInfo[i].dwHighFEnergy= *(DWORD *)(cTemp + 15);
		memcpy(m_stSupInfo[i].cLeftUnitName,cTemp +19,4);
		m_stSupInfo[i].cLeftUnitName[4] = '\0';
		memcpy(m_stSupInfo[i].cRightUnitName,cTemp +23,4);
		m_stSupInfo[i].cRightUnitName[4] = '\0';

		// Ket thuc bo xung
	}
	return TRUE;
}

int CMyDatabase::Find(LPCTSTR lpszAUnitName)
{
	if(!this->m_bOpenedDB){
		m_nErrorCode = DB_DBNOTOPENED;
		return -1;
	}

	if(!lpszAUnitName){ 
		m_nErrorCode = DB_NULLPOINTER;
		return -1;
	}

	ASSERT(strlen(lpszAUnitName) < 5);

	char *lpszDBAUnitName = new char [5];
	lpszDBAUnitName[4] = '\0';
	BOOL	bFound = FALSE;
	int i;
	for(i = 0; i < *(WORD *)(m_cHeader);i++)
	{
		*(DWORD *)(lpszDBAUnitName) = *(DWORD *)(m_cHeader + i * 8 + 2);
		if((!m_stSupInfo[i].bDeleted)&&(strcmp(lpszAUnitName,lpszDBAUnitName)==0)){
			bFound = TRUE;
			break;
		}
	}
	delete[] lpszDBAUnitName;
	if(!bFound){
		m_nErrorCode = DB_UNITNOTFOUND;
		m_csError.Format("Acoustic Unit 2 \"%s\" not found",lpszAUnitName);
		CPsola::OutputLastError(m_csError);
		return -1;
	}
	return i;
}

int CMyDatabase::FindNext(LPCTSTR lpszAUnitName, int nIndex)
{
	if(!this->m_bOpenedDB){
		m_nErrorCode = DB_DBNOTOPENED;
		return -1;
	}

	if(!lpszAUnitName){ 
		m_nErrorCode = DB_NULLPOINTER;
		return -1;
	}

	ASSERT(strlen(lpszAUnitName) < 5);

	char *lpszDBAUnitName = new char [5];
	lpszDBAUnitName[4] = '\0';
	BOOL	bFound = FALSE;
	int i;
	for(i = nIndex +1; i < *(WORD *)(m_cHeader);i++)
	{
		*(DWORD *)(lpszDBAUnitName) = *(DWORD *)(m_cHeader + i * 8 + 2);
		if((!m_stSupInfo[i].bDeleted)&&(strcmp(lpszAUnitName,lpszDBAUnitName)==0)){
			bFound = TRUE;
			break;
		}
	}
	delete[] lpszDBAUnitName;
	if(!bFound){
		m_nErrorCode = DB_UNITNOTFOUND;
		//m_csError.Format("Acoustic Unit next \"%s\" not found",lpszAUnitName);
		//CPsola::OutputLastError(m_csError);
		return -1;
	}
	return i;

}

void CMyDatabase::GetUnitContext(SYLLABLESTRUCT CurrentSyl, SYLLABLESTRUCT LeftSyl, SYLLABLESTRUCT RightSyl, 
								 UNITINFO &Unit, BYTE BTypeOfPos, BYTE bPosInSyl)
{
	switch (BTypeOfPos)
	{
		case 1: 
				memcpy(Unit.cLeftUnitName,"SIL",3);	
				Unit.cLeftUnitName[3] = '\0';
				if(CurrentSyl.nAUnit > 1)
				{
					memcpy(Unit.cRightUnitName,CurrentSyl.cSecondAUnit,5);
					Unit.bRightTone	= CurrentSyl.nTon;
				}
				else 
				{
					memcpy(Unit.cRightUnitName,RightSyl.cFirstAUnit,5);
					Unit.bRightTone	= RightSyl.nTon;
				}
				Unit.bTone		= CurrentSyl.nTon;
				Unit.bLeftTone	= 0;
				break;

		case 2:	
				if((CurrentSyl.nAUnit ==3)||((CurrentSyl.nAUnit ==4)&&(bPosInSyl = 2)))
				{
					memcpy(Unit.cLeftUnitName,CurrentSyl.cFirstAUnit,5);
					memcpy(Unit.cRightUnitName,CurrentSyl.cSecondAUnit,5);
				}
				if((CurrentSyl.nAUnit ==4)&&(bPosInSyl = 3))
				{
					memcpy(Unit.cLeftUnitName,CurrentSyl.cSecondAUnit,5);
					memcpy(Unit.cRightUnitName,CurrentSyl.cThirdAUnit,5);
				}

				Unit.bTone		= CurrentSyl.nTon;
				Unit.bLeftTone	= CurrentSyl.nTon;
				Unit.bRightTone	= CurrentSyl.nTon;
				break;

		case 3:
				if(CurrentSyl.nAUnit ==2)
					memcpy(Unit.cLeftUnitName,CurrentSyl.cFirstAUnit,5);	
				if(CurrentSyl.nAUnit ==3)
					memcpy(Unit.cLeftUnitName,CurrentSyl.cSecondAUnit,5);
				if(CurrentSyl.nAUnit ==4)
					memcpy(Unit.cLeftUnitName,CurrentSyl.cThirdAUnit,5);
				
				memcpy(Unit.cRightUnitName,RightSyl.cFirstAUnit,5);
				
				Unit.bTone		= CurrentSyl.nTon;
				Unit.bLeftTone	= CurrentSyl.nTon;
				Unit.bRightTone	= RightSyl.nTon;
				break;
		case 4:
				switch (LeftSyl.nAUnit)
				{
				case 1:
					memcpy(Unit.cLeftUnitName,LeftSyl.cFirstAUnit,5);
					break;
				case 2:
					memcpy(Unit.cLeftUnitName,LeftSyl.cSecondAUnit,5);
					break;
				case 3:
					memcpy(Unit.cLeftUnitName,LeftSyl.cThirdAUnit,5);
					break;
				case 4:
					memcpy(Unit.cLeftUnitName,LeftSyl.cFourthAUnit,5);
					break;
				}
				if(CurrentSyl.nAUnit > 1)
				{
					memcpy(Unit.cRightUnitName,CurrentSyl.cSecondAUnit,5);
					Unit.bRightTone	= CurrentSyl.nTon;
				}
				else 
				{
					memcpy(Unit.cRightUnitName,RightSyl.cFirstAUnit,5);
					Unit.bRightTone	= RightSyl.nTon;
				}
				
				Unit.bTone		= CurrentSyl.nTon;
				Unit.bLeftTone	= LeftSyl.nTon;
				break;
		case 5:
				memcpy(Unit.cRightUnitName,"SIL",3);	
				Unit.cRightUnitName[3] = '\0';
				switch (CurrentSyl.nAUnit)
				{
				case 1: 
					switch (LeftSyl.nAUnit)
					{
					case 1:
						memcpy(Unit.cLeftUnitName,LeftSyl.cFirstAUnit,5);
						break;
					case 2:
						memcpy(Unit.cLeftUnitName,LeftSyl.cSecondAUnit,5);
						break;
					case 3:
						memcpy(Unit.cLeftUnitName,LeftSyl.cThirdAUnit,5);
						break;
					case 4:
						memcpy(Unit.cLeftUnitName,LeftSyl.cFourthAUnit,5);
						break;
					}
					break;
				case 2:
					memcpy(Unit.cLeftUnitName,CurrentSyl.cFirstAUnit,5);
					break;
				case 3:
					memcpy(Unit.cLeftUnitName,CurrentSyl.cSecondAUnit,5);
					break;
				case 4:
					memcpy(Unit.cLeftUnitName,CurrentSyl.cThirdAUnit,5);
					break;
				}
				if(CurrentSyl.nAUnit ==1) Unit.bLeftTone	= LeftSyl.nTon;
				else Unit.bLeftTone = CurrentSyl.nTon;
				Unit.bTone		= CurrentSyl.nTon;
				Unit.bRightTone	= 0;
	}

}

BOOL CMyDatabase::BestUnitSelection(UNITINFO &UnitContext)
{
	if(!this->m_bOpenedDB){
		m_nErrorCode = DB_DBNOTOPENED;
		return FALSE;
	}
	int nIndex;
	nIndex = Find(UnitContext.cUnitName);
	if(nIndex == -1) return FALSE;
	UNITINFO Info;
	float fToneDistance;

	Info.wIndex = nIndex;
	Info.wFlag = DB_DIPINDEX|DB_CONTEXT;
	if(!GetAUnitInfo(Info)) return FALSE;
	
	float fNote =0;

	
	Num_Best_Unit_Array.push_back(0);
	if(!strcmp(UnitContext.cLeftUnitName,"SIL")) 
	{
		PreUnit.wFlag = PreUnit.wFlag & 0x1FF;

	}
	if(!strcmp(UnitContext.cLeftUnitName,Info.cLeftUnitName)) fNote =2;
	if(!strcmp(UnitContext.cRightUnitName,Info.cRightUnitName)) fNote = fNote + 2;
	if(UnitContext.bTone == Info.bTone) fNote = fNote + 2;
	else
	{
		fToneDistance = ToneDistance(UnitContext.bTone,Info.bTone);
		if((Info.bTone==6)||(Info.bTone==3)) fToneDistance = fToneDistance/3; 
		fNote = fNote + 2*fToneDistance;
	}
	if(UnitContext.bLeftTone == Info.bLeftTone)  fNote = fNote + 1;
	else
	{
		fToneDistance = ToneDistance(UnitContext.bLeftTone,Info.bLeftTone);
		fNote = fNote + fToneDistance;
	}
	if(UnitContext.bRightTone == Info.bRightTone)  fNote = fNote + 1;
	else
	{
		fToneDistance = ToneDistance(UnitContext.bRightTone,Info.bRightTone);
		fNote = fNote + fToneDistance;
	}
	
	BYTE bSameUnitIndex;
	UnitContext.bSameUnitIndex = 1;
	UnitContext.wIndex = nIndex;
	
	///////////////////////////////////////////
	// Bo xung ngay 15 thang 02 nam 2005	 //
	// Noi dung: Lay danh sach cac Unit co context thoa man yeu cau
	//										 //
	///////////////////////////////////////////
	int nLastUnit, nUnitOrder;

	nLastUnit = Num_Best_Unit_Array.size() - 1;
	nUnitOrder = Num_Best_Unit_Array.at(nLastUnit);
	Num_Best_Unit_Array.at(nLastUnit)= nUnitOrder +1;
	
	DIPDISINFO Dip_Candidate;

	Dip_Candidate.wIndex = UnitContext.wIndex;
	Dip_Candidate.bSameUnitIndex = UnitContext.bSameUnitIndex;
	memcpy(Dip_Candidate.cUnitName, UnitContext.cUnitName,5);
	//
	Dip_Candidate.fTargetCost = fNote;
	//
	DIP_Best_Unit_Array.push_back(Dip_Candidate);
	
	///////////////////////////////////////////
//	fNoteMax = fNote;
	bSameUnitIndex = UnitContext.bSameUnitIndex;
	int nIndexNext;
	nIndexNext = nIndex;
	for(;;)
	{
		nIndexNext = FindNext(UnitContext.cUnitName,nIndexNext);
		if(nIndexNext == -1) 
		{
			break;
		}
		else 
		{
			bSameUnitIndex ++;
			Info.wIndex = nIndexNext;
			Info.wFlag = DB_DIPINDEX|DB_CONTEXT;
			if(!GetAUnitInfo(Info)) return FALSE;

			fNote =0;
			if(!strcmp(UnitContext.cLeftUnitName,Info.cLeftUnitName)) fNote =2;
			if(!strcmp(UnitContext.cRightUnitName,Info.cRightUnitName)) fNote = fNote + 2;
			if(UnitContext.bTone == Info.bTone) fNote = fNote + 2;
			else
			{
				fToneDistance = ToneDistance(UnitContext.bTone,Info.bTone);
				if((Info.bTone==6)||(Info.bTone==3)) fToneDistance = fToneDistance/3; 
				fNote = fNote + 2*fToneDistance;
			}
			
			if(UnitContext.bLeftTone == Info.bLeftTone)  fNote = fNote + 1;
			else
			{
				fToneDistance = ToneDistance(UnitContext.bLeftTone,Info.bLeftTone);
				fNote = fNote + fToneDistance;
			}
			if(UnitContext.bRightTone == Info.bRightTone)  fNote = fNote + 1;
			else
			{
				fToneDistance = ToneDistance(UnitContext.bRightTone,Info.bRightTone);
				fNote = fNote + fToneDistance;
			}


			///////////////////////////////////////////
			// Bo xung ngay 15 thang 02 nam 2005	 //
			// Noi dung: Lay danh sach cac Unit co context thoa man yeu cau
			//										 //
			///////////////////////////////////////////
			//	int nLastUnit, nUnitOrder;
			nLastUnit = Num_Best_Unit_Array.size() - 1;
			nUnitOrder = Num_Best_Unit_Array.at(nLastUnit);
			Num_Best_Unit_Array.at(nLastUnit)=nUnitOrder +1;
			
			Dip_Candidate.wIndex = Info.wIndex;
			Dip_Candidate.bSameUnitIndex = bSameUnitIndex;
			memcpy(Dip_Candidate.cUnitName, Info.cUnitName,5);
			//
			Dip_Candidate.fTargetCost = fNote;
			//
			DIP_Best_Unit_Array.push_back(Dip_Candidate);
		}
	}

	PreUnit.wFlag = DB_LEFTCONTEXT;
	PreUnit.wIndex = UnitContext.wIndex; // Bo xung ngay 10 thang 02: luu giu ket qua am duoc chon
	memcpy(PreUnit.cUnitName, UnitContext.cUnitName,5); // Bo xung ngay 10 thang 02: luu giu ket qua am duoc chon
	////////////////////////////////////
	/*FILE *fileopen;
	if( (fileopen = fopen( "outText.txt", "a+t" )) == NULL )
	AfxMessageBox( "The file 'crt_fopen.c' was not opened\n" );
	else
	{
		fwrite(UnitContext.cUnitName,5,1,fileopen);
		char cIndex[5];
		itoa(UnitContext.bSameUnitIndex,cIndex,10);
		fwrite(cIndex,strlen(cIndex),1,fileopen);
		fwrite("\n",strlen("\n"),1,fileopen);
	}
	fclose(fileopen);*/

	return TRUE;

}

////////////////////////////////////////////////////////////////////////////////////////
// This function will connect 2 database files.
////////////////////////////////////////////////////////////////////////////////////////



BOOL CMyDatabase::SpectralDistance(UNITINFO Unit1, UNITINFO Unit2, float &fDistance)
{
	
	 float* mfccEnd1;
     float* mfccBegin2;
     mfccEnd1 = (float*)malloc(12*sizeof(float));
	 mfccBegin2 = (float*)malloc(12*sizeof(float));
	 // Lay ra cac he so MFCC 
     GetMFCCEnd(Unit1.wIndex, mfccEnd1);
	 GetMFCCBegin(Unit2.wIndex, mfccBegin2);  
	 // Tinh toan khoang cach pho
     fDistance = MFCCdistance(mfccEnd1,mfccBegin2);     
     fDistance = 10 - 5*(fDistance);     
     free(mfccEnd1);
	 free(mfccBegin2);
     
     return TRUE; 

}
///////////////////////////////////////////////////////////////////////////////////////

void CMyDatabase::ListSelUnit()
{
	int i, nCounter = 0;
	//FILE *fileopen;

	//if( (fileopen = fopen( "SelectedCandidat.path.txt", "a+t" )) == NULL )
	//{
	//	AfxMessageBox( "The file 'SelectedCandidat.path.txt' was not opened\n" );
	//	return;
	//}
	DistanceMatrix();
	ComputeShortestPathArray();
	
	for(i=0; i<Num_Best_Unit_Array.size();i++)
	{
		int nSize;
		nSize = Num_Best_Unit_Array.at(i);
		for(int j=0; j<nSize; j++)
		{
			DIPDISINFO OutUnit;
			OutUnit = DIP_Best_Unit_Array.at(nCounter++);

			/*char cbuff[20];
			sprintf(cbuff,"%5s %3d %3d ", OutUnit.cUnitName, OutUnit.bSameUnitIndex,OutUnit.wIndex);
			fwrite(cbuff,strlen(cbuff),1,fileopen);

			sprintf(cbuff," Shortest Path:");
			fwrite(cbuff,strlen(cbuff),1,fileopen);

			for(int k=0;k<OutUnit.wPathSize;k++)
			{
				sprintf(cbuff,"%3d ",OutUnit.wCurrentPath[k] );
				fwrite(cbuff,strlen(cbuff),1,fileopen);

			}

			sprintf(cbuff," Path score: %0.2f \n",OutUnit.fShortestPath);
			fwrite(cbuff,strlen(cbuff),1,fileopen);*/
			//////////
		}
		//fwrite("\n",strlen("\n"),1,fileopen);
	}

	/*char cbuff[20];
	//sprintf(cbuff," Shortest Path:");
	//fwrite(cbuff,strlen(cbuff),1,fileopen);
	for(int k=0;k<Best_Units_Path.wPathSize;k++)
		{
			sprintf(cbuff,"%3d ",Best_Units_Path.wCurrentPath[k] );
			fwrite(cbuff,strlen(cbuff),1,fileopen);
		}
	sprintf(cbuff," Path score: %0.2f \n",Best_Units_Path.fShortestPath);
	fwrite(cbuff,strlen(cbuff),1,fileopen);

	sprintf(cbuff,"DIP_Arr %d Cont %d \n",DIP_Best_Unit_Array.size(),nCounter);
	fwrite(cbuff,strlen(cbuff),1,fileopen);

	fclose(fileopen);*/
	return;

}

//////////////////////////////////////////////////////////////////////////////////
// This function calculates the distance of context of two acoustic units which were 
// selected for synthesizing
///////////////////////////////////////////////////////////////////////////////////
float CMyDatabase::ContextDistance(DIPDISINFO Unit1, DIPDISINFO Unit2)
{
	UNITINFO Info1, Info2;

	if((!strcmp(Unit1.cUnitName,"SIL"))&&(!Unit1.wIndex))
	{
		strcpy(Info1.cUnitName,Unit1.cUnitName);
		strcpy(Info1.cLeftUnitName,"SIL");
		strcpy(Info2.cRightUnitName, "SIL"); //02/06/2006
		Info1.bRightTone = 0;
		Info1.bTone = 0;
		Info1.bLeftTone =0;
	}

	else
	{
		Info1.wIndex = Unit1.wIndex;
		Info1.wFlag = DB_DIPINDEX|DB_CONTEXT;
		GetAUnitInfo(Info1);
	}

	
	/////////////////////////////////////////////////////////////////////////////////////////////////
	// Adding 02/06/2006
	// Adding the context distance of the last Unit in the phrase
	/////////////////////////////////////////////////////////////////////////////////////////////////
	
	if((!strcmp(Unit2.cUnitName,"SIL"))&&(!Unit2.wIndex))
	{
		strcpy(Info2.cUnitName,Unit2.cUnitName);
		strcpy(Info2.cLeftUnitName,"SIL");
		strcpy(Info2.cRightUnitName, "SIL");
		Info2.bRightTone = 0;
		Info2.bTone = 0;
		Info2.bLeftTone =0;
	}
	// End of Adding
	else
	{
		Info2.wIndex = Unit2.wIndex;
		Info2.wFlag = DB_DIPINDEX|DB_CONTEXT;
		GetAUnitInfo(Info2);
	}
	float fNote =0;
	float fToneDistance =0;
	

	if(!strcmp(Info1.cRightUnitName,Info2.cUnitName)) fNote = 2;
	if(!strcmp(Info1.cUnitName,Info2.cLeftUnitName)) fNote = fNote + 2;
	if(Info1.bRightTone == Info2.bTone) fNote = fNote + 2;
	else
	{
		fToneDistance = ToneDistance(Info1.bRightTone ,Info2.bTone);
		fNote = fNote + 2*fToneDistance;
	}
	if(Info1.bTone == Info2.bLeftTone)  fNote = fNote + 2;
	else
	{
		fToneDistance = ToneDistance(Info1.bTone ,Info2.bLeftTone);
		fNote = fNote + 2*fToneDistance;
	}

	return fNote;
}
//////////////////////////////////////////////////////////////////////////////////
// This function calculates the context distances of all member of two adjacent 
// unit layers which were selected for synthesizing
///////////////////////////////////////////////////////////////////////////////////

BOOL CMyDatabase::DistanceMatrix()
{
	int i,q, nCounter = 0;
	int nPositionLayer1, nPositionLayer2;
	DIPDISINFO UnitLayer2;
	for(i=0; i<Num_Best_Unit_Array.size();i++)
	{
		q = Num_Best_Unit_Array.size();
		int nSize;
		nSize = Num_Best_Unit_Array.at(i);
		nPositionLayer1 = nCounter;
		for(int j=0; j<nSize; j++)
		{
			DIPDISINFO UnitLayer1;
			UnitLayer1 = DIP_Best_Unit_Array.at(nCounter);
			
			if(i==0)
			{

				strcpy(UnitLayer2.cUnitName,"SIL");
				UnitLayer2.wIndex =0;

				DIP_Best_Unit_Array.at(nCounter).fDistArray[0] = 
										ContextDistance(UnitLayer2,UnitLayer1)/2 + 
										DIP_Best_Unit_Array.at(nCounter).fTargetCost/2;

			}
			else
			{
				int nSizeOfPre;
				nSizeOfPre = Num_Best_Unit_Array.at(i-1);
				nPositionLayer2 = nPositionLayer1 - nSizeOfPre;
				for(int k=0; k<nSizeOfPre;k++)
				{
					//DIPDISINFO UnitLayer2;
					UnitLayer2 = DIP_Best_Unit_Array.at(nPositionLayer2 + k);
					//UnitLayer1.fDistArray[j] = ContextDistance(UnitLayer1,UnitLayer2);
					UNITINFO temp1, temp2;
					memcpy(temp1.cUnitName,UnitLayer1.cUnitName,5);
					temp1.wIndex = UnitLayer1.wIndex;
					temp1.bSameUnitIndex = UnitLayer1.bSameUnitIndex;

					memcpy(temp2.cUnitName,UnitLayer2.cUnitName,5);
					temp2.wIndex = UnitLayer2.wIndex;
					temp2.bSameUnitIndex = UnitLayer2.bSameUnitIndex;

					float fSpectralDis;

					if(!SpectralDistance(temp2,temp1,fSpectralDis)) return FALSE;
					

					DIP_Best_Unit_Array.at(nCounter).fDistArray[k] = ContextDistance(UnitLayer2,UnitLayer1)/2
																			+ 2.0*fSpectralDis + DIP_Best_Unit_Array.at(nCounter).fTargetCost/2;//(6 - 3*fSpectralDis);
					/////////////////////////////////////////////////////////////////////////////////////////////////
					// Adding 02/06/2006
					// Adding the context distance of the last Unit in the phrase
					/////////////////////////////////////////////////////////////////////////////////////////////////
					if(i== (Num_Best_Unit_Array.size()-1))
					{
						strcpy(UnitLayer2.cUnitName,"SIL");
						UnitLayer2.wIndex =0;
						DIP_Best_Unit_Array.at(nCounter).fDistArray[k] += ContextDistance(UnitLayer1,UnitLayer2)/2;
					}

					// End of Adding
				}
			}
			nCounter++;
		}
	}
	return TRUE;
}

void CMyDatabase::ComputeShortestPathArray()
{
	int i, nColSize, nRowSize;
	float min = 0;
	float fMax =0;
	int nPositionLayer1, nPositionLayer2;
	WORD wMaxPos=0;

	nRowSize = Num_Best_Unit_Array.size();
	int nCounter = 0;

	for(i = 0; i< nRowSize; i++)
	{
		nColSize = Num_Best_Unit_Array.at(i);
		nPositionLayer1 = nCounter;
		float fShortestPath = 0;
		for(int j=0; j<nColSize; j++)
		{
			int nSizeOfPre;

			
			if(i==0)
			{
				DIP_Best_Unit_Array.at(nCounter).fShortestPath = DIP_Best_Unit_Array.at(nCounter).fDistArray[0];
				DIP_Best_Unit_Array.at(nCounter).wCurrentPath = new WORD[i+1];
				DIP_Best_Unit_Array.at(nCounter).wPathSize = i+1;//nRowSize;
				DIP_Best_Unit_Array.at(nCounter).wCurrentPath[i] = nCounter;
			}
			else
			{
				nSizeOfPre = Num_Best_Unit_Array.at(i-1);
				nPositionLayer2 = nPositionLayer1 - nSizeOfPre;	
				fMax = 0; wMaxPos=0;
				
				DIP_Best_Unit_Array.at(nCounter).wCurrentPath = new WORD[i+1];
				DIP_Best_Unit_Array.at(nCounter).wPathSize = i+1;//nRowSize;
				for(int k=0; k<nSizeOfPre; k++)
				{
					fShortestPath = DIP_Best_Unit_Array.at(nCounter).fDistArray[k] +
										DIP_Best_Unit_Array.at(nPositionLayer2 + k).fShortestPath;
					if (fShortestPath > fMax)
					{
						fMax = fShortestPath;
						wMaxPos = k;
					}
				}
				DIP_Best_Unit_Array.at(nCounter).fShortestPath = fMax;
				memcpy(DIP_Best_Unit_Array.at(nCounter).wCurrentPath,DIP_Best_Unit_Array.at(nPositionLayer2 + wMaxPos).wCurrentPath, (i-1)*sizeof(WORD));
				
			
				DIP_Best_Unit_Array.at(nCounter).wCurrentPath[i-1] = DIP_Best_Unit_Array.at(nPositionLayer2 + wMaxPos).bSameUnitIndex;//nPositionLayer2 + wMaxPos;
				DIP_Best_Unit_Array.at(nCounter).wCurrentPath[i] = DIP_Best_Unit_Array.at(nCounter).bSameUnitIndex;//nCounter - nPositionLayer1 +1;
			}

			nCounter++;
		}
	}
	
	nColSize = Num_Best_Unit_Array.at(nRowSize-1);

	nPositionLayer1 = DIP_Best_Unit_Array.size() - nColSize;
	fMax = 0;
	for(i=0; i<nColSize; i++)
		{
			if(DIP_Best_Unit_Array.at(nPositionLayer1+i).fShortestPath > fMax)
			{
				fMax = DIP_Best_Unit_Array.at(nPositionLayer1+i).fShortestPath;
				wMaxPos = nPositionLayer1+i;
			}
		}
	Best_Units_Path.fShortestPath = fMax;
	Best_Units_Path.wCurrentPath = new WORD[nRowSize];
	memcpy(Best_Units_Path.wCurrentPath,DIP_Best_Unit_Array.at(wMaxPos).wCurrentPath, nRowSize*sizeof(WORD));
	Best_Units_Path.wPathSize = nRowSize;


}

DIPDISINFO CMyDatabase::GetBestUnit(WORD index)
{
	DIPDISINFO BestUnit;
	BestUnit = DIP_Best_Unit_Array.at(index);
	return BestUnit;

}

BYTE CMyDatabase::GetPosBestUnit(WORD index)
{

	if(index>= Best_Units_Path.wPathSize) return 0;

	return Best_Units_Path.wCurrentPath[index];

}



void CMyDatabase::EmptyBestUnitArray()
{
	DIP_Best_Unit_Array.clear();
	Num_Best_Unit_Array.clear();
}



float CMyDatabase::ToneDistance(BYTE Tone1, BYTE Tone2)
{
	int ToneVector[8][2] = {0,  0,
							-1, 1,
							1,  4,
							-1, 2,
							1,  1,
							-1, 6,
							2,  1,
							-1, 1};
	float fDistance;
	if((Tone1==0)||(Tone2==0)) fDistance = 0.5f;
	else
		fDistance = 0.1f*float(abs(ToneVector[Tone1-1][0] - ToneVector[Tone2-1][0]) + ToneVector[Tone1-1][1] + ToneVector[Tone2-1][1]);
	
	return (1-fDistance);
}
// Cac ham de lay ra cac he so MFCC trong CSDL, ket qua tra ve trong mang result
void CMyDatabase::GetMFCCBegin(WORD wIndex, float* result)
{
	DWORD address, elementLen;
	int i = 0;		
	// Lay ra dia chi va do dai cua vung du lieu cua don vi am wIndex
	fseek(m_fAUnits,8*wIndex + 4 + 2, SEEK_SET);	
	fread(&address, 4,1,m_fAUnits);
	elementLen = GetElementLen(wIndex);
	// Lay ra 12 he so MFCC begin, ket qua tra ve trong mang result
	for(i = 0;i<12;i++)
	{			
		fseek(m_fAUnits,address + elementLen - 96 + i*4, SEEK_SET);
		fread(&result[i],4,1,m_fAUnits);
	}		
}
void CMyDatabase::GetMFCCEnd(WORD wIndex, float* result)
{
	DWORD address, elementLen;
	int i = 0;	
	// Lay ra dia chi va do dai cua vung du lieu cua don vi am wIndex trong CSDL
	fseek(m_fAUnits,8*wIndex + 4 + 2, SEEK_SET);	
	fread(&address, 4,1,m_fAUnits);	
	elementLen = GetElementLen(wIndex);
	// Lay ra 12 he so MFCC end, ket qua tra ve trong mang result
	for(i = 0;i<12;i++)
	{			
		fseek(m_fAUnits,address + elementLen - 48 + i*4, SEEK_SET);		
		fread(&result[i],4,1,m_fAUnits);
	}	
}
// Ham tinh khoang cach MFCC
float CMyDatabase::MFCCdistance(float* mfcc1, float* mfcc2)
{
     int j,nCounter;
     float sum_sq_x,sum_sq_y,sum_coproduct,sweep,delta_x,delta_y;
     float mean_x,mean_y,pop_sd_x,pop_sd_y,cov_x_y,correlation;
     
     nCounter = 2;
     sum_sq_x = 0;
     sum_sq_y = 0;
     sum_coproduct = 0;
     mean_x = mfcc1[0]; 
     mean_y = mfcc2[0];
     
     for(j=0; j<12; j++)
      {
           if(j==0) continue;
           sweep = (float)(nCounter - 1.0)/nCounter;     
           delta_x = mfcc1[j] - mean_x;
           delta_y = mfcc2[j] - mean_y;
           sum_sq_x += delta_x * delta_x * sweep;
           sum_sq_y += delta_y * delta_y * sweep;
		   sum_coproduct += delta_x * delta_y * sweep;
		   mean_x += delta_x / nCounter;
		   mean_y += delta_y / nCounter;
		   nCounter++;         
      } 
      pop_sd_x = sqrt(sum_sq_x/nCounter);
      pop_sd_y = sqrt(sum_sq_y/nCounter);
      cov_x_y  = sum_coproduct/nCounter;
      correlation = cov_x_y/(pop_sd_x*pop_sd_y);
     
     return (float)(2*(1.0-correlation));     
}