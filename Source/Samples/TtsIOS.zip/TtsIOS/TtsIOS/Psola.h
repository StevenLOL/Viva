// Psola.h: interface for the CPsola class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PSOLA_H__0E9EF8B5_0D05_40B0_8D75_DAE379C7F904__INCLUDED_)
#define AFX_PSOLA_H__0E9EF8B5_0D05_40B0_8D75_DAE379C7F904__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "MyConstants.h"
#include "MyDatabase.h"
#include "stdstring.h"

class CPsola   
{
public:
	static BOOL DB_UpdateUnit(WORD wIndex, UNITINFO UnitContext);
	static BOOL B_EnergySmooth;
	static BOOL EnergySmooth(FRAMEPOSSTRUCT PreSyl, FRAMEPOSSTRUCT CurSyl, SYLLABLESTRUCT &Syl);
	static BOOL DB_FIleMerge(CStdStringA FileName);
	static BYTE bSettingUnitType;
	static BOOL BAutoORHand;
	static BYTE BAutoORHandF0;
	static BOOL BSettingInputText;
	static int nF0_Begin;
	static int nTypeOfPhrase;
	static float fSpeakingRate;
	static CStdStringA CsNameOfWavFile;
	static CStdStringA CsNameOfDebugFile;
	static BOOL DB_Close();
	static int TonForSyllable(BYTE TonType, int F0, int **nF0, int **nLen, int nLenOfSyl,float fTransitionPoint);// tra ve so diem can thay doi F0
	
	//static UNITINFO TempUnit;
	static short GetAbsAvgValue(short *lpArray,int nNumber);
	static double m_AUTOCORdCoefHeuristic;
	static BOOL MedianSmooth(short *lpSigal, int nSize);
	static short AUTOCOR_CaculateFo(short *lpFrame, int nFrameLen);
	static double AUTOCOR_Energy(short* lpFrame,int nLen);
	static BOOL TDPR_PlayText(CStdStringA &cs);
	static BOOL TDPR_StopSound();

	static BOOL DB_GetAUnitInfo(UNITINFO &info);

	static BOOL DB_Reload();
	static BOOL DB_Open(LPCTSTR lpszDBFileName);
	
	static CStdStringA GetLastError(	int *nErrorCode=NULL);
	static BOOL OutputLastError(CStdStringA strOut);
	static DWORD AMDF_CaculateTo(		LPCSTR cSignal,LONG lCount);
	static BOOL HanningWnd(			LPSTR m_cSignal,LONG lCount); 
	static int GetMinValue(int *nArray,int nCount);
	static int GetMaxValue(int *nArray,int nCount);
	static int GetMaxAbsValue(short *nArray,int nCount);
//	static int GetMaxAbsValue(char *nArray,int nCount);
	static LONG GetMaxValuePos(LPCTSTR lpSignal, DWORD dwLen, LONG *lMaxValue=NULL);
	static LONG GetMaxPositiveValuePos(LPCTSTR lpSignal, DWORD dwLen, LONG *lMaxValue=NULL);
	static LONG GetMaxNegativeValuePos(LPCTSTR lpSignal, DWORD dwLen, LONG *lMaxValue=NULL);
	static BOOL AccentFromOneFrame(	FRAMESTRUCT stFrame, int *nFo = NULL, int nNumberFo = 0);
	static double m_dCoefHeuristic;
	static WORD m_wVolumeAmp;
	static WORD m_wSilenceSize;
	static FRAMEPOSSTRUCT FP_OldSyl; // Bo xung ngay 01 thang 01 nam 2006 -> chua thong tin Syllable dung truoc

	CPsola();
	virtual ~CPsola();

protected:
		
	static DWORD GetMaxTo(DWORD *lpArray, int nNumber);
	static DWORD GetAvgTo(DWORD *lpArray, int nNumber);
	static BOOL AccentFromPhone(UNITINFO &Dip1,UNITINFO &Dip2,PHONESTRUCT &stPhone, int *nFo = NULL, int nNumberFo = 0, BYTE TonType = 0);
	//static BOOL AccentFromPhone(UNITINFO Unit[4],PHONESTRUCT &stPhone, int *nFo = NULL, int nNumberFo = 0);
	static int AUTOCOR_IndexOfMin(short peak[2]);
	static int AUTOCOR_IndexOfMin(LONG peak[2]);
	static BOOL HanningLeft(LPSTR lpSignal, DWORD dwMax); 
	static BOOL HanningRight(LPSTR lpSignal, DWORD dwMax);
	static BOOL CreateSyllable(SYLLABLESTRUCT &stSyllable);
	static CMyDatabase m_db;
	static BOOL ConnectAUnits(CONNECTUNITSSTRUCT &stAUnits);
	static BOOL BalanceAmplitude(UNITINFO &stDip1,int *nPeakPos1,int nNumberPeaks1,
								UNITINFO &stDip2,int *nPeakPos2,int nNumberPeaks2);
	static BOOL ChangeAmplitude(LPSTR lpSignal,int nLen, double dCoef);
	//static BOOL CreateNewPhone(UNITINFO stDip1,int *nPeakPos1,int nNumberPos1,
							//	UNITINFO stDip2,int *nPeakPos2,int nNumberPos2,
							//	PHONESTRUCT &stPhone,int *nFramePos,int nNumberFrame);
	static BOOL CreateNewPhone(UNITINFO stDip1,UNITINFO stDip2,PHONESTRUCT &stPhone,int *nFramePos,int nNumberFrame);
	static BOOL CreateNewPhone(UNITINFO stDip1,UNITINFO stDip2,UNITINFO &stConnect, int ConnectType);
	//static BOOL CreateNewPhone(UNITINFO stDip1,UNITINFO stDip2,PHONESTRUCT &stPhone,
								//int *nFramePos,int nNumberFrame, int ConnectType); // ConnectType dung de kiem tra 
																				   // loai unite de ket noi
																				   // Co thay doi F0 = 1, ko thay doi co gia tri la 2

	static DWORD m_dwThreshold;
	static LONG AccentAiguFrom1Frame(	FRAMESTRUCT &stFrame, int nStartFo, int nFinalFo );
	static LONG AccentGraveFrom1Frame(	FRAMESTRUCT &stFrame, int nStartFo, int nFinalFo );
	static LONG SansAccentFrom1Frame(	FRAMESTRUCT &stFrame, int nNewFo);
	static int SansAccentFromPhone(   FRAMEPOSSTRUCT &stFramePos, int nNewTo);
	static int AccentGraveFromPhone(   FRAMEPOSSTRUCT &stFramePos, int nStartTo, int nFinalTo);
	static int AccentAiguFromPhone(   FRAMEPOSSTRUCT &stFramePos, int nStartTo, int nFinalTo);
	static int m_nErrorCode;
	static CStdStringA m_csError;
	static DWORD * AMDF_CalculeDk(LPCSTR cSignal,LONG nCount,  DWORD &dwMinDk, LONG *lSize = NULL);
};

#endif // !defined(AFX_PSOLA_H__0E9EF8B5_0D05_40B0_8D75_DAE379C7F904__INCLUDED_)
