#include <jni.h>
#include <android/log.h>
#include <string.h>

extern "C"
{
	jstring Java_com_mica_ttsandroid_TtsAndroidActivity_nativeStart(JNIEnv*  env, jobject thiz, jstring javaInput)
	{
		return env->NewStringUTF("Hello from native code!");
	}
}