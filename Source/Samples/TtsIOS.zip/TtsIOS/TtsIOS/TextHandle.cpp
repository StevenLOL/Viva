// TextHandle.cpp: implementation of the CTextHandle class.
//
//////////////////////////////////////////////////////////////////////

//#include "stdafx.h"

#include "TextHandle.h"
//#include "Psola.h"
//#include "TDPSOLA_Console.h"
#include "stdstring.h"
//#include "cocos2d.h"
//using namespace cocos2d;

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CStdStringA CTextHandle::m_csError;
int		CTextHandle::m_nErrorCode = TH_NOERROR;
CStdStringA CTextHandle::CsNameOfDebugFile = "";
CStdStringA CTextHandle::CsNameOfWavFile = "";
CStdStringA CTextHandle::CsDirectoryOfFile = "";
CStdStringA CTextHandle::CS_DBFileName = "";
CStdStringA CTextHandle::CsNameOfSynFile = "";
int CTextHandle::nF0_Begin = 0;
float CTextHandle::fSpeakingRate = 0;
int CTextHandle::nTypeOfPhrase = 3;
BYTE CTextHandle::bSettingUnitType = 2;
BOOL CTextHandle::BSettingInputText = TRUE;

CTextHandle::CTextHandle()
{

}

CTextHandle::~CTextHandle() 
{
	this->Empty();
}
/******************************************************************************************************************/
BOOL CTextHandle::IsNumeric(LPCTSTR lpBuf,WORD wLen)
{
	for(int i = 0;i < wLen; i++)
	{
		if( (lpBuf[i] != '0')&&(lpBuf[i] != '1')&&(lpBuf[i] != '2')&&(lpBuf[i] != '3')&&(lpBuf[i] != '4')
			&&(lpBuf[i] != '5')&&(lpBuf[i] != '6')&&(lpBuf[i] != '7')&&(lpBuf[i] != '8')&&(lpBuf[i] != '9'))
			return FALSE;
	}
	return TRUE;
}
/******************************************************************************************************************/
CStdStringA CTextHandle::GetLastError(int *nErrorCode)
{
	if(nErrorCode) *nErrorCode = m_nErrorCode;
	switch(m_nErrorCode)
	{
		case TH_INDEXOVERFLOW :			return "Index Overflow";
		case TH_UNITNOTFOUND	:		return m_csError;
		case TH_UNITNOTPAIR :		return m_csError;
		case TH_LENNOTNUMERIC	:		return m_csError;
		case TH_FONOTNUMERIC :			return m_csError;
		case TH_SILENCELENNOTNUMERIC :	return m_csError;
	}
	return "No Error";
}
/******************************************************************************************************************/
BOOL CTextHandle::ParseText(CStdStringA &cs)
{
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// The variables used for analyzing the context of a syllable.
	// Adding: 19-12-2006
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////

	BYTE BTypeOfPhrase;	
	BYTE bUnitType;  // 4 Syllable
					// 2 DemiSyllable
					// 1 Dephone
					// 0 Phone
					// 3 Initial - Final Parts
					// 5 all
	//CArray<UNITINFOFULL,UNITINFOFULL> SyllableArray;
	vector<UNITINFOFULL> SyllableArray;
	//CStringArray SylArray; //test
	UNITINFOFULL SyllableElement;
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////
	int nPhraseBegPos, nPhraseEndPos, nSyntagmBegPos, nSyntagmEndPos, 
		nWordBegPos, nWordEndPos, nSyllableBegPos, nSyllableEndPos, nStressPos, 
		nPhraseEndPosQuestion, nPhraseEndPosImperative; // nPhraseEndPosQuestion added for demo aniverssary
	int nSylPosInWord, nSylPosInSyntagm, nSylPosInPhrase;
	int nNumOfDash, nNumOfSpace;
	int nPhraseLen, nSyntagmLen, nWordLen;
	int nPhraseLenInSyl, nSyntagmLenInSyl, nWordLenInSyl;
	int i = -1;
	int j = 0;
	int nLen;
	CStdStringA csMid, csPhrase, csSyntagm, csWord, csSyllable;
	
//	if(CPsola::BAutoORHandF0 == TRUE)

	BTypeOfPhrase = nTypeOfPhrase;
	
	if(1)//(CPsola::BSettingInputText == TRUE)
	{
		//LoadDictionary();
		LoadPhoneme();
		LoadVowelAndTone();
		Empty();
		
		int dwBegin, dwEnd;
		CStdStringA csTemp, csOut, csF0, csTemp1;
		//int dwSize = SyllableArray.size();

		CStdStringA csPhoneme[13]			= {"7X","EX","aX","OX","ie","M7","uo","NG","th","tr","NJ","ss","zr"};
		CStdStringA csPhonemeConverted[13]  = {"Z", "A", "B", "Q", "I", "U", "Y", "N", "T", "R", "J", "S", "r"};
		
		
		cs.Remove('\r'); cs.Remove('\n');
		nLen = cs.GetLength();
		nPhraseBegPos =0;
		//SylArray.Add("SILP");
		SyllableElement.cUnitName ="SILP";
		SyllableElement.PosInWord =0;
		SyllableElement.PosInSyntagm =0;
		SyllableElement.PosInPhrase =0;
		SyllableElement.Stress = 0;
		SyllableElement.TypeOfPhrase = 0;
		
		SyllableArray.push_back(SyllableElement);
		while( nPhraseBegPos + 1 < nLen )
		{
			nPhraseEndPos = cs.Find('.',nPhraseBegPos);
			nPhraseEndPosQuestion = cs.Find('?',nPhraseBegPos);
			nPhraseEndPosImperative = cs.Find('!',nPhraseBegPos);
			

			#pragma region phan tich kieu cau

			if((nPhraseEndPos >-1)||(nPhraseEndPosQuestion >-1)||(nPhraseEndPosImperative >-1))
			{
				int nPosMin =-1;
				if (nPhraseEndPos >-1) nPosMin = nPhraseEndPos;
				if (((nPosMin > nPhraseEndPosQuestion)&&(nPhraseEndPosQuestion >-1))||(nPosMin == -1)) nPosMin = nPhraseEndPosQuestion;
				if (((nPosMin > nPhraseEndPosImperative)&&(nPhraseEndPosImperative >-1))||(nPosMin == -1)) nPosMin = nPhraseEndPosImperative;
				
				if(nPosMin == nPhraseEndPos)
				{
					//nPhraseEndPos = nPhraseEndPosImperative;
					if(nTypeOfPhrase == 3)	BTypeOfPhrase = 0;
				}
				if(nPosMin == nPhraseEndPosQuestion)
				{
					nPhraseEndPos = nPhraseEndPosQuestion;
					if(nTypeOfPhrase == 3)	BTypeOfPhrase = 1;
				}
				if(nPosMin == nPhraseEndPosImperative)
				{
					nPhraseEndPos = nPhraseEndPosImperative;
					if(nTypeOfPhrase == 3)	BTypeOfPhrase = 2;
				}



			}
			
			else 
			{
				if(nTypeOfPhrase == 3) BTypeOfPhrase = 0;
			}

			#pragma endregion phan tich kieu cau

			


			#pragma region set speaking rate
			switch(BTypeOfPhrase)

			{
				case 0: fRegister		= 1.0f;
						fSpeakingRate	= 1.0f;
						break;
				case 1: fRegister		= 1.1f;
						fSpeakingRate	= 0.92f;
						break;
				case 2: fRegister		= 1.2f;
						fSpeakingRate	= 0.85f;
						break;
			}
			#pragma endregion set speaking rate
			

			#pragma region khong co dau cham cau

			if(nPhraseEndPos == -1)
			{ 
				if (nLen -nPhraseBegPos ==0) break;
				////////////////////////////////////////////////////
				// Extract the phrase of a paragraph.
				////////////////////////////////////////////////////
				csMid= cs.Mid(nPhraseBegPos, nLen - nPhraseBegPos);
				csMid.Replace('\t',' ');
				for(;;)
				{
					int nIsDoubleSpace;
					nIsDoubleSpace = csMid.Replace("  "," ");
					if (nIsDoubleSpace == 0) break;
				}
				csPhrase = csMid;
				csMid.TrimLeft();
				csMid.TrimRight();
				///////////////////////////////////
				// calculate number of syllable in phrase base on ' ' and '-'
				nNumOfSpace = csMid.Remove(' ');
				nNumOfDash	= csMid.Remove('-');
				nPhraseLenInSyl = nNumOfSpace + nNumOfDash +1;
				nSylPosInPhrase = 0;
				///////////////////////////////////
				nSyntagmBegPos = 0;
				nPhraseLen = csPhrase.GetLength();



				while(nSyntagmBegPos + 1 <nPhraseLen)
				{
					nSyntagmEndPos = csPhrase.Find(',',nSyntagmBegPos);

					#pragma region khong co dau phay

					if(nSyntagmEndPos == -1)
					{
						if(nPhraseLen - nSyntagmBegPos ==0) break;
						////////////////////////////////////////////////////
						// Extract the syntagm from a phrase.
						////////////////////////////////////////////////////
						if(nSyntagmBegPos > 0)	//SylArray.Add("SIL");
						{
							SyllableElement.cUnitName ="SIL";
							SyllableElement.PosInWord =0;
							SyllableElement.PosInSyntagm =0;
							SyllableElement.PosInPhrase =0;
							SyllableElement.Stress = 0;
							SyllableArray.push_back(SyllableElement);
						}
						csMid = csPhrase.Mid(nSyntagmBegPos, nPhraseLen-nSyntagmBegPos);
						csSyntagm = csMid;
						csMid.TrimLeft();
						csMid.TrimRight();
						///////////////////////////////////
						// calculate number of syllable in a syntagm based on ' ' and '-'
						nNumOfSpace = csMid.Remove(' ');
						nNumOfDash	= csMid.Remove('-');
						nSyntagmLenInSyl = nNumOfSpace + nNumOfDash +1;
						nSylPosInSyntagm =0;
						///////////////////////////////////
						nWordBegPos =0;
						nSyntagmLen = csSyntagm.GetLength();
						while(nWordBegPos + 1 < nSyntagmLen)
						{
							nWordEndPos = csSyntagm.Find(' ',nWordBegPos);
							if(nWordEndPos == -1)
							{
								if(nSyntagmLen -nWordBegPos ==0) break;
								////////////////////////////////////////////////////
								// Extract the word from a syntagm.
								////////////////////////////////////////////////////
								csMid = csSyntagm.Mid(nWordBegPos, nSyntagmLen-nWordBegPos);
								csWord = csMid;
								///////////////////////////////////
								// calculate number of syllable in a word based on '-'
								nNumOfDash	= csMid.Remove('-');
								nWordLenInSyl = nNumOfDash +1;
								nSylPosInWord =0;
								///////////////////////////////////
								nSyllableBegPos =0;
								nWordLen = csWord.GetLength();
								while(nSyllableBegPos + 1 <= nWordLen)
								{
									nSyllableEndPos = csWord.Find('-',nSyllableBegPos);
									if(nSyllableEndPos == -1)
									{
										if(nWordLen -nSyllableBegPos ==0) break;
										////////////////////////////////////////////////////
										// Extract the syllable from a word.
										////////////////////////////////////////////////////
										csMid = csWord.Mid(nSyllableBegPos, nWordLen-nSyllableBegPos);
										csSyllable = csMid;
										csSyllable.Remove('-');
										if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
										else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
										if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
										else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
										if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
										else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
										
										nStressPos = csSyllable.Find('\'',0);
										if(nStressPos == csSyllable.GetLength()-1) 
										{
											csSyllable.Remove('\'');
											SyllableElement.Stress = 1;
										}
										else SyllableElement.Stress = 0;
										
										SyllableElement.cUnitName = csSyllable;
										SyllableArray.push_back(SyllableElement);
										nSylPosInWord ++; 
										nSylPosInSyntagm++;
										nSylPosInPhrase++;
										//SylArray.Add(csSyllable);
										break;
									}
									csMid = csWord.Mid(nSyllableBegPos, nSyllableEndPos-nSyllableBegPos);
									csSyllable = csMid;
									csSyllable.Remove('-');
									csSyllable.Remove(' ');
									
									if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
									else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
									if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
									else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
									if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
									else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
																		
									nStressPos = csSyllable.Find('\'',0);
									if(nStressPos == csSyllable.GetLength()-1) 
									{
										csSyllable.Remove('\'');
										SyllableElement.Stress = 1;
									}
									else SyllableElement.Stress = 0;
									
									SyllableElement.cUnitName = csSyllable;
									SyllableArray.push_back(SyllableElement);
									nSylPosInWord ++; 
									nSylPosInSyntagm++;
									nSylPosInPhrase++;
									
									//SylArray.Add(csSyllable);						
									nSyllableBegPos = nSyllableEndPos +1;								
								}
								break;
							}//		if(nWordEndPos == -1)
							////////////////////////////////////////////////////
							// Extract the word from a syntagm.
							////////////////////////////////////////////////////
							csMid = csSyntagm.Mid(nWordBegPos, nWordEndPos-nWordBegPos);
							csWord = csMid;
							///////////////////////////////////
							// calculate number of syllable in a word based on '-'
							nNumOfDash	= csMid.Remove('-');
							nWordLenInSyl = nNumOfDash +1;
							nSylPosInWord =0;
							///////////////////////////////////
							nSyllableBegPos =0;
							nWordLen = csWord.GetLength();
							while(nSyllableBegPos + 1 <= nWordLen)
							{
								nSyllableEndPos = csWord.Find('-',nSyllableBegPos);
								if(nSyllableEndPos == -1)
								{
									if(nWordLen -nSyllableBegPos ==0) break;
									////////////////////////////////////////////////////
									// Extract the syllable from a word.
									////////////////////////////////////////////////////
									csMid = csWord.Mid(nSyllableBegPos, nWordLen-nSyllableBegPos);
									csSyllable = csMid;
									csSyllable.Remove('-');
									csSyllable.Remove(' ');

									if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
									else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
									if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
									else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
									if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
									else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
									
									nStressPos = csSyllable.Find('\'',0);
									if(nStressPos == csSyllable.GetLength()-1) 
									{
										csSyllable.Remove('\'');
										SyllableElement.Stress = 1;
									}
									else SyllableElement.Stress = 0;
									
									SyllableElement.cUnitName = csSyllable;
									SyllableArray.push_back(SyllableElement);
									nSylPosInWord ++; 
									nSylPosInSyntagm++;
									nSylPosInPhrase++;

									//SylArray.Add(csSyllable);
									break;
								}
								csMid = csWord.Mid(nSyllableBegPos, nSyllableEndPos-nSyllableBegPos);
								csSyllable = csMid;
								csSyllable.Remove('-');
								csSyllable.Remove(' ');

								if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
								else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
								if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
								else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
								if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
								else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
								
								nStressPos = csSyllable.Find('\'',0);
								if(nStressPos == csSyllable.GetLength()-1) 
								{
									csSyllable.Remove('\'');
									SyllableElement.Stress = 1;
								}
								else SyllableElement.Stress = 0;
								
								SyllableElement.cUnitName = csSyllable;
								SyllableArray.push_back(SyllableElement);
								nSylPosInWord ++; 
								nSylPosInSyntagm++;
								nSylPosInPhrase++;
								//SylArray.Add(csSyllable);						
								nSyllableBegPos = nSyllableEndPos +1;								
							}
							nWordBegPos = nWordEndPos +1;
						}//	while(nWordBegPos + 1 < nSyntagmLen)
						break;
					}//if(nSyntagmEndPos == -1)

					#pragma endregion khong co dau phay

					////////////////////////////////////////////////////
					// Extract the syntagm from a phrase.
					////////////////////////////////////////////////////


					if(nSyntagmBegPos > 0)	//SylArray.Add("SIL");
					{
						SyllableElement.cUnitName ="SIL";
						SyllableElement.PosInWord =0;
						SyllableElement.PosInSyntagm =0;
						SyllableElement.PosInPhrase =0;
						SyllableElement.Stress = 0;
						SyllableArray.push_back(SyllableElement);
					}
					csMid = csPhrase.Mid(nSyntagmBegPos, nSyntagmEndPos-nSyntagmBegPos);
					csSyntagm = csMid;
					csMid.TrimLeft();
					csMid.TrimRight();
					///////////////////////////////////
					// calculate number of syllable in a syntagm based on ' ' and '-'
					nNumOfSpace = csMid.Remove(' ');
					nNumOfDash	= csMid.Remove('-');
					nSyntagmLenInSyl = nNumOfSpace + nNumOfDash +1;
					nSylPosInSyntagm =0;
					///////////////////////////////////
					nWordBegPos =0;
					nSyntagmLen = csSyntagm.GetLength();

					#pragma region Extract the word from a syntagm

					while(nWordBegPos + 1 < nSyntagmLen)
					{
						nWordEndPos = csSyntagm.Find(' ',nWordBegPos);
						if(nWordEndPos == -1)
						{
							if(nSyntagmLen -nWordBegPos ==0) break;
							////////////////////////////////////////////////////
							// Extract the word from a syntagm.
							////////////////////////////////////////////////////
							csMid = csSyntagm.Mid(nWordBegPos, nSyntagmLen-nWordBegPos);
							csWord = csMid;
							///////////////////////////////////
							// calculate number of syllable in a word based on '-'
							nNumOfDash	= csMid.Remove('-');
							nWordLenInSyl = nNumOfDash +1;
							nSylPosInWord =0;
							///////////////////////////////////
							nSyllableBegPos =0;
							nWordLen = csWord.GetLength();
							while(nSyllableBegPos + 1 <= nWordLen)
							{
								nSyllableEndPos = csWord.Find('-',nSyllableBegPos);
								if(nSyllableEndPos == -1)
								{
									if(nWordLen -nSyllableBegPos ==0) break;
									////////////////////////////////////////////////////
									// Extract the syllable from a word.
									////////////////////////////////////////////////////
									csMid = csWord.Mid(nSyllableBegPos, nWordLen-nSyllableBegPos);
									csSyllable = csMid;
									csSyllable.Remove('-');
									csSyllable.Remove(' ');

									if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
									else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
									if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
									else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
									if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
									else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
								

									nStressPos = csSyllable.Find('\'',0);
									if(nStressPos == csSyllable.GetLength()-1) 
									{
										csSyllable.Remove('\'');
										SyllableElement.Stress = 1;
									}
									else SyllableElement.Stress = 0;
									
									SyllableElement.cUnitName = csSyllable;	
									SyllableArray.push_back(SyllableElement);

									nSylPosInWord ++; 
									nSylPosInSyntagm++;
									nSylPosInPhrase++;
									//SylArray.Add(csSyllable);
									break;
								}
								csMid = csWord.Mid(nSyllableBegPos, nSyllableEndPos-nSyllableBegPos);
								csSyllable = csMid;
								csSyllable.Remove('-');
								csSyllable.Remove(' ');
								
								if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
								else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
								if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
								else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
								if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
								else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
								
								nStressPos = csSyllable.Find('\'',0);
								if(nStressPos == csSyllable.GetLength()-1) 
								{
									csSyllable.Remove('\'');
									SyllableElement.Stress = 1;
								}
								else SyllableElement.Stress = 0;
									
								SyllableElement.cUnitName = csSyllable;
								SyllableArray.push_back(SyllableElement);
								nSylPosInWord ++; 
								nSylPosInSyntagm++;
								nSylPosInPhrase++;
								//SylArray.Add(csSyllable);						
								nSyllableBegPos = nSyllableEndPos +1;								
							}
							break;
						}
						////////////////////////////////////////////////////
						// Extract the word from a syntagm.
						////////////////////////////////////////////////////
						csMid = csSyntagm.Mid(nWordBegPos, nWordEndPos-nWordBegPos);
						csWord = csMid;
						///////////////////////////////////
						// calculate number of syllable in a word based on '-'
						nNumOfDash	= csMid.Remove('-');
						nWordLenInSyl = nNumOfDash +1;
						nSylPosInWord =0;
						///////////////////////////////////
						nSyllableBegPos =0;
						nWordLen = csWord.GetLength();
						while(nSyllableBegPos + 1 <= nWordLen)
						{
							nSyllableEndPos = csWord.Find('-',nSyllableBegPos);
							if(nSyllableEndPos == -1)
							{
								if(nWordLen -nSyllableBegPos ==0) break;
								////////////////////////////////////////////////////
								// Extract the syllable from a word.
								////////////////////////////////////////////////////
								csMid = csWord.Mid(nSyllableBegPos, nWordLen-nSyllableBegPos);
								csSyllable = csMid;
								csSyllable.Remove('-');
								csSyllable.Remove(' ');
								
								if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
								else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
								if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
								else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
								if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
								else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
								
								nStressPos = csSyllable.Find('\'',0);
								if(nStressPos == csSyllable.GetLength()-1) 
								{
									csSyllable.Remove('\'');
									SyllableElement.Stress = 1;
								}
								else SyllableElement.Stress = 0;
									
								SyllableElement.cUnitName = csSyllable;
								SyllableArray.push_back(SyllableElement);
								nSylPosInWord ++; 
								nSylPosInSyntagm++;
								nSylPosInPhrase++;
								
								//SylArray.Add(csSyllable);
								break;
							}
							csMid = csWord.Mid(nSyllableBegPos, nSyllableEndPos-nSyllableBegPos);
							csSyllable = csMid;
							csSyllable.Remove('-');
							csSyllable.Remove(' ');
							
							if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
							else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
							if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
							else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
							if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
							else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
							
							nStressPos = csSyllable.Find('\'',0);
							if(nStressPos == csSyllable.GetLength()-1) 
							{
								csSyllable.Remove('\'');
								SyllableElement.Stress = 1;
							}
							else SyllableElement.Stress = 0;
							
							SyllableElement.cUnitName = csSyllable;
							SyllableArray.push_back(SyllableElement);
							nSylPosInWord ++; 
							nSylPosInSyntagm++;
							nSylPosInPhrase++;
							//SylArray.Add(csSyllable);						
							nSyllableBegPos = nSyllableEndPos +1;								
						}
						nWordBegPos = nWordEndPos +1;
					}
					#pragma endregion 
					//	while(nWordBegPos + 1 < nSyntagmLen)
					nSyntagmBegPos = nSyntagmEndPos +1;
				}//while(nSyntagmBegPos + 1 <nPhraseLen)
				////////////////////////////////////////////////////
				break;
			}
			#pragma endregion khong co dau cham cau
			//		if(nPhraseEndPos == -1)
			////////////////////////////////////////////////////
			// Extract the phrase of a paragraph.
			////////////////////////////////////////////////////

			#pragma region co dau cham cau
			
			if(nPhraseBegPos > 0)	//SylArray.Add("SILS");
			{
				SyllableElement.cUnitName ="SILS";
				SyllableElement.PosInWord =0;
				SyllableElement.PosInSyntagm =0;
				SyllableElement.PosInPhrase =0;
				SyllableElement.Stress = 0;
				SyllableArray.push_back(SyllableElement);
			}
			#pragma endregion co dau cham cau
			csMid= cs.Mid(nPhraseBegPos, nPhraseEndPos - nPhraseBegPos);
			csMid.Replace('\t',' ');
			for(;;)
			{
				int nIsDoubleSpace;
				nIsDoubleSpace = csMid.Replace("  "," ");
				if (nIsDoubleSpace == 0) break;
			}
			csPhrase = csMid;
			csMid.TrimLeft();
			csMid.TrimRight();
			///////////////////////////////////
			// calculate number of syllable in phrase base on ' ' and '-'
			nNumOfSpace = csMid.Remove(' ');
			nNumOfDash	= csMid.Remove('-');
			nPhraseLenInSyl = nNumOfSpace + nNumOfDash +1;
			nSylPosInPhrase =0;
			///////////////////////////////////
			nSyntagmBegPos =0;
			nPhraseLen = csPhrase.GetLength();
			while(nSyntagmBegPos + 1 <nPhraseLen)
			{
				nSyntagmEndPos = csPhrase.Find(',',nSyntagmBegPos);
				if(nSyntagmEndPos == -1)
				{
					if(nPhraseLen - nSyntagmBegPos ==0) break;
					////////////////////////////////////////////////////
					// Extract the syntagm from a phrase.
					////////////////////////////////////////////////////
					if(nSyntagmBegPos > 0)	//SylArray.Add("SIL");
					{
						SyllableElement.cUnitName ="SIL";
						SyllableElement.PosInWord =0;
						SyllableElement.PosInSyntagm =0;
						SyllableElement.PosInPhrase =0;
						SyllableElement.Stress = 0;
						SyllableArray.push_back(SyllableElement);
					}
					csMid = csPhrase.Mid(nSyntagmBegPos, nPhraseLen-nSyntagmBegPos);
					csSyntagm = csMid;
					csMid.TrimLeft();
					csMid.TrimRight();
					///////////////////////////////////
					// calculate number of syllable in a syntagm based on ' ' and '-'
					nNumOfSpace = csMid.Remove(' ');
					nNumOfDash	= csMid.Remove('-');
					nSyntagmLenInSyl = nNumOfSpace + nNumOfDash +1;
					nSylPosInSyntagm =0;
					///////////////////////////////////
					nWordBegPos =0;
					nSyntagmLen = csSyntagm.GetLength();

					#pragma region Extract the word from a syntagm

					while(nWordBegPos + 1 < nSyntagmLen)
					{
						nWordEndPos = csSyntagm.Find(' ',nWordBegPos);
						if(nWordEndPos == -1)
						{
							if(nSyntagmLen -nWordBegPos ==0) break;
							////////////////////////////////////////////////////
							// Extract the word from a syntagm.
							////////////////////////////////////////////////////
							csMid = csSyntagm.Mid(nWordBegPos, nSyntagmLen-nWordBegPos);
							csWord = csMid;
							///////////////////////////////////
							// calculate number of syllable in a word based on '-'
							nNumOfDash	= csMid.Remove('-');
							nWordLenInSyl = nNumOfDash +1;
							nSylPosInWord =0;
							///////////////////////////////////
							nSyllableBegPos =0;
							nWordLen = csWord.GetLength();
							while(nSyllableBegPos + 1 <= nWordLen)
							{
								nSyllableEndPos = csWord.Find('-',nSyllableBegPos);
								if(nSyllableEndPos == -1)
								{
									if(nWordLen -nSyllableBegPos ==0) break;
									////////////////////////////////////////////////////
									// Extract the syllable from a word.
									////////////////////////////////////////////////////
									csMid = csWord.Mid(nSyllableBegPos, nWordLen-nSyllableBegPos);
									csSyllable = csMid;
									csSyllable.Remove('-');
									csSyllable.Remove(' ');
									
									if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
									else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
									if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
									else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
									if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
									else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
									
									nStressPos = csSyllable.Find('\'',0);
									if(nStressPos == csSyllable.GetLength()-1) 
									{
										csSyllable.Remove('\'');
										SyllableElement.Stress = 1;
									}
									else SyllableElement.Stress = 0;
									
									SyllableElement.cUnitName = csSyllable;	
									SyllableArray.push_back(SyllableElement);
									nSylPosInWord ++; 
									nSylPosInSyntagm++;
									nSylPosInPhrase++;
									//SylArray.Add(csSyllable);
									break;
								}
								csMid = csWord.Mid(nSyllableBegPos, nSyllableEndPos-nSyllableBegPos);
								csSyllable = csMid;
								csSyllable.Remove('-');

								if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
								else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
								if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
								else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
								if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
								else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
								
								nStressPos = csSyllable.Find('\'',0);
								if(nStressPos == csSyllable.GetLength()-1) 
								{
									csSyllable.Remove('\'');
									SyllableElement.Stress = 1;
								}
								else SyllableElement.Stress = 0;

								SyllableElement.cUnitName = csSyllable;	
								SyllableArray.push_back(SyllableElement);
								nSylPosInWord ++; 
								nSylPosInSyntagm++;
								nSylPosInPhrase++;
								//SylArray.Add(csSyllable);						
								nSyllableBegPos = nSyllableEndPos +1;								
							}
							break;
						}//		if(nWordEndPos == -1)
						////////////////////////////////////////////////////
						// Extract the word from a syntagm.
						////////////////////////////////////////////////////
						csMid = csSyntagm.Mid(nWordBegPos, nWordEndPos-nWordBegPos);
						csWord = csMid;
						///////////////////////////////////
						// calculate number of syllable in a word based on '-'
						nNumOfDash	= csMid.Remove('-');
						nWordLenInSyl = nNumOfDash +1;
						nSylPosInWord =0;
						///////////////////////////////////
						nSyllableBegPos =0;
						nWordLen = csWord.GetLength();

						#pragma region Extract the syllable from a word

						while(nSyllableBegPos + 1 <= nWordLen)
						{
							nSyllableEndPos = csWord.Find('-',nSyllableBegPos);
							if(nSyllableEndPos == -1)
							{
								if(nWordLen -nSyllableBegPos ==0) break;
								////////////////////////////////////////////////////
								// Extract the syllable from a word.
								////////////////////////////////////////////////////
								csMid = csWord.Mid(nSyllableBegPos, nWordLen-nSyllableBegPos);
								csSyllable = csMid;
								csSyllable.Remove('-');
								csSyllable.Remove(' ');

								if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
								else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
								if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
								else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
								if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
								else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
								
								nStressPos = csSyllable.Find('\'',0);
								if(nStressPos == csSyllable.GetLength()-1) 
								{
									csSyllable.Remove('\'');
									SyllableElement.Stress = 1;
								}
								else SyllableElement.Stress = 0;
								
								SyllableElement.cUnitName = csSyllable;
								SyllableArray.push_back(SyllableElement);
								nSylPosInWord ++; 
								nSylPosInSyntagm++;
								nSylPosInPhrase++;
								//SylArray.Add(csSyllable);
								break;
							}
							csMid = csWord.Mid(nSyllableBegPos, nSyllableEndPos-nSyllableBegPos);
							csSyllable = csMid;
							csSyllable.Remove('-');
							csSyllable.Remove(' ');
							
							if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
							else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
							if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
							else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
							if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
							else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
							
							nStressPos = csSyllable.Find('\'',0);
							if(nStressPos == csSyllable.GetLength()-1) 
							{
								csSyllable.Remove('\'');
								SyllableElement.Stress = 1;
							}
							else SyllableElement.Stress = 0;
							
							SyllableElement.cUnitName = csSyllable;
							SyllableArray.push_back(SyllableElement);
							nSylPosInWord ++; 
							nSylPosInSyntagm++;
							nSylPosInPhrase++;
							//SylArray.Add(csSyllable);						
							nSyllableBegPos = nSyllableEndPos +1;								
						}

						#pragma endregion Extract the syllable from a word
						nWordBegPos = nWordEndPos +1;
					}
					#pragma endregion Extract the word from a syntagm
					//	while(nWordBegPos + 1 < nSyntagmLen)
				//	SylArray.Add("SILS");
					break;
				}//if(nSyntagmEndPos == -1)
				////////////////////////////////////////////////////
				// Extract the syntagm from a phrase.
				////////////////////////////////////////////////////
				if(nSyntagmBegPos > 0)	//SylArray.Add("SIL");
				{
					SyllableElement.cUnitName ="SIL";
					SyllableElement.PosInWord =0;
					SyllableElement.PosInSyntagm =0;
					SyllableElement.PosInPhrase =0;
					SyllableElement.Stress = 0;
					SyllableArray.push_back(SyllableElement);
				}
				csMid = csPhrase.Mid(nSyntagmBegPos, nSyntagmEndPos-nSyntagmBegPos);
				csSyntagm = csMid;
				csMid.TrimLeft();
				csMid.TrimRight();
				///////////////////////////////////
				// calculate number of syllable in a syntagm based on ' ' and '-'
				nNumOfSpace = csMid.Remove(' ');
				nNumOfDash	= csMid.Remove('-');
				nSyntagmLenInSyl = nNumOfSpace + nNumOfDash +1;
				nSylPosInSyntagm =0;
						///////////////////////////////////
				nWordBegPos =0;
				nSyntagmLen = csSyntagm.GetLength();
				while(nWordBegPos + 1 < nSyntagmLen)
				{
					nWordEndPos = csSyntagm.Find(' ',nWordBegPos);
					if(nWordEndPos == -1)
					{
						if(nSyntagmLen -nWordBegPos ==0) break;
						////////////////////////////////////////////////////
						// Extract the word from a syntagm.
						////////////////////////////////////////////////////
						csMid = csSyntagm.Mid(nWordBegPos, nSyntagmLen-nWordBegPos);
						csWord = csMid;
						///////////////////////////////////
						// calculate number of syllable in a word based on '-'
						nNumOfDash	= csMid.Remove('-');
						nWordLenInSyl = nNumOfDash +1;
						nSylPosInWord =0;
						///////////////////////////////////
						nSyllableBegPos =0;
						nWordLen = csWord.GetLength();
						while(nSyllableBegPos + 1 <= nWordLen)
						{
							nSyllableEndPos = csWord.Find('-',nSyllableBegPos);
							if(nSyllableEndPos == -1)
							{
								if(nWordLen -nSyllableBegPos ==0) break;
								////////////////////////////////////////////////////
								// Extract the syllable from a word.
								////////////////////////////////////////////////////
								csMid = csWord.Mid(nSyllableBegPos, nWordLen-nSyllableBegPos);
								csSyllable = csMid;
								csSyllable.Remove('-');
								csSyllable.Remove(' ');
								
								if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
								else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
								if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
								else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
								if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
								else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
							
								nStressPos = csSyllable.Find('\'',0);
								if(nStressPos == csSyllable.GetLength()-1) 
								{
									csSyllable.Remove('\'');
									SyllableElement.Stress = 1;
								}
								else SyllableElement.Stress = 0;
							
								SyllableElement.cUnitName = csSyllable;
								SyllableArray.push_back(SyllableElement);
								nSylPosInWord ++; 
								nSylPosInSyntagm++;
								nSylPosInPhrase++;
								//SylArray.Add(csSyllable);
								break;
							}
							csMid = csWord.Mid(nSyllableBegPos, nSyllableEndPos-nSyllableBegPos);
							csSyllable = csMid;
							csSyllable.Remove('-');
							csSyllable.Remove(' ');

							if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
							else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
							if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
							else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
							if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
							else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
							
							nStressPos = csSyllable.Find('\'',0);
							if(nStressPos == csSyllable.GetLength()-1) 
							{
								csSyllable.Remove('\'');
								SyllableElement.Stress = 1;
							}
							
							SyllableElement.cUnitName = csSyllable;
							SyllableArray.push_back(SyllableElement);
							nSylPosInWord ++; 
							nSylPosInSyntagm++;
							nSylPosInPhrase++;
							//SylArray.Add(csSyllable);						
							nSyllableBegPos = nSyllableEndPos +1;								
						}
						break;
					}
					////////////////////////////////////////////////////
					// Extract the word from a syntagm.
					////////////////////////////////////////////////////
					csMid = csSyntagm.Mid(nWordBegPos, nWordEndPos-nWordBegPos);
					csWord = csMid;
					///////////////////////////////////
					// calculate number of syllable in a word based on '-'
					nNumOfDash	= csMid.Remove('-');
					nWordLenInSyl = nNumOfDash +1;
					nSylPosInWord =0;
					///////////////////////////////////
					nSyllableBegPos =0;
					nWordLen = csWord.GetLength();
					while(nSyllableBegPos + 1 <= nWordLen)
					{
						nSyllableEndPos = csWord.Find('-',nSyllableBegPos);
						if(nSyllableEndPos == -1)
						{
							if(nWordLen -nSyllableBegPos ==0) break;
							////////////////////////////////////////////////////
							// Extract the syllable from a word.
							////////////////////////////////////////////////////
							csMid = csWord.Mid(nSyllableBegPos, nWordLen-nSyllableBegPos);
							csSyllable = csMid;
							csSyllable.Remove('-');
							csSyllable.Remove(' ');
							
							if((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
							else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
							if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
							else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
							if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
							else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
							
							nStressPos = csSyllable.Find('\'',0);
							if(nStressPos == csSyllable.GetLength()-1) 
							{
								csSyllable.Remove('\'');
								SyllableElement.Stress = 1;
							}
							else SyllableElement.Stress = 0;
							
							SyllableElement.cUnitName = csSyllable;
							SyllableArray.push_back(SyllableElement);
							nSylPosInWord ++; 
							nSylPosInSyntagm++;
							nSylPosInPhrase++;
							//SylArray.Add(csSyllable);
							break;
						}
						csMid = csWord.Mid(nSyllableBegPos, nSyllableEndPos-nSyllableBegPos);
						csSyllable = csMid;
						csSyllable.Remove('-');
						csSyllable.Remove(' ');
						
						if(((nSylPosInWord == (nWordLenInSyl-1))&&(nWordLenInSyl>1))&&(nWordLenInSyl>1)) SyllableElement.PosInWord = 1;
						else SyllableElement.PosInWord = float(nSylPosInWord)/nWordLenInSyl;
						if(nSylPosInSyntagm == (nSyntagmLenInSyl-1)) SyllableElement.PosInSyntagm = 1;
						else SyllableElement.PosInSyntagm = float(nSylPosInSyntagm)/nSyntagmLenInSyl;
						if(nSylPosInPhrase == (nPhraseLenInSyl-1)) SyllableElement.PosInPhrase = 1;
						else SyllableElement.PosInPhrase = float(nSylPosInPhrase)/nPhraseLenInSyl;
					
						nStressPos = csSyllable.Find('\'',0);
						if(nStressPos == csSyllable.GetLength()-1) 
						{
							csSyllable.Remove('\'');
							SyllableElement.Stress = 1;
						}
						else SyllableElement.Stress = 0;
						
						SyllableElement.cUnitName = csSyllable;
						SyllableArray.push_back(SyllableElement);
						nSylPosInWord ++; 
						nSylPosInSyntagm++;
						nSylPosInPhrase++;
						//SylArray.Add(csSyllable);						
						nSyllableBegPos = nSyllableEndPos +1;								
					}
					nWordBegPos = nWordEndPos +1;
				}//	while(nWordBegPos + 1 < nSyntagmLen)
				nSyntagmBegPos = nSyntagmEndPos +1;
			}//while(nSyntagmBegPos + 1 <nPhraseLen)
			////////////////////////////////////////////////////
			nPhraseBegPos = nPhraseEndPos +1;			

		/*}// End of while( nPhraseBegPos + 1 < nLen )*/

		if(nPhraseBegPos + 1>= nLen)
		{
			SyllableElement.cUnitName ="SILP";
			SyllableElement.PosInWord =0;
			SyllableElement.PosInSyntagm =0;
			SyllableElement.PosInPhrase =0;
			SyllableElement.Stress = 0;

			SyllableArray.push_back(SyllableElement);
		}
		
		
		int dwSize = SyllableArray.size();


		
		for(j=0; j<dwSize;j++)	
		{
			//SyllableAnalysis(SyllableArray.ElementAt(j));
			//if( SyllableAnalysis(SyllableArray.ElementAt(j))==TRUE) // Dung thu ham moi
			if(SyllableAnalysis(SyllableArray.at(j).cUnitName,SyllableArray.at(j))==TRUE)
			{
				if(SyllableArray.at(j).PosInSyntagm ==1) SyllableArray.at(j).Stress =1;
				//else if(SyllableArray.ElementAt(j).Stress !=1) SyllableArray.ElementAt(j).Stress = 0;
				
				//////////////////////////////////////////////////////////////////////////////////////////////////////////
				SyllableElement = SyllableArray.at(j);
				for(i=0; i<4;i++) 
				{
					if(SyllableElement.csSound[i]=="NUL") SyllableElement.csSound[i].Empty();
					for(int k=0; k<13; k++)
					{
						if(SyllableElement.csSound[i] == csPhoneme[k]) 
						{
							SyllableElement.csSound[i] = csPhonemeConverted[k];
							SyllableArray.at(j).csSound[i] = csPhonemeConverted[k];
							break;
						}
					}
				}
					
				bUnitType =bSettingUnitType;

				switch (bUnitType)
				{
					
					case 0:// AUnit
						for(i=0; i<4;i++) SyllableArray.at(j).csSubUnit[i] = SyllableElement.csSound[i];
						SyllableArray.at(j).bNumOfSubUnit = 4;
						SyllableArray.at(j).bUnitType = bUnitType;
						break;

					case 1:// AUnit
						SyllableArray.at(j).bNumOfSubUnit = 4;
						SyllableArray.at(j).csSubUnit[0] = '_' + SyllableElement.csSound[0];
						if(SyllableArray.at(j).csSubUnit[0] == "_")
						{
							SyllableArray.at(j).bNumOfSubUnit --;
							SyllableArray.at(j).csSubUnit[0] = "_" + SyllableElement.csSound[1]+SyllableElement.csSound[2];
							SyllableArray.at(j).csSubUnit[1] = SyllableElement.csSound[2]+SyllableElement.csSound[3];
							SyllableArray.at(j).csSubUnit[2] = SyllableElement.csSound[3]+ '_';
							if(SyllableArray.at(j).csSubUnit[2] =="_")
							{
								SyllableArray.at(j).csSubUnit[1] = SyllableElement.csSound[2]+'_';
								SyllableArray.at(j).csSubUnit[2].Empty();
								SyllableArray.at(j).bNumOfSubUnit--;
							}
						}
						else
						{
							SyllableArray.at(j).csSubUnit[1] = SyllableElement.csSound[0]+SyllableElement.csSound[1]+SyllableElement.csSound[2];
							SyllableArray.at(j).csSubUnit[2] = SyllableElement.csSound[2]+SyllableElement.csSound[3];
							SyllableArray.at(j).csSubUnit[3] = SyllableElement.csSound[3]+ '_';
							if(SyllableArray.at(j).csSubUnit[3] =="_")
							{
								SyllableArray.at(j).csSubUnit[2] = SyllableElement.csSound[2]+'_';
								SyllableArray.at(j).csSubUnit[3].Empty();
								SyllableArray.at(j).bNumOfSubUnit--;
							}
						}

						SyllableArray.at(j).bUnitType = bUnitType;
						break;
					case 2:// Demisyllable
						SyllableArray.at(j).csSubUnit[0] = "_" + SyllableElement.csSound[0]+SyllableElement.csSound[1]+SyllableElement.csSound[2];
						SyllableArray.at(j).csSubUnit[1] = SyllableElement.csSound[2]+SyllableElement.csSound[3] +'_';
						SyllableArray.at(j).bUnitType = bUnitType;
						SyllableArray.at(j).bNumOfSubUnit = 2;
						break;
					case 3:// Initial - Final Part
						SyllableArray.at(j).csSubUnit[0] = '_' + SyllableElement.csSound[0];
						SyllableArray.at(j).csSubUnit[1] = SyllableElement.csSound[2] + SyllableElement.csSound[2]+SyllableElement.csSound[3];
						SyllableArray.at(j).bUnitType = bUnitType;
						SyllableArray.at(j).bNumOfSubUnit = 2;
						break;
					case 4:// Syllble 
						SyllableArray.at(j).csSubUnit[0] = SyllableElement.csSound[0]+SyllableElement.csSound[1]+SyllableElement.csSound[2]+SyllableElement.csSound[3];
						SyllableArray.at(j).bUnitType = bUnitType;
						SyllableArray.at(j).bNumOfSound = 1;
						break;
					case 5:// Combination - At this time Combination = Demi-syllable. 23/12/2006
						SyllableArray.at(j).csSubUnit[0] = "_" + SyllableElement.csSound[0] + SyllableElement.csSound[1]+SyllableElement.csSound[2];
						SyllableArray.at(j).csSubUnit[1] = SyllableElement.csSound[2]+SyllableElement.csSound[3] +'_';
						SyllableArray.at(j).bUnitType = bUnitType;
						SyllableArray.at(j).bNumOfSubUnit = 2;
						break;
				}

			//////////////////////////////////////////////////////////////////////////////////////////////////////////
			} //end If
			else
			{
				SyllableArray.erase(SyllableArray.begin()+j);
				dwSize--;
				j--;
			}
		}// End for
		
		dwBegin = dwEnd =0;
		///////////////////////////////////////////////////
		// Analysing the context of the syllable	     //
		///////////////////////////////////////////////////

		for(i=0; i<dwSize; i++)
		{
			if((dwBegin == dwEnd)&&(dwEnd < dwSize -1))
			{
				//int j;
				j=1;
				for(;;)
				{
					csSyllable = SyllableArray.at(i+j).cUnitName;
					if((csSyllable=="SIL")||(csSyllable=="SILS")||(csSyllable=="SILP")||(dwEnd == (dwSize - 1))||((i+j)==(dwSize-1)))
					{
						dwEnd = i+j;
						nPhraseLenInSyl = dwEnd - dwBegin-1;
						break;
					}
					j++;
				}
			}
					
			if(i==0)
			{
				if((SyllableArray.at(i).cUnitName=="SILP")||(SyllableArray.at(i).cUnitName=="SILS"))
				{
					SyllableArray.at(i).cLeftUnitName = "NULL";
					dwBegin = i;
				}
				else
				{
					SyllableArray.at(i).cLeftUnitName = "SILS";
					dwBegin = -1;
				}
				SyllableArray.at(i).csLeftPhone = "NUL";
				SyllableArray.at(i).csLeftPhoneType = "NUL";
				SyllableArray.at(i).bLeftTone = 0;
			}
			else 
			{
				csSyllable = SyllableArray.at(i).cUnitName;
				SyllableArray.at(i).cLeftUnitName = SyllableArray.at(i-1).cUnitName;
				SyllableArray.at(i).bLeftTone	 = SyllableArray.at(i-1).bTone;
						
				if((SyllableArray.at(i-1).cUnitName=="SILP")||(SyllableArray.at(i-1).cUnitName=="SILS")||(SyllableArray.at(i-1).cUnitName=="SIL"))
				{
					SyllableArray.at(i).csLeftPhone = "NUL";
					SyllableArray.at(i).csLeftPhoneType = "NUL";
				}
				else 
					for(int nSound =3; nSound >=0; nSound--)
					if(SyllableArray.at(i-1).csSound[nSound].Compare("NUL")) 
					{
						SyllableArray.at(i).csLeftPhone = SyllableArray.at(i-1).csSound[nSound];
						SyllableArray.at(i).csLeftPhoneType = SyllableArray.at(i-1).csSoundType[nSound];
						break;
					}
									
				if((csSyllable =="SIL")||(csSyllable =="SILS")||(csSyllable =="SILP")) dwBegin = dwEnd;
										
			}
			if(i < dwSize -1) 
			{
				SyllableArray.at(i).cRightUnitName = SyllableArray.at(i+1).cUnitName;
				SyllableArray.at(i).bRightTone = SyllableArray.at(i+1).bTone;
				
				if((SyllableArray.at(i+1).cUnitName=="SILP")||(SyllableArray.at(i+1).cUnitName=="SILS")||(SyllableArray.at(i+1).cUnitName=="SIL"))
				{
					SyllableArray.at(i).csRightPhone = "NUL";
					SyllableArray.at(i).csRightPhoneType = "NUL";
				}
				else
					for(int nSound =0; nSound <=3; nSound++)
					if(SyllableArray.at(i+1).csSound[nSound].Compare("NUL")) 
					{
						SyllableArray.at(i).csRightPhone = SyllableArray.at(i+1).csSound[nSound];
						SyllableArray.at(i).csRightPhoneType = SyllableArray.at(i+1).csSoundType[nSound];
						break;
					}
			}
			else 
			{
				SyllableArray.at(i).cRightUnitName = "NULL";
				SyllableArray.at(i).bRightTone = 0;
				SyllableArray.at(i).csRightPhone = "NUL";
				SyllableArray.at(i).csRightPhoneType = "NUL";
			}
					
			SyllableArray.at(i).wIndex = i - dwBegin;
			SyllableArray.at(i).nPhraseLen = nPhraseLenInSyl;
					
		}

		///////////////////////////////////////////////////
		// End of analysing the context of the syllable	 //
		///////////////////////////////////////////////////
		float Length;
		int node;
		for(j=0; j<dwSize;j++)	
		{
			SyllableElement = SyllableArray.at(j);
			
			if((SyllableElement.cUnitName == "SILP")||(SyllableElement.cUnitName =="SILS"))
				SyllableArray.at(j).dwUnitLen = 6400;
			else
			{
				if(SyllableElement.cUnitName == "SIL")
				SyllableArray.at(j).dwUnitLen = 3000;
				else
				{
					SyllableArray.at(j).PosInPhrase = SyllableArray.at(j).PosInSyntagm;
					DurationModel(SyllableElement, Length, node);
					SyllableArray.at(j).dwUnitLen = int(Length)*(1/fSpeakingRate)*fSpeakingRate;//*1.1f;//*1.2f;
					SyllableArray.at(j).dwEnergy	 = EnergyModel(SyllableElement);
				}
			}
		}

		F0ContourGeneration(SyllableArray);

		//Empty();
		for(j=0; j<dwSize;j++)
		{
			SyllableElement = SyllableArray.at(j);
			csTemp.Empty();
			////////////////////////////////////////////////
			
			SYLLABLESTRUCT *psst;
			psst = new SYLLABLESTRUCT;
			if(!ParseSylInfo(SyllableElement,psst))
			{
				Empty();
				delete psst;
				return FALSE;
			}
			if((BTypeOfPhrase == 1)&&(SyllableElement.PosInPhrase ==1))
			{
				float fDelta, fStep;
				fDelta = 0.1f;
				fStep = fDelta/ SyllableElement.numOfF0;
				for(int nF0Pos = 0; nF0Pos < SyllableElement.numOfF0; nF0Pos++)
					psst->nFo[nF0Pos] = int(psst->nFo[nF0Pos]*(1+ float(fStep*nF0Pos)));
				psst->nEnergy = int(SyllableElement.dwEnergy*1.25f);
				if(psst->nEnergy >32) psst->nEnergy =32;

			}
			m_pdwSyl.push_back((DWORD)psst);

			////////////////////////////////////////////////
			//Sua lai de ghi ra file day du thong tin cung cap cho qua trinh tim kiem va ghep noi.19/3/2009

			if((SyllableElement.cUnitName !="SILP")&&(SyllableElement.cUnitName !="SILS")&&(SyllableElement.cUnitName !="SIL"))
			{				
		
				csTemp.Format("%d ", SyllableElement.bNumOfSubUnit);//Them vao so luong cua SubUnit
				csTemp1 = csTemp;
				csTemp.Empty();
				// Them vao ten cac don vi am
				for(i=0; i< SyllableElement.bNumOfSubUnit; i++)
				csTemp = csTemp + SyllableElement.csSubUnit[i]+ ' ';
							
				csTemp1 += csTemp;
				csTemp.Empty();
				csTemp.Format("%d ", SyllableElement.dwUnitLen*BYTESPERSAMPLE);//Them vao *BYTESPERSAMPLE
				csTemp1 = csTemp1 + csTemp;
				csTemp.Empty();
				
				csTemp.Format("%d ", SyllableElement.bTone);// Them vao bTone
				csTemp1 += csTemp;
				csTemp.Empty();
				csTemp.Format("%d ", (int)SyllableElement.dwEnergy);// Them vao gia tri nang luong
				csTemp1 += csTemp;
				csTemp.Empty();
				csTemp.Format("%d ", SyllableElement.numOfF0);// Them vao gia tri cua 
				csTemp1 += csTemp;
				csTemp.Empty();

			//	for(i=0;i< SyllableElement.bNumOfSubUnit; i++)// Them vao gia tri cua mang bUnitIndex[]
			//	{
			//	  csTemp.Format("%d ",1);
			//	  csTemp1 += csTemp;
			//	  csTemp.Empty();
			//	
			//	}
				csF0.Empty();

				for(i=0; i< SyllableElement.numOfF0; i++)// Chinh sua lai viec ghi ra mang F0
				{
					int nF0Value;
					//nF0Value = int(CPsola::nF0_Begin*SyllableElement.fF0[i]);
					nF0Value = int(SyllableElement.fF0[i] * nF0_Begin *fRegister);
					if(nF0Value < int(0.5f* nF0_Begin)) nF0Value = int(0.55f* nF0_Begin);
					csTemp.Format("%d", nF0Value);
					if(i!=SyllableElement.numOfF0-1)
						csF0 = csF0 + csTemp + ' ';
					else
						csF0 = csF0 + csTemp; 
					

				}

				csTemp1 = csTemp1 + csF0 + "\n";
			}
			else
			{
				csTemp1.Format("_ %d\n", SyllableElement.dwUnitLen*BYTESPERSAMPLE);
			}

			/*csTemp.Format(" %d\t%s\t%d\t%s\t%s\t%s\t%s\t%4.2f %4.2f %4.2f\t%d\t%d\t%s\t%s\t%d\t%d\t%s\t%s\t%s\t%s\n",j, SyllableElement.cUnitName, SyllableElement.bTone, 
				SyllableElement.csSoundType[0],SyllableElement.csSoundType[1],SyllableElement.csSoundType[2],SyllableElement.csSoundType[3],
				SyllableElement.PosInWord,SyllableElement.PosInSyntagm,SyllableElement.PosInPhrase,SyllableElement.bLeftTone,
				SyllableElement.bRightTone,SyllableElement.csLeftPhoneType,SyllableElement.csRightPhoneType, SyllableElement.dwUnitLen, node,
				SyllableElement.csSubUnit[0], SyllableElement.csSubUnit[1],SyllableElement.csSubUnit[2], SyllableElement.csSubUnit[3]);*/
			csOut = csOut + csTemp1;
		}
		SyllableArray.clear();

		}// End of while( nPhraseBegPos + 1 < nLen )
	
		
		#pragma region Exporting the prosodic information into file: Analysed Phrase.syn


		////////////////////////////////////////////////////////
		// Exporting the prosodic information into file: Analysed Phrase.syn
		/////////////////////////////////////////////////////////////////////
		FILE *fOut;
		if( (fOut = fopen(CsNameOfSynFile, "wt")) == NULL ) // .syn = synthesis: this file contains all of the prosodic information of the synthetic phrase.
		{
						
			///////////////////////////////////////
			/*		bao loi ra ngoai file debug	 */
			///////////////////////////////////////
			CStdStringA strOut;
			strOut = "Can not open this file: Analysed Phrase.syn";
			//CPsola::OutputLastError(strOut);
			////////////////////////////////////////
			return FALSE;
		}
		fwrite(csOut,csOut.GetLength(),1,fOut);
		fclose(fOut);

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////
		cs.Empty();
		cs = csOut;
	
		#pragma endregion Exporting the prosodic information into file: Analysed Phrase.syn
	} //if(CPsola::BAutoORHandF0 == TRUE) 

	else
	{
		Empty();
		SYLLABLESTRUCT *psst;
		i = -1;
		j = 0;
		cs.Remove('\r');
		nLen = cs.GetLength();
		//CString csMid;
		while( i + 1 < nLen )
		{
			i = cs.Find('\n',j);
			if(i == -1){
				if( nLen - j == 0) break;
				psst = new SYLLABLESTRUCT;
				psst->nNumberFo = 0;
				csMid = cs.Mid(j,nLen - j);
				csMid.Insert(0,' ');
				csMid.Insert(csMid.GetLength(),' ');
				csMid.Replace('\t',' ');
				while(csMid.Replace("  "," "));
				if(*((LPCTSTR)csMid + 1)==';'){
					delete psst;
					break;
				}
				if(csMid.GetLength() < 3){
					delete psst;
					break;
				}
				if(!ParseSylInfo(csMid,psst)){
					Empty();
					delete psst;
					return FALSE;
				}
				m_pdwSyl.push_back((DWORD)psst);
				break;
			}
			if( i - j == 0) {
				j = i + 1;
				continue;
			}

			psst = new SYLLABLESTRUCT;
			psst->nNumberFo = 0;
			csMid = cs.Mid(j,i-j);
			csMid.Insert(0,' ');
			csMid.Insert(csMid.GetLength(),' ');
			csMid.Replace('\t',' ');
			while(csMid.Replace("  "," "));
			if(*((LPCTSTR)csMid + 1)==';'){
				delete psst;
				j = i + 1;
				continue;
			}
			if(csMid.GetLength() < 3){
				delete psst;
				j = i + 1;
				continue;
			}
			if(!ParseSylInfo(csMid,psst)){
				Empty();
				delete psst;
				return FALSE;
			}
			m_pdwSyl.push_back((DWORD)psst);
			j = i + 1;
		}
	}
	return TRUE; 
}

/******************************************************************************************************************/
void CTextHandle::Empty()
{
	int i = 0;
	int nSize = m_pdwSyl.size();
	while( i < nSize)
	{
		if(((SYLLABLESTRUCT *)(m_pdwSyl.at(i)))->nNumberFo)
			delete[] ((SYLLABLESTRUCT *)(m_pdwSyl.at(i)))->nFo;
		delete (SYLLABLESTRUCT *)(m_pdwSyl.at(i));
		i++;		
	}
	m_pdwSyl.clear();
}

/******************************************************************************************************************/
void CTextHandle::RemoveAt(int i)
{
	if ((i>=0)&&(i<=m_pdwSyl.size()))	m_pdwSyl.erase(m_pdwSyl.begin()+i);
}
/******************************************************************************************************************/
//Neu stSyl.Flag co chua SYL_FOARRAY thi nguoi dung phai dam bao rang
//con tro stSyl.nFo tro den Buffer co do dai >= stSyl.nNumberFo * 4 (so byte danh cho kieu int)
//vi vay hay goi ham nay hai lan : Lan dau de lay ra stSyl.nNumberFo
//va lan thu hai moi lay ra stSyl.nFo
///////////////////////////////////////////////////
//			Bo xung ngay 16/10/2004				 //
//		Noi dung: them phan lay thong tin dp 3,4 //
///////////////////////////////////////////////////
BOOL CTextHandle::GetSylInfo(WORD wIndex,SYLLABLESTRUCT &stSyl)
{
	if(wIndex > m_pdwSyl.size()-1) return FALSE;
	SYLLABLESTRUCT *psst = (SYLLABLESTRUCT *)m_pdwSyl.at(wIndex);
	if(stSyl.wFlag & SYL_FIRSTUNIT)
	{
		strcpy(stSyl.cFirstAUnit,psst->cFirstAUnit);
		stSyl.bUnitIndex[0] = psst->bUnitIndex[0]; // Bo xung ngay 08 thang 12 nam 2005: lay chi so cua don vi am
	}
	if(stSyl.wFlag & SYL_SECONDUNIT&&(psst->nAUnit >= 2))
	{
		strcpy(stSyl.cSecondAUnit,psst->cSecondAUnit);
		stSyl.bUnitIndex[1] = psst->bUnitIndex[1]; // Bo xung ngay 08 thang 12 nam 2005: lay chi so cua don vi am
	}
	
	if(stSyl.wFlag &SYL_SYLLABLELEN)
		stSyl.nSyllableLen = psst->nSyllableLen;
	if(stSyl.wFlag & SYL_NUMOFUNIT)
		stSyl.nAUnit = psst->nAUnit;
	
	if(stSyl.wFlag & SYL_NUMBERFO)
		stSyl.nNumberFo = psst->nNumberFo;
	
	if(stSyl.wFlag & SYL_FOARRAY)
		memcpy(stSyl.nFo,psst->nFo,psst->nNumberFo * 4);
	//////////////////////////////////////////////////////////////////
	//	Sua doi ngay 31 thang 08 nam 2005							//
	//	Noi dung; them cac co SYL_TON, va cac lenh de lay gia tri	//
	//			  thanh dieu can tong hop							//
	//////////////////////////////////////////////////////////////////

	if((stSyl.wFlag & SYL_ENERGY)&&(stSyl.nNumberFo>0)&&(stSyl.wFlag & SYL_TON))
	{
		switch (stSyl.nNumberFo)
		{
			case 1: if((stSyl.nFo[0]>0) &&(stSyl.nFo[0]<=8)) 
					{
						stSyl.nNumberFo --;
						stSyl.nTon = stSyl.nFo[0];
						
						stSyl.nEnergy = 0;
					}
					else 
					{
						if((stSyl.nFo[0]>8) &&(stSyl.nFo[0]<=PSL_ENERGY_LEVELS)) // kiem tra nguong, de cho phep la F0
						{
							stSyl.nNumberFo --;
							stSyl.nEnergy = stSyl.nFo[0];
							stSyl.nTon	= 1; // mac dinh thanh dieu la thanh NGANG - LEVEL
						}
						/*else 
						{
							//stSyl.nEnergy =0;
							//stSyl.nTon	= 1;
						}*/ // Sua doi ngay 28 thang 11 nam 2005
					}
					break;
			case 2: if((stSyl.nFo[0] <=PSL_ENERGY_LEVELS)&&(stSyl.nFo[0]>0))// kiem tra nguong, de cho phep la F0
					{
						stSyl.nNumberFo --;
						stSyl.nEnergy = stSyl.nFo[0];
						for(int i=0; i<stSyl.nNumberFo; i++)
						stSyl.nFo[i] = stSyl.nFo[i+1];

						if((stSyl.nFo[1]>0)&&(stSyl.nFo[1]<=8))
						{
							stSyl.nNumberFo --;
							stSyl.nTon = stSyl.nFo[0];
							for(int i=0; i<stSyl.nNumberFo; i++)
								stSyl.nFo[i] = stSyl.nFo[i+1];
						}

					}
					else
					{
						stSyl.nEnergy = 0;
						stSyl.nTon = 0;
						/*stSyl.nNumberFo --;
						for(int i=0; i<stSyl.nNumberFo; i++)
						stSyl.nFo[i] = stSyl.nFo[i+1];*/// Sua doi ngay 28 thang 11 nam 2005
					}

					break;
			default: 
					if((stSyl.nFo[0] <=PSL_ENERGY_LEVELS)&&(stSyl.nFo[0]>0))// kiem tra nguong, de cho phep la F0
					{
						stSyl.nNumberFo --;
						stSyl.nEnergy = stSyl.nFo[0];
						for(int i=0; i<stSyl.nNumberFo; i++)
						stSyl.nFo[i] = stSyl.nFo[i+1];
					}
					else
					{
						stSyl.nEnergy = 0;
						stSyl.nTon = 0;
						
					}
					
					if(BSettingInputText == TRUE)// Adding 24/12/2006 for modeling F0contour automatically
					{
						stSyl.nTon = psst->nTon;
						stSyl.nEnergy = psst->nEnergy;
						//stSyl.nEnergy = 20;
					}
				
					break;
		}
	}
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////
//			Sua ngay 28 thang 10 nam 2004												 //
//			Noi dung: tao cho ham co tac dung phan tich cau truc syllable, biet co bao	 //
//					  nhieu thanh phan cau tao thanh syllable + cac thong tin khac		 //
///////////////////////////////////////////////////////////////////////////////////////////

BOOL CTextHandle::ParseSylInfo(CStdStringA &csOrg,SYLLABLESTRUCT *stSyl)
{
	//Tim ten cua diphone thu nhat
	int i = 0;
	int j = 1;
	int index = 0;
	CStdStringA cs = csOrg;
	CStdStringA csTemp; //csStrOut;
	///MessageBox(::AfxGetMainWnd()->m_hWnd,"1"+cs+"1",0,0);

	stSyl->nAUnit = 0;
	i = cs.Find(' ',j);	
	index = cs.Find(':',j);
	if( i - j > 4 ){
	
		if((i - j > 7) || (index == -1)|| (index -j >4))
		{
			this->m_nErrorCode = TH_UNITNOTFOUND;
			this->m_csError = "Fatal error in line : " + cs + "\n\n" + "AUnit : \"" + cs.Mid(j,i-j) + "\" not found";
			return FALSE;
		}
	}
	stSyl->bUnitIndex[0] = 1;
	if((index > j)&&(index < i))
	{
		csTemp = cs.Mid(index + 1, i - index -1);
		stSyl->bUnitIndex[0] = atoi(LPCSTR(csTemp));
	} // Ket thuc bo xung

	if ((index == -1)||(index > i)) index = i;// Sua doi ngay 08 thang 12 nam 2005


	memcpy(stSyl->cFirstAUnit,(LPCTSTR)cs + j,index-j); // Sua doi ngay 08 thang 12 nam 2005
	stSyl->cFirstAUnit[index-j] = '\0';// Sua doi ngay 08 thang 12 nam 2005
	stSyl->nAUnit++;
	
	int nTemp = 0;

	//Truong hop la SILENCE
	if((i-j == 1) && (stSyl->cFirstAUnit[0] == '_'))
	{
		//Tinh tong tat ca so theo sau vao silence 
		cs.Delete(0,i+1);
		stSyl->nNumberFo = 0;
		stSyl->nFo = NULL;
		stSyl->cSecondAUnit[0]='\0';
		stSyl->nSyllableLen = 0;
		i=0;
		j=0;
		while((i = cs.Find(' ',j))!=-1)
		{
			nTemp = atoi((LPCTSTR)cs + j);
			if(!IsNumeric((LPCTSTR)cs + j,i-j)||(nTemp < 0)){
				this->m_nErrorCode = TH_SILENCELENNOTNUMERIC;
				this->m_csError = "Fatal error in line : " + csOrg + "\n\nSilence Len : \"" + cs.Mid(j,i-j) + "\" not matched";
				return FALSE;
			}
			stSyl->nSyllableLen += nTemp;
			j = i + 1;
		}
		stSyl->nSyllableLen *= BYTESPERSAMPLE;
		return TRUE;
	}

	//Neu khong phai SILENCE
	//Tim ten diphone thu hai
	//************************************ Sua doi ngay 09/02 *****************************************************//
	//**	Noi dung: Dam bao la mot don vi am cho vao cung co the bien doi duoc cac thanh dieu, do do co the	***//
	//**			  ket noi cac syllabe voi nhau cung nhu bien doi thanh dieu cua mot van tuy y				***//
	//*************************************************************************************************************//
	j = i + 1;
	i = cs.Find(' ',j);
	index = cs.Find(':',j); // bo xung 08 thang 12 nam 2006

	if(i == -1)// Kiem tra xem con thong tin phia truoc khong, neu co thi co the hoac la Don vi am ke tiep hoac la So
				// neu khong thi du lieu se khong co thong tin ve chieu dai syllabe va tan so
	
	{
		stSyl->nSyllableLen = 0;
		stSyl->nFo = NULL;
		stSyl->nNumberFo = 0;
		return TRUE;
	}
	else 
	{
		nTemp = atoi((LPCTSTR)cs + j);
		if(!IsNumeric((LPCTSTR)cs + j,i-j) || (nTemp < 0) )
		{
			if( i - j > 4 ) // Bo xung ngay 08 thang 12 nam 2005, cho phu hop voi cau truc moi
			{
				if((i - j > 7) || (index == -1)|| (index -j >4))
				{
					this->m_nErrorCode = TH_UNITNOTFOUND;
					this->m_csError = "Fatal error in line : " + cs + "\n\nAUnit : \"" + cs.Mid(j,i-j) + "\" not found";
					return FALSE;
				}
			}
			stSyl->bUnitIndex[1] = 1;
			if((index > j)&&(index < i)) // Bo xung ngay 08 thang 12 nam 2005, cho phu hop voi cau truc moi
			{
				csTemp = cs.Mid(index + 1, i - index -1);
				stSyl->bUnitIndex[1] = atoi(LPCSTR(csTemp));
			} // Ket thuc bo xung
			if ((index == -1)||(index > i)) index = i;// Sua doi ngay 08 thang 12 nam 2005
			memcpy(stSyl->cSecondAUnit,(LPCTSTR)cs + j,index-j);
			stSyl->cSecondAUnit[index-j] = '\0';
			stSyl->nAUnit++;

		}
		else
		{
			stSyl->nSyllableLen = nTemp * BYTESPERSAMPLE;

			//Tim chuoi Fo
			cs.Delete(0,i + 1);
			stSyl->nNumberFo = cs.Replace(' ','\t');
			if(stSyl->nNumberFo == 0){
				stSyl->nFo = NULL;
				return TRUE;
			}
			stSyl->nFo = new int [stSyl->nNumberFo];
			i=0;
			j=0;
			int nCount = 0;
			while((i = cs.Find('\t',j))!=-1)
			{
				nTemp = atoi((LPCTSTR)cs + j);
				if(!IsNumeric((LPCTSTR)cs + j,i-j)||(nTemp <= 0)){
					delete[] stSyl->nFo;
					this->m_nErrorCode = TH_FONOTNUMERIC;
					this->m_csError = "Fatal error in line : " + csOrg + "\n\nFo Value : \"" + cs.Mid(j,i-j) + "\" not matched";
					return FALSE;
				}
				stSyl->nFo[nCount] = nTemp;
				nCount++;
				j = i + 1;
			}
			return TRUE;
		}

	}


	///////////////////////////////////////////////////////
	//				Bo xung cac diphone khac			///
	///////////////////////////////////////////////////////

	j = i + 1;
	i = cs.Find(' ',j);
	index = cs.Find(':',j); // bo xung 08 thang 12 nam 2006
	
	if(i == -1) // Kiem tra xem con thong tin phia truoc khong, neu co thi co the hoac la Don vi am ke tiep hoac la So
				// neu khong thi du lieu se khong co thong tin ve chieu dai syllabe va tan so
	{
		/*this->m_nErrorCode = TH_UNITNOTPAIR;
		this->m_csError = "Fatal error in line : " + cs + "\n\n" + "At AUnit Pair : \"" + csOrg + "\"";
		return FALSE;*/
		stSyl->nSyllableLen = 0;
		stSyl->nFo = NULL;
		stSyl->nNumberFo = 0;
		return TRUE;
	}
	else 
	{
		nTemp = atoi((LPCTSTR)cs + j);
		if(!IsNumeric((LPCTSTR)cs + j,i-j) || (nTemp < 0) )
		{
			if( i - j > 4 )
			{
				if((i - j > 7) || (index == -1)|| (index -j >4)) // Bo xung ngay 08 thang 12 nam 2005, cho phu hop voi cau truc moi
				{
					this->m_nErrorCode = TH_UNITNOTFOUND;
					this->m_csError = "Fatal error in line : " + cs + "\n\nAUnit : \"" + cs.Mid(j,i-j) + "\" not found";
					return FALSE;
				}
			}
			stSyl->bUnitIndex[2] = 1;
			if((index > j)&&(index < i)) // Bo xung ngay 08 thang 12 nam 2005, cho phu hop voi cau truc moi
			{
				csTemp = cs.Mid(index + 1, i - index -1);
				stSyl->bUnitIndex[2] = atoi(LPCSTR(csTemp));
			} // Ket thuc bo xung
			if ((index == -1)||(index > i)) index = i;// Sua doi ngay 08 thang 12 nam 2005
			memcpy(stSyl->cThirdAUnit,(LPCTSTR)cs + j,index-j);
			stSyl->cThirdAUnit[index-j] = '\0';
			stSyl->nAUnit++;

		}
		else
		{
			stSyl->nSyllableLen = nTemp * BYTESPERSAMPLE;

		//Tim chuoi Fo
			cs.Delete(0,i + 1);
			stSyl->nNumberFo = cs.Replace(' ','\t');
			if(stSyl->nNumberFo == 0){
				stSyl->nFo = NULL;
				return TRUE;
			}
			stSyl->nFo = new int [stSyl->nNumberFo];
			i=0;
			j=0;
			int nCount = 0;
			while((i = cs.Find('\t',j))!=-1)
			{
				nTemp = atoi((LPCTSTR)cs + j);
				if(!IsNumeric((LPCTSTR)cs + j,i-j)||(nTemp <= 0)){
					delete[] stSyl->nFo;
					this->m_nErrorCode = TH_FONOTNUMERIC;
					this->m_csError = "Fatal error in line : " + csOrg + "\n\nFo Value : \"" + cs.Mid(j,i-j) + "\" not matched";
					return FALSE;
				}
				stSyl->nFo[nCount] = nTemp;
				nCount++;
				j = i + 1;
			}
			return TRUE;
		}

	}
	
	// Nhap vao don vi am thu 4 neu co. maximum co 4 don vi am
	j = i + 1;
	i = cs.Find(' ',j);
	index = cs.Find(':',j); // bo xung 08 thang 12 nam 2006
	if(i == -1)// Kiem tra xem con thong tin phia truoc khong, neu co thi co the hoac la Don vi am ke tiep hoac la So
				// neu khong thi du lieu se khong co thong tin ve chieu dai syllabe va tan so
	{
		stSyl->nSyllableLen = 0;
		stSyl->nFo = NULL;
		stSyl->nNumberFo = 0;
		return TRUE;
	}
	else 
	{
		nTemp = atoi((LPCTSTR)cs + j);
		if(!IsNumeric((LPCTSTR)cs + j,i-j) || (nTemp < 0) )
		{
			if( i - j > 4 )
			{
				if((i - j > 7) || (index == -1)|| (index -j >4)) // Bo xung ngay 08 thang 12 nam 2005, cho phu hop voi cau truc moi
				{
					this->m_nErrorCode = TH_UNITNOTFOUND;
					this->m_csError = "Fatal error in line : " + cs + "\n\nAUnit : \"" + cs.Mid(j,i-j) + "\" not found";
					return FALSE;
				}
			}
			stSyl->bUnitIndex[3] = 1;
			if((index > j)&&(index < i)) // Bo xung ngay 08 thang 12 nam 2005, cho phu hop voi cau truc moi
			{
				csTemp = cs.Mid(index + 1, i - index -1);
				stSyl->bUnitIndex[3] = atoi(LPCSTR(csTemp));
			} // Ket thuc bo xung
			if ((index == -1)||(index > i)) index = i;// Sua doi ngay 08 thang 12 nam 2005
			memcpy(stSyl->cFourthAUnit,(LPCTSTR)cs + j,index-j);
			stSyl->cFourthAUnit[index-j] = '\0';
			stSyl->nAUnit++;
			//this->m_nErrorCode = TH_LENNOTNUMERIC;
			//this->m_csError = "Fatal error in line : " + csOrg + "\n\nSyllable Len : \"" + cs.Mid(j,i-j) + "\" not matched";
			//return FALSE;
		}
		else
		{
			stSyl->nSyllableLen = nTemp * BYTESPERSAMPLE;

		//Tim chuoi Fo
			cs.Delete(0,i + 1);
			stSyl->nNumberFo = cs.Replace(' ','\t');
			if(stSyl->nNumberFo == 0){
				stSyl->nFo = NULL;
				return TRUE;
			}
			stSyl->nFo = new int [stSyl->nNumberFo];
			i=0;
			j=0;
			int nCount = 0;
			while((i = cs.Find('\t',j))!=-1)
			{
				nTemp = atoi((LPCTSTR)cs + j);
				if(!IsNumeric((LPCTSTR)cs + j,i-j)||(nTemp <= 0)){
					delete[] stSyl->nFo;
					this->m_nErrorCode = TH_FONOTNUMERIC;
					this->m_csError = "Fatal error in line : " + csOrg + "\n\nFo Value : \"" + cs.Mid(j,i-j) + "\" not matched";
					return FALSE;
				}
				stSyl->nFo[nCount] = nTemp;
				nCount++;
				j = i + 1;
			}
			return TRUE;
		}

	}
	///////////////////////////////////////////////////////

	//Tim do dai Syllable
	j = i + 1;
	i = cs.Find(' ',j);
	if(i == -1){
		stSyl->nSyllableLen = 0;
		stSyl->nFo = NULL;
		stSyl->nNumberFo = 0;
		return TRUE;
	}

	nTemp = atoi((LPCTSTR)cs + j);
	if(!IsNumeric((LPCTSTR)cs + j,i-j) || (nTemp < 0) )
	{
		this->m_nErrorCode = TH_LENNOTNUMERIC;
		this->m_csError = "Fatal error in line : " + csOrg + "\n\nSyllable Len : \"" + cs.Mid(j,i-j) + "\" not matched";
		return FALSE;
	}
	
	stSyl->nSyllableLen = nTemp * BYTESPERSAMPLE;

	//Tim chuoi Fo
	cs.Delete(0,i + 1);
	stSyl->nNumberFo = cs.Replace(' ','\t');
	if(stSyl->nNumberFo == 0){
		stSyl->nFo = NULL;
		return TRUE;
	}
	stSyl->nFo = new int [stSyl->nNumberFo];
	i=0;
	j=0;
	int nCount = 0;
	while((i = cs.Find('\t',j))!=-1)
	{
		nTemp = atoi((LPCTSTR)cs + j);
		if(!IsNumeric((LPCTSTR)cs + j,i-j)||(nTemp <= 0)){
			delete[] stSyl->nFo;
			this->m_nErrorCode = TH_FONOTNUMERIC;
			this->m_csError = "Fatal error in line : " + csOrg + "\n\nFo Value : \"" + cs.Mid(j,i-j) + "\" not matched";
			return FALSE;
		}
		stSyl->nFo[nCount] = nTemp;
		nCount++;
		j = i + 1;
	}
	return TRUE;
}

int CTextHandle::GetSylCount()
{
	return m_pdwSyl.size();
}

void CTextHandle::UpdateSylInfo(int index, SYLLABLESTRUCT Syllable)
{
	//strcpy(((SYLLABLESTRUCT*)(m_pdwSyl.ElementAt(index)))->cFirstAUnit,Syllable.cFirstAUnit);
	((SYLLABLESTRUCT*)(m_pdwSyl.at(index)))->bUnitIndex[0] = Syllable.bUnitIndex[0];

	if(Syllable.nAUnit>=2)
	{
	//	strcpy(((SYLLABLESTRUCT*)(m_pdwSyl.ElementAt(index)))->cSecondAUnit,Syllable.cSecondAUnit);
		((SYLLABLESTRUCT*)(m_pdwSyl.at(index)))->bUnitIndex[1] = Syllable.bUnitIndex[1];
	}
	if(Syllable.nAUnit>=3)
	{
	//	strcpy(((SYLLABLESTRUCT*)(m_pdwSyl.ElementAt(index)))->cThirdAUnit,Syllable.cThirdAUnit);
		((SYLLABLESTRUCT*)(m_pdwSyl.at(index)))->bUnitIndex[2] = Syllable.bUnitIndex[2];
	}
	if(Syllable.nAUnit==4)
	{
	//	strcpy(((SYLLABLESTRUCT*)(m_pdwSyl.ElementAt(index)))->cFourthAUnit,Syllable.cFourthAUnit);
		((SYLLABLESTRUCT*)(m_pdwSyl.at(index)))->bUnitIndex[3] = Syllable.bUnitIndex[3];
	}


}

BOOL CTextHandle::SyllableAnalysis(UNITINFOFULL &DicSyllable)
{


	BYTE bTone;
	int j;
	int nNumOfVowel = VowelArray.size();

	float	PosInPhrase,PosInWord, PosInSyntagm;
	BOOL	Stress;
	
	CStdStringA csSyllable;
	csSyllable	= DicSyllable.cUnitName;
	PosInPhrase = DicSyllable.PosInPhrase;
	PosInSyntagm= DicSyllable.PosInSyntagm;
	PosInWord	= DicSyllable.PosInWord;
	Stress		= DicSyllable.Stress;
	//////////////////////////////////////////////////
	//Begin analyzing the componants of the syllable
	//			01. Tone
	//			02.	phoneme
	//			03. phoneme type
	/////////////////////////////////////////////////
	for(BYTE k=0; k<4;k++)
	{
		DicSyllable.csSound[k] = "NUL";
		DicSyllable.csSoundType[k] = "NUL";
	}
	DicSyllable.bNumOfSound = 0;
	if((csSyllable =="SIL")|| (csSyllable =="SILP")||(csSyllable =="SILS")) 
	{
		bTone = 0;
		//DicSyllable.cUnitName = csSyllable;
	}
	else
	{
		for(j=0; j< nNumOfVowel; j++)
		{
			int nFound = csSyllable.Find(VowelArray.at(j),0);
			if(nFound== -1) bTone = 1;
			else 
			{
				bTone = ToneArray.at(j);
				if (bTone == 5)
				{
					BYTE SylLen=0,posTemp=0;
					SylLen = csSyllable.GetLength();
					posTemp = csSyllable.Find("ch",1);
					if((csSyllable.at(SylLen-1) =='c')||(csSyllable.at(SylLen-1) =='t')
							||(csSyllable.at(SylLen-1) =='p')||(posTemp == (SylLen-2)))
						bTone = 7;
				}
				if (bTone == 6)
				{
					BYTE SylLen=0,posTemp=0;
					SylLen = csSyllable.GetLength();
					posTemp = csSyllable.Find("ch",1);

					if((csSyllable.at(SylLen-1) =='c')||(csSyllable.at(SylLen-1) =='t')
						||(csSyllable.at(SylLen-1) =='p')||(posTemp == (SylLen-2)))
						bTone = 8;
				}
				break;
			}
		}
		/////////////////////////////////////////////////////////
		// Get the information of the struture of syllables
		/////////////////////////////////////////////////////////
		
		for(j=0; j< DicSyllableArray.size(); j++)
		{
			if(csSyllable == DicSyllableArray.at(j).cUnitName)
			{
				DicSyllable = DicSyllableArray.at(j);
				break;
			}
		}
		if(j==DicSyllableArray.size()) 
		{
			///////////////////////////////////////
			/*		bao loi ra ngoai file debug	 */
			///////////////////////////////////////
			CStdStringA strOut;
			strOut = "The syllable: \"" + csSyllable +"\" does not exist in the dictionary";
			//CPsola::OutputLastError(strOut);
			////////////////////////////////////////
			//DicSyllable.cUnitName = csSyllable;
			return FALSE;
		}
		/////////////////////////////////////////////////////////
		// End of Adding 30/08/2006 
		// Get the information of the struture of syllables
		/////////////////////////////////////////////////////////
		SyllableStructureAnalyse(DicSyllable);
	}
	DicSyllable.PosInPhrase	= PosInPhrase;
	DicSyllable.PosInSyntagm= PosInSyntagm;
	DicSyllable.PosInWord	= PosInWord;
	DicSyllable.Stress		= Stress;
	DicSyllable.bTone = bTone;

	return TRUE;

}

BOOL CTextHandle::LoadDictionary()
{
	FILE *fp;
	////////////////////////////////////////////////
	// Take a list of syllable in the dictionary and their prononciation
	CStdStringA csFilename;
	csFilename = CsDirectoryOfFile + "PronunciationDictionary.dic";
    //csFilename = cocos2d::CCFileUtils::fullPathFromRelativePath("PronunciationDictionary.dic");
	//if( (fp = fopen("C:\\Documents and Settings\\Tran Do Dat\\My Documents\\Doctorat au Vietnam\\TDPSOLA MICA\\PronunciationDictionary.dic", "rt")) == NULL ) 
	if( (fp = fopen(csFilename, "rt")) == NULL ) 
	{
		///////////////////////////////////////
		/*		bao loi ra ngoai file debug	 */
		///////////////////////////////////////
		CStdStringA strOut;
		strOut = "Can not open file: PronunciationDictionary.dic";
		//CCLog(strOut.c_str());
		FILE* fp = fopen(CsNameOfDebugFile,"a");
		fputs(strOut, fp);
		fclose(fp);
		////////////////////////////////////////
		
		return FALSE;
	}

	UNITINFOFULL DicSyllable;
		
	CStdStringA csText, csInfo, csTemp;
	int nNumOfSylInDic =0;
	
	fseek(fp,0,SEEK_SET);
	fseek(fp,0,SEEK_END);
	
	long lSizeOfFile = ftell(fp);
	fseek(fp,0,SEEK_SET);
	
	char *Buff;
	Buff = new char[lSizeOfFile+1];
		
	fread(Buff,lSizeOfFile,1,fp);
	Buff[lSizeOfFile] = NULL;

	csText.Format("%s",Buff+3);
	csText.TrimLeft();
	csText.TrimRight();
	lSizeOfFile = csText.GetLength();

	delete[] Buff;

	long lBegPos=0, lEndPos=0, lLastTabPos;
	int nStart=0,nEnd=0;
		
	fclose(fp);

	lLastTabPos = csText.ReverseFind('\t');
		
	for(;;)
	{
		//if(lEndPos >=lLastTabPos) break;
		lEndPos = csText.Find('\n',lBegPos+1);
		if((lEndPos == -1)||(lEndPos >=lLastTabPos)) 
			csInfo = csText.Mid(lBegPos, lSizeOfFile - lBegPos);
		else	
			csInfo = csText.Mid(lBegPos, lEndPos - lBegPos);
		
		nEnd = csInfo.Find('\t',0);
		csTemp = csInfo.Mid(0,nEnd);
		csTemp.TrimLeft();
		csTemp.TrimRight();
		DicSyllable.cUnitName = csTemp;
		nStart = nEnd;

		BYTE bNumOfSound;
		bNumOfSound=0;
		for(;;)
		{
			nEnd = csInfo.Find(' ',nStart+1);
			if(nEnd ==-1) 
			{
				csTemp = csInfo.Mid(nStart,csInfo.GetLength() - nStart);
				csTemp.TrimLeft();
				csTemp.TrimRight();
				DicSyllable.csSound[bNumOfSound] = csTemp;
				bNumOfSound++;
				break;
			}
			csTemp = csInfo.Mid(nStart,nEnd - nStart);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			DicSyllable.csSound[bNumOfSound] = csTemp;
			bNumOfSound++;
			nStart = nEnd;
		}
			
		DicSyllable.bNumOfSound = bNumOfSound;
		
		DicSyllableArray.push_back(DicSyllable);
		
		nNumOfSylInDic++;
		if((lEndPos == -1)||(lEndPos >=lLastTabPos)) break;
		lBegPos = lEndPos;
	}

	//////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////

	return TRUE;

}

void CTextHandle::SyllableStructureAnalyse(UNITINFOFULL &SylOUT)
{
	UNITINFOFULL SylIN;
	SylIN = SylOUT;
	int i,j;
	for(i =0;i<SylIN.bNumOfSound; i++)
	{
		for(j=0;j<PhoneArray.size();j++)
			if(SylIN.csSound[i] == PhoneArray.at(j).csPhoneId)
				SylIN.csSoundType[i] = PhoneArray.at(j).csPhoneType;
	}
	
	

	
	switch (SylIN.bNumOfSound)
	{
	case 4:
		SylOUT = SylIN;
		break;
	case 1:
		SylOUT.csSound[0] = "NUL";
		SylOUT.csSound[1] = "NUL";
		SylOUT.csSound[2] = SylIN.csSound[0];
		SylOUT.csSound[3] = "NUL";
		
		SylOUT.csSoundType[0] = "NUL";
		SylOUT.csSoundType[1] = "NUL";
		SylOUT.csSoundType[2] = SylIN.csSoundType[0];
		SylOUT.csSoundType[3] = "NUL";
		break;
	case 2:
		for(j =0; j< PhoneArray.size()- NUMOFFINALSOUNDS;j++)
			if(SylIN.csSound[0] == PhoneArray.at(j).csPhoneId)
			{
				if(j < NUMOFINITIALCONSONANTS)
				{
					SylOUT.csSound[0] = SylIN.csSound[0];
					SylOUT.csSound[1] = "NUL";
					SylOUT.csSound[2] = SylIN.csSound[1];
					SylOUT.csSound[3] = "NUL";

					SylOUT.csSoundType[0] = SylIN.csSoundType[0];
					SylOUT.csSoundType[1] = "NUL";
					SylOUT.csSoundType[2] = SylIN.csSoundType[1];
					SylOUT.csSoundType[3] = "NUL";
				}
				if(j== NUMOFINITIALCONSONANTS )
				{
					SylOUT.csSound[0] = "NUL";
					SylOUT.csSound[1] = SylIN.csSound[0];
					SylOUT.csSound[2] = SylIN.csSound[1];
					SylOUT.csSound[3] = "NUL";

					SylOUT.csSoundType[0] = "NUL";
					SylOUT.csSoundType[1] = SylIN.csSoundType[0];
					SylOUT.csSoundType[2] = SylIN.csSoundType[1];
					SylOUT.csSoundType[3] = "NUL";
				}
				if(j> NUMOFINITIALCONSONANTS )
					{
					SylOUT.csSound[0] = "NUL";
					SylOUT.csSound[1] = "NUL";
					SylOUT.csSound[2] = SylIN.csSound[0];
					SylOUT.csSound[3] = SylIN.csSound[1];

					SylOUT.csSoundType[0] = "NUL";
					SylOUT.csSoundType[1] = "NUL";
					SylOUT.csSoundType[2] = SylIN.csSoundType[0];
					SylOUT.csSoundType[3] = SylIN.csSoundType[1];
				}
				break;
			}
		break;
	case 3:
		for(j =0; j<= NUMOFINITIALCONSONANTS;j++)
		{
			//CString csID;
			//int ntet = PhoneArray.size();
			//csID = PhoneArray.at(j).csPhoneId;
			if(SylIN.csSound[0] == PhoneArray.at(j).csPhoneId)
			{
				if(j < NUMOFINITIALCONSONANTS)
				{
					SylOUT.csSound[0] = SylIN.csSound[0];
					
					SylOUT.csSoundType[0] = SylIN.csSoundType[0];
					
					if(SylIN.csSound[1]=="w")
					{
						SylOUT.csSound[1] = SylIN.csSound[1];
						SylOUT.csSound[2] = SylIN.csSound[2];
						SylOUT.csSound[3] = "NUL";

						SylOUT.csSoundType[1] = SylIN.csSoundType[1];
						SylOUT.csSoundType[2] = SylIN.csSoundType[2];
						SylOUT.csSoundType[3] = "NUL";
					}
					else
					{
						SylOUT.csSound[1] = "NUL";
						SylOUT.csSound[2] = SylIN.csSound[1];
						SylOUT.csSound[3] = SylIN.csSound[2];

						SylOUT.csSoundType[1] = "NUL";
						SylOUT.csSoundType[2] = SylIN.csSoundType[1];
						SylOUT.csSoundType[3] = SylIN.csSoundType[2];
					}

				}
				if(j== NUMOFINITIALCONSONANTS )
				{
					SylOUT.csSound[0] = "NUL";
					SylOUT.csSound[1] = SylIN.csSound[0];
					SylOUT.csSound[2] = SylIN.csSound[1];
					SylOUT.csSound[3] = SylIN.csSound[2];

					SylOUT.csSoundType[0] = "NUL";
					SylOUT.csSoundType[1] = SylIN.csSoundType[0];
					SylOUT.csSoundType[2] = SylIN.csSoundType[1];
					SylOUT.csSoundType[3] = SylIN.csSoundType[2];
				}
				
				break;
			}
		}
		break;
		
	}

}

BOOL CTextHandle::LoadPhoneme()
{
	FILE *fp;
	UNITINFOFULL DicSyllable;
	
	CStdStringA csText, csInfo, csTemp, csListOfPhone;

	PHONESTRUCTINFO PhoneElement;
	
	int nNumOfSylInDic =0;
	CStdStringA csFileName;
	csFileName = CsDirectoryOfFile + "PhonemeVietnamienne.dic";
	Log("TextHandle:load phoneme file:%s",csFileName.c_str());
	if( (fp = fopen(csFileName, "rt")) == NULL ) 
		{
			csFileName = "Can not open file: PhonemeVietnamienne.dic";
			//CPsola::OutputLastError(csFileName);
			//CCLog(csFileName.c_str());
			
			return FALSE;
		}

	fseek(fp,0,SEEK_SET);
	fseek(fp,0,SEEK_END);
	long lSizeOfFile = ftell(fp);
	fseek(fp,0,SEEK_SET);
	
	char *Buff;
	Buff = new char[lSizeOfFile+1];
			
	fread(Buff,lSizeOfFile,1,fp);
	Buff[lSizeOfFile] = NULL;

	csText.Format("%s",Buff);
	csText.TrimLeft();
	csText.TrimRight();
	lSizeOfFile = csText.GetLength();

	delete[] Buff;

	long lBegPos=0, lEndPos=0;
	int nStart=0,nEnd=0;
		
	fclose(fp);
	
	///////////////////////////////////////////////////////////////
	// Get all of the initial consonants
	///////////////////////////////////////////////////////////////
	lBegPos = csText.Find("{PAD}",0);
	lEndPos = csText.Find("{EOPAD}",0);

	csListOfPhone = csText.Mid(lBegPos, lEndPos - lBegPos);
	
	lEndPos = csListOfPhone.Find('\n',0);
	lBegPos = lEndPos;
	
	for(;;)
		{
			lEndPos = csListOfPhone.Find('\n',lBegPos+1);
			if(lEndPos == -1) break;
				
			csInfo = csListOfPhone.Mid(lBegPos, lEndPos - lBegPos);
			nEnd = csInfo.Find('\t',0);
			csTemp = csInfo.Mid(0,nEnd);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			PhoneElement.csPhoneId = csTemp;
			
			nStart = nEnd;
			nEnd = csInfo.Find('\t',nStart + 1);
			csTemp = csInfo.Mid(nStart+1,nEnd - nStart);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			PhoneElement.csPhoneType = csTemp;

			nStart = nEnd;
			csTemp = csInfo.Mid(nStart+1,csInfo.GetLength()-nStart-1);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			PhoneElement.csCharId = csTemp;

			InPhoneArray.push_back(PhoneElement);
			//PhoneArray.Add(PhoneElement);
			//if(lEndPos == -1) break;
			lBegPos = lEndPos;
		//	nNumOfPhone[0] ++;
		}
	////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////
	// Get all of the semivowel
	///////////////////////////////////////////////////////////////
	PhoneElement.csPhoneId = "w";
	PhoneElement.csPhoneType = "SV";
	PhoneElement.csCharId	= "o";
	MiPhoneArray.push_back(PhoneElement);

	PhoneElement.csPhoneId = "w";
	PhoneElement.csPhoneType = "SV";
	PhoneElement.csCharId	= "u";
	MiPhoneArray.push_back(PhoneElement);
	
	//PhoneArray.Add(PhoneElement);
	//nNumOfPhone[1] = 1;
	
	///////////////////////////////////////////////////////////////
	// Get all of the vowels
	///////////////////////////////////////////////////////////////
	
	lBegPos = csText.Find("{NA}",0);
	lEndPos = csText.Find("{EONA}",0);

	csListOfPhone = csText.Mid(lBegPos, lEndPos - lBegPos);
	
	lEndPos = csListOfPhone.Find('\n',0);
	lBegPos = lEndPos;
	
	for(;;)
		{
			lEndPos = csListOfPhone.Find('\n',lBegPos+1);
			if(lEndPos == -1) 	break;
			
			csInfo = csListOfPhone.Mid(lBegPos, lEndPos - lBegPos);
			nEnd = csInfo.Find('\t',0);
			csTemp = csInfo.Mid(0,nEnd);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			PhoneElement.csPhoneId = csTemp;
			
			nStart = nEnd;
			nEnd = csInfo.Find('\t',nStart + 1);
			csTemp = csInfo.Mid(nStart+1,nEnd - nStart);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			PhoneElement.csPhoneType = csTemp;

			nStart = nEnd;
			csTemp = csInfo.Mid(nStart+1,csInfo.GetLength()-nStart-1);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			PhoneElement.csCharId = csTemp;
			
			VoArray.push_back(PhoneElement);
			//PhoneArray.Add(PhoneElement);
			//if(lEndPos == -1) break;

			lBegPos = lEndPos;
		//	nNumOfPhone[2] ++;
		}
	////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////
	// Get all of the final sounds
	///////////////////////////////////////////////////////////////
	
	lBegPos = csText.Find("{AC}",0);
	lEndPos = csText.Find("{EOAC}",0);

	csListOfPhone = csText.Mid(lBegPos, lEndPos - lBegPos);
	
	lEndPos = csListOfPhone.Find('\n',0);
	lBegPos = lEndPos;
	
	for(;;)
		{
			lEndPos = csListOfPhone.Find('\n',lBegPos+1);
			if(lEndPos == -1) break;
			
			csInfo = csListOfPhone.Mid(lBegPos, lEndPos - lBegPos);
			nEnd = csInfo.Find('\t',0);
			csTemp = csInfo.Mid(0,nEnd);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			PhoneElement.csPhoneId = csTemp;
			
			nStart = nEnd;
			nEnd = csInfo.Find('\t',nStart + 1);
			csTemp = csInfo.Mid(nStart+1,nEnd - nStart);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			PhoneElement.csPhoneType = csTemp;

			nStart = nEnd;
			csTemp = csInfo.Mid(nStart+1,csInfo.GetLength()-nStart-1);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			PhoneElement.csCharId = csTemp;

			FiPhoneArray.push_back(PhoneElement);
			//if(lEndPos == -1) break;
			lBegPos = lEndPos;
		//	nNumOfPhone[3] ++;
		}
	////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////
/*	// For testing 
	FILE *fOut;
	char text[256];
		if( (fOut = fopen("Phoneme.dic", "wt")) == NULL ) 
		{
			MessageBox("Can not open this file");
			return FALSE;
		}

		int TestdwSize = PhoneArray.size();

		for(int it=0; it<TestdwSize;it++)
		{
			PhoneElement = PhoneArray.at(it);
			sprintf(text,"%s \t %s \n",PhoneElement.csPhoneId, PhoneElement.csPhoneType);
			fwrite(text,strlen(text),1,fOut);
		}
		fclose(fOut);*/
	///////////////////////////////////////////////////////////
		
	return TRUE;

}

void CTextHandle::LoadVowelAndTone()
{
	FILE *fVow;
	////////////////////////////////////////////////////////////////////////////////////////////
	// Take the vowels with their tones
	////////////////////////////////////////////////////////////////////////////////////////////
	
	CStdStringA csFilename;
	CStdStringA csText, csInfo, csTemp;
	BYTE bTone;
	csFilename = CsDirectoryOfFile + "vowel_tone_ABC.dic";
    Log("TextHandle:load LoadVowelAndTone file:%s",csFilename.c_str());
	//csFilename = //cocos2d::CCFileUtils::fullPathFromRelativePath("vowel_tone_ABC.dic");
	if((fVow = fopen(csFilename, "rt")) == NULL ) 
		{
			csFilename = "Can not open file: vowel_tone.dic";
			//CPsola::OutputLastError(csFilename);
			//CCLog(csFilename.c_str());
			return;
		}

	fseek(fVow,0,SEEK_SET);
	fseek(fVow,0,SEEK_END);
	long lSizeOfFile = ftell(fVow);
	fseek(fVow,0,SEEK_SET);
	
	char *Buff;
	Buff = new char[lSizeOfFile+1];
			
	fread(Buff,lSizeOfFile,1,fVow);
	Buff[lSizeOfFile] = NULL;

	csText.Format("%s",Buff);
	csText.TrimLeft();
	csText.TrimRight();
	lSizeOfFile = csText.GetLength();

	delete[] Buff;

	long lBegPos=0, lEndPos=0;
	int nStart=0,nEnd=0;
		
	fclose(fVow);
	
	///////////////////////////////////////////////////////////////
	// Get all of the initial consonants
	///////////////////////////////////////////////////////////////
	lBegPos = csText.Find("{NA}",0);
	lEndPos = csText.Find("{EONA}",0);

	csText = csText.Mid(lBegPos, lEndPos - lBegPos);
	
	lEndPos = csText.Find('\n',0);
	lBegPos = lEndPos;
	
	for(;;)
		{
			lEndPos = csText.Find('\n',lBegPos+1);
			if(lEndPos == -1) break;
				
			csInfo = csText.Mid(lBegPos, lEndPos - lBegPos);
			nEnd = csInfo.Find('\t',0);
			csTemp = csInfo.Mid(0,nEnd);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			VowelArray.push_back(csTemp);
			
			nStart = nEnd;
			nEnd = csInfo.Find('\t',nStart + 1);
			csTemp = csInfo.Mid(nStart+1,nEnd-nStart);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			VowelNoToneArray.push_back(csTemp);
			
			nStart = nEnd;
			csTemp = csInfo.Mid(nStart+1,csInfo.GetLength()-nStart-1);
			csTemp.TrimLeft();
			csTemp.TrimRight();
			bTone = atoi(csTemp);
			ToneArray.push_back(bTone );
						
			lBegPos = lEndPos;
		}

/*	BYTE bTone;
	char text[255];
	while( !feof( fVow ) )
	{
		fscanf( fVow,"%s", text );
		if( feof( fVow ) ) break;
		VowelArray.Add(text);

		fscanf( fVow,"%s", text );
		if( feof( fVow ) ) break;
		VowelNoToneArray.Add(text);

		fscanf( fVow,"%d", &bTone );
		if( feof( fVow ) ) break;
			
		ToneArray.Add( bTone );
		if( feof(fVow) ) break;
	}
	fclose(fVow);*/
	return;
	//int nNumOfVowel = Vowel.GetSize();

}

BOOL CTextHandle::DurationModel(UNITINFOFULL Unit, float &Length, int &node)
{
	/*Rules for node 2*/
	float mean = 0;

	if( Unit.Stress == FALSE )
	{
		node = 2;
		mean = 2966.68f;
  
		/*Rules for node 3*/
		if(( Unit.csSoundType[3] == "CSU") || (Unit.csSoundType[3] == "NUL") || (Unit.csSoundType[3] == "SV" ))
		{
			node = 3;
			mean = 2786.49f;
			/*Rules for node 4*/
			if((Unit.PosInWord == 0) ||(Unit.PosInWord == 2.0f/3) || (Unit.PosInWord == 0.75f ))
			{
				node = 4;
				mean = 2695.16f;
				/*Rules for node 5*/
				if(( Unit.csSoundType[0] == "CSU") || (Unit.csSoundType[0] == "NUL" ))
				{
					node = 5;
					mean = 2481.76f;
					/*Rules for terminal node 1*/
					if((Unit.csRightPhoneType == "CFL") || (Unit.csRightPhoneType == "CSN") || 
						(Unit.csRightPhoneType == "CSV") || (Unit.csRightPhoneType == "VF" ))
					{
						node = -1;
						mean = 2263.42f;
					}
					/*Rules for terminal node 2*/

					if((Unit.csRightPhoneType == "CFU") ||(Unit.csRightPhoneType == "CFV") ||(Unit.csRightPhoneType == "CSU") ||
						   (Unit.csRightPhoneType == "SV") ||(Unit.csRightPhoneType == "VB") ||(Unit.csRightPhoneType == "VBC") ||
						   (Unit.csRightPhoneType == "VFC") ||(Unit.csRightPhoneType == "VM") ||(Unit.csRightPhoneType == "VMC"))
					{
						node = -2;
						mean = 2606.69f;
					}
				}
				/*Rules for node 6*/

				if((Unit.csSoundType[0] == "CFL") || (Unit.csSoundType[0] == "CFU") || (Unit.csSoundType[0] == "CFV") ||
					   (Unit.csSoundType[0] == "CSN") || (Unit.csSoundType[0] == "CSV"))
				{
					node = 6;
					mean = 2812.22f;
					/*Rules for node 7*/
					if((Unit.csRightPhoneType == "CFL") || (Unit.csRightPhoneType == "CFU") || (Unit.csRightPhoneType == "CFV") ||
						   (Unit.csRightPhoneType == "CSN") || (Unit.csRightPhoneType == "CSV") || ( Unit.csRightPhoneType == "VBC") ||
						   (Unit.csRightPhoneType == "VFC") || (Unit.csRightPhoneType == "VMC"))
					
					{
						node = 7;
						mean = 2701.01f;
						/*Rules for terminal node 3*/
						if(Unit.PosInPhrase <= 0.465f )
						{
							node = -3;
							mean = 2583.1f;
						}
						/*Rules for terminal node 3*/

						if(  Unit.PosInPhrase > 0.465f )
						{
							node = -4;
							mean = 2805.1f;
						}
					}
					/*Rules for terminal node 5*/
					if((Unit.csRightPhoneType == "CSU") || (Unit.csRightPhoneType == "SV") || 
						(Unit.csRightPhoneType == "VB") || (Unit.csRightPhoneType == "VF") || (Unit.csRightPhoneType == "VM"))
					{
						node = -5;
						mean = 3037.18f;
					}
				}
			}
			/*Rules for terminal node 6*/

			if((Unit.PosInWord == 0.5f) ||(Unit.PosInWord == 1 ))
			{
				node = -6;
				mean = 3289.2f;
			}
		}
		/*Rules for node 8*/

		if( Unit.csSoundType[3] == "CSN" )
		{
			node = 8;
			mean = 3306.31f;
			
			/*Rules for node 9*/

			if( (Unit.csRightPhoneType == "CFL") || (Unit.csRightPhoneType == "CFU") || (Unit.csRightPhoneType == "CSN") ||
				(Unit.csRightPhoneType == "CSV") || (Unit.csRightPhoneType == "SV")  || (Unit.csRightPhoneType == "VB")  ||
				(Unit.csRightPhoneType == "VBC") || (Unit.csRightPhoneType == "VF")  || (Unit.csRightPhoneType == "VMC")) 
			{
				node = 9;
				mean = 3103;
				/*Rules for node 10*/

				if( Unit.PosInPhrase <= 0.98f )
				{
					node = 10;
					mean = 3087.51f;
					/*Rules for terminal node 7*/
					if( (Unit.csRightPhoneType == "CFL") || (Unit.csRightPhoneType == "CSN") ||
						(Unit.csRightPhoneType == "SV")  || (Unit.csRightPhoneType == "VBC"))
					{
						node = -7;
						mean = 2950.54f;
					}
					/*Rules for node 11*/
					if( (Unit.csRightPhoneType == "CFU") || (Unit.csRightPhoneType == "CSV") ||
						(Unit.csRightPhoneType == "VB")  || (Unit.csRightPhoneType == "VF") ||(Unit.csRightPhoneType == "VMC")) 
					{
						node = 11;
						mean = 3191.23f;
						/*Rules for terminal node 8*/
						if( (Unit.PosInWord == 0) || ( Unit.PosInWord == 0.5) ||
						    (Unit.PosInWord == 2.0f/3) || (Unit.PosInWord == 0.75))
						{
							node = -8;
							mean = 3105.44f;
						}
						/*Rules for terminal node 9*/
						if(Unit.PosInWord == 1 )
						{
							node = -9;
							mean = 3552.22f;
						}
					}
				}
				/*Rules for terminal node 10*/

				if( Unit.PosInPhrase > 0.98f )
				{
					node = -10;
					mean = 4466.15f;
				}
			}
		/*Rules for node 12*/
			if( (Unit.csRightPhoneType == "CFV") || (Unit.csRightPhoneType == "CSU") ||
				   (Unit.csRightPhoneType == "VFC") || (Unit.csRightPhoneType == "VM"))
			{
				node = 12;
				mean = 3532.28f;
				/*Rules for node 13*/
				if( (Unit.PosInWord == 0) || (Unit.PosInWord == 0.5f) ||
					  ( Unit.PosInWord == 2.0f/3) || (Unit.PosInWord == 0.75f) )
				{
					node = 13;
					mean = 3450.81f;
					/*Rules for terminal node 11*/
					if( ( Unit.bTone == 1) ||(Unit.bTone == 3) ||
						   (Unit.bTone == 7) || (Unit.bTone == 8))
					{
						node = -11;
						mean = 3280.94f;
					}
					/*Rules for terminal node 12*/
					if( ( Unit.bTone == 2) ||
						   (Unit.bTone == 4) ||
						   (Unit.bTone == 5) ||
						   (Unit.bTone == 6 ))
					{
						node = -12;
						mean = 3612.98f;
					}
				}
			/*Rules for terminal node 13*/
				if(Unit.PosInWord == 1 )
				{
					node = -13;
					mean = 3832.83f;
				}
			}

		}

	}

	/*Rules for node 14*/

	if( Unit.Stress == TRUE )

	{
		node = 14;
		mean = 4547.03f;
		/*Rules for terminal node 14*/

		if (( Unit.bTone == 6)  || ( Unit.bTone == 7) || ( Unit.bTone == 8))
		{
			node = -14;
			mean = 4025.34f;
		}
		/*Rules for node 15*/
		if (( Unit.bTone == 1) || (  Unit.bTone == 2) || ( Unit.bTone == 3) || (Unit.bTone == 4) ||(Unit.bTone == 5 ))
		{
			node = 15;
			mean = 4751.15f;
			/*Rules for node 16*/
			if((Unit.bRightTone == 1) || (Unit.bRightTone == 2) || (Unit.bRightTone == 3) ||
			   (Unit.bRightTone == 4) || (Unit.bRightTone == 5) || (Unit.bRightTone == 6) || (Unit.bRightTone == 7 ))
			{
				node = 16;
				mean = 4139.47f;
				/*Rules for terminal node 15*/
				if( Unit.PosInPhrase <= 0.345f )
				{
					node = -15;
					mean = 3805.06f;
				}
				/*Rules for terminal node 16*/

				if( Unit.PosInPhrase > 0.345f )
				{
					node = -16;
					mean = 4303.63f;
				}
			}
			/*Rules for node 17*/
			if(( Unit.bRightTone == 0) || (Unit.bRightTone == 8 ))
			{
				node = 17;
				mean = 5027.88f;
				/*Rules for node 18*/
				if((Unit.bTone == 1) || (Unit.bTone == 2) || (Unit.bTone == 4))
				{
					node = 18;
					mean = 4927.28f;
					/*Rules for terminal node 17*/
					if( (Unit.csRightPhoneType == "CFL") || (  Unit.csRightPhoneType == "CSN") ||
						(Unit.csRightPhoneType == "CSV") || (  Unit.csRightPhoneType == "SV") ||
						(Unit.csRightPhoneType == "VB")  || (Unit.csRightPhoneType == "VBC") ||
						(Unit.csRightPhoneType == "VFC") || (Unit.csRightPhoneType == "VM") ||
						(Unit.csRightPhoneType == "VMC"))
					{
						node = -17;
						mean = 4718.52f;
					}
				/*Rules for terminal node 18*/

					if( (Unit.csRightPhoneType == "CFU") || (  Unit.csRightPhoneType == "CFV") ||
						   (Unit.csRightPhoneType == "CSU") ||(Unit.csRightPhoneType == "VF" )||(Unit.csRightPhoneType == "NUL" ))
					{
						node = -18;
						mean = 5076.02f;
					}
				}
				/*Rules for terminal node 19*/
				if((Unit.bTone == 3) ||  (Unit.bTone == 5 ))
				{
					node = -19;
					mean = 5313.19f;
				}
			}
		}
	}
	Length = mean;
	return TRUE;

}


void CTextHandle::F0ContourGeneration(vector<UNITINFOFULL> &SyllableArray)//(CArray<UNITINFOFULL, UNITINFOFULL> &SyllableArray)
{
	/*const double fRelRegMatrix[8][8] = {0.99, 0.84, 0.91, 0.82, 0.90, 0.88, 1.24, 0.84,
										1.13, 0.92, 0.96, 0.91, 0.99, 0.93, 1.38, 0.92,
										1.21, 1.05, 1.04, 1.07, 1.06, 1.11, 1.48, 1.09,
										1.13, 0.92, 0.94, 0.90, 0.98, 0.92, 1.39, 0.93,
										1.19, 1.08, 1.12, 1.05, 1.07, 1.18, 1.50, 1.18,
										1.11, 0.92, 0.90, 0.90, 0.95, 0.92, 1.36, 0.93,
										0.84, 0.73, 0.77, 0.68, 0.78, 0.80, 1.10, 0.70,
										1.14, 0.91, 0.96, 0.94, 0.98, 0.95, 1.45, 0.94};*/
	const double fRelRegMatrix[8][8] = {0.99, 0.84, 0.91, 0.82, 0.90, 0.88, 1.24, 0.84,
										1.13, 0.92, 0.96, 0.91, 0.99, 0.93, 1.38, 0.92,
										1.21, 1.05, 1.04, 1.07, 1.06, 1.11, 1.48, 1.09,
										1.13, 0.92, 0.94, 0.90, 0.98, 0.92, 1.39, 0.93,
										1.19, 1.08, 1.12, 1.05, 1.07, 1.18, 1.50, 1.18,
										1.11, 0.92, 0.90, 0.90, 0.95, 0.92, 1.36, 0.93,
										0.84, 0.73, 0.77, 0.68, 0.78, 0.80, 1.10, 0.70,
										1.14, 0.91, 0.96, 0.94, 0.98, 0.95, 1.45, 0.94};
	//CUIntArray F0_Contour;
	//CArray<float, float> F0_Contour, F0_Syllable, F0_Register_Contour;
	vector<float> F0_Contour, F0_Syllable, F0_Register_Contour;
	float fOldNorRegister =1.0f;
	
	//////////////////////////////////////////////////////////////////////////////////////////////////
	// Modeling F0 contour
	//////////////////////////////////////////////////////////////////////////////////////////////////
	int nNumOfSylInPhrase;
	int nSizeOfArray;
	int nNumOfF0InPhrase;
	nSizeOfArray = SyllableArray.size();
	nNumOfSylInPhrase	= 0;
	nNumOfF0InPhrase	= 0;
	for( int i=0; i < nSizeOfArray; i++)
	{
		int nSample;
		float fNumOfF0; 
		int nNumOfF0;
		if(SyllableArray.at(i).bTone>0)
		{
//			int nPosOfSyl;
			float fNorRegister;// = 1.0f;
			BYTE bLeftTone;
									
			fNorRegister = 1.0f;
			//nPosOfSyl = LookUpSylArray.GetSize()-1;
					
			bLeftTone = SyllableArray.at(i-1).bTone;
			if(bLeftTone ==0) 
			{
						
				fNorRegister = 1.0f;
				F0_Syllable.clear();
				
				fNumOfF0 = float(SyllableArray.at(i).dwUnitLen)/160;
				if((fNumOfF0 + 0.5f) > (int(fNumOfF0)+1)) SyllableArray.at(i).numOfF0 = int(fNumOfF0)+1;
				else SyllableArray.at(i).numOfF0 = int(fNumOfF0);

				for(nSample=0; nSample < SyllableArray.at(i).numOfF0; nSample++) 
				{
					F0_Syllable.push_back(fNorRegister);
					F0_Register_Contour.push_back(fNorRegister);// For contour of the register of F0 of the phrase
				}
				ToneInPhrase(F0_Syllable, SyllableArray.at(i).bTone, fNorRegister,SyllableArray.at(i).dwUnitLen);
				for(nSample=0; nSample < SyllableArray.at(i).numOfF0; nSample++) 
				{
					F0_Contour.push_back(F0_Syllable.at(nSample));
				}
				fOldNorRegister = fNorRegister;
				nNumOfF0InPhrase = nNumOfF0InPhrase + SyllableArray.at(i).numOfF0;
				nNumOfSylInPhrase ++;
				if(SyllableArray.at(i).bRightTone ==0)
				{
					int nF0BeginOfSyl =0;
					int nF0ContourSize = F0_Contour.size();
					
					for(int nPosInPhrase = i-nNumOfSylInPhrase+1;nPosInPhrase <= i; nPosInPhrase++)
					{
						nNumOfF0 = SyllableArray.at(nPosInPhrase).numOfF0;
						SyllableArray.at(nPosInPhrase).fF0 = new float[nNumOfF0];
						for(nSample=0;nSample < nNumOfF0; nSample++)
							SyllableArray.at(nPosInPhrase).fF0[nSample] = F0_Contour.at(nF0ContourSize - nNumOfF0InPhrase + nF0BeginOfSyl + nSample);
						nF0BeginOfSyl = nF0BeginOfSyl + nNumOfF0;

					}

					nNumOfF0InPhrase = 0;
					nNumOfSylInPhrase= 0;
				}
			}
			else
			{
				fNorRegister = fOldNorRegister*float(fRelRegMatrix[bLeftTone-1][SyllableArray.at(i).bTone-1]);
				F0_Syllable.clear();
				fNumOfF0 = float(SyllableArray.at(i).dwUnitLen)/160;
				if((fNumOfF0 + 0.5f) > (int(fNumOfF0)+1)) SyllableArray.at(i).numOfF0 = int(fNumOfF0)+1;
				else SyllableArray.at(i).numOfF0 = int(fNumOfF0);
				
				for(nSample=0; nSample < SyllableArray.at(i).numOfF0; nSample++) 
				{
					F0_Syllable.push_back(fNorRegister);
					F0_Register_Contour.push_back(fNorRegister);// For contour of the register of F0 of the phrase
				}
				
				fOldNorRegister = fNorRegister;
			
				ToneInPhrase(F0_Syllable, SyllableArray.at(i).bTone, fNorRegister,SyllableArray.at(i).dwUnitLen);

			
				/////////////////////////////////////////////////////////////////////////////////////
				// Smoothing two levels of register of Tone
				/////////////////////////////////////////////////////////////////////////////////////
				float fAverage, fTempReg;
				
				fAverage =  F0_Syllable.at(0) - F0_Contour.at(F0_Contour.size() - 1); // Pr0 - Pl0 // Coarticulation at the endpoint of the first syllable
				
				
				if(bLeftTone == 6)
					for(nSample = 0; nSample < SyllableArray.at(i).numOfF0/6; nSample ++)// Progressve Effect > Regressive Effect
					{
						//fTempReg = F0_Syllable.at(nSample) - fAverage*(float)(DicSyllable.numOfF0/6 - nSample)/(DicSyllable.numOfF0/6);// Progressve Effect = Regressive Effect
						fTempReg = F0_Syllable.at(nSample) - fAverage*(float)(SyllableArray.at(i).numOfF0/6 - nSample)/(SyllableArray.at(i).numOfF0/6);// Progressve Effect > Regressive Effect
						F0_Syllable.at(nSample) = fTempReg;
					}
				else
				{
					for(nSample = 0; nSample < SyllableArray.at(i).numOfF0/3; nSample ++)// Progressve Effect > Regressive Effect
					{
						//fTempReg = F0_Syllable.at(nSample) - fAverage*(float)(DicSyllable.numOfF0/6 - nSample)/(DicSyllable.numOfF0/6);// Progressve Effect = Regressive Effect
						fTempReg = F0_Syllable.at(nSample) - fAverage*(float)(SyllableArray.at(i).numOfF0/3 - nSample)/(SyllableArray.at(i).numOfF0/3);// Progressve Effect > Regressive Effect
						F0_Syllable.at(nSample) = fTempReg;
					}
				}
				for(nSample=0; nSample < SyllableArray.at(i).numOfF0; nSample++)
				F0_Contour.push_back(F0_Syllable.at(nSample));
				// End of Smoothing
				/////////////////////////////////////////////////////////////////////////////////////
				nNumOfF0InPhrase = nNumOfF0InPhrase + SyllableArray.at(i).numOfF0;
				nNumOfSylInPhrase ++;
				if(SyllableArray.at(i).bRightTone ==0)
				{
					int nF0BeginOfSyl =0;
					int nF0ContourSize = F0_Contour.size();
					
					for(int nPosInPhrase = i-nNumOfSylInPhrase+1;nPosInPhrase <= i; nPosInPhrase++)
					{
						nNumOfF0 = SyllableArray.at(nPosInPhrase).numOfF0;
						SyllableArray.at(nPosInPhrase).fF0 = new float[nNumOfF0];
						for(nSample=0;nSample < nNumOfF0; nSample++)
							SyllableArray.at(nPosInPhrase).fF0[nSample] = F0_Contour.at(nF0ContourSize - nNumOfF0InPhrase + nF0BeginOfSyl + nSample);
						nF0BeginOfSyl = nF0BeginOfSyl + nNumOfF0;

					}

					nNumOfF0InPhrase = 0;
					nNumOfSylInPhrase= 0;
				}
				
			}
		}
		else 
		{
			fNumOfF0 = float(SyllableArray.at(i).dwUnitLen)/160;
			if((fNumOfF0 + 0.5f) > (int(fNumOfF0)+1)) SyllableArray.at(i).numOfF0 = int(fNumOfF0)+1;
			else SyllableArray.at(i).numOfF0 = int(fNumOfF0);

			for(nSample=0; nSample < SyllableArray.at(i).numOfF0; nSample++) 
			{
				F0_Contour.push_back(0.0f);
				F0_Register_Contour.push_back(0.0f);// For contour of the register of F0 of the phrase
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	// For test
	//////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////
/*	CString csFileName;
	csFileName = "F0Contour.FRE"; // F0RE = F0 REgister

	FILE *fOut;
	if( (fOut = fopen((LPCTSTR)csFileName, "wt")) == NULL ) 
	{
		csFileName = "Can not open file: F0Contour.FRE";
		CPsola::OutputLastError(csFileName);
		return;
	}

	char text[255];
	sprintf(text,"Time\tFrequency\n");
	fwrite(text,strlen(text),1,fOut);
		
	int dwSize = F0_Register_Contour.GetSize();

	for(int i=0; i<dwSize;i++)
	{
		sprintf(text,"%7.2f\t%6.0f\n",float(i)*0.01f, CPsola::nF0_Begin*F0_Register_Contour.at(i));
		fwrite(text,strlen(text),1,fOut);
	}
	F0_Register_Contour.RemoveAll();
	
	fclose(fOut);*/
			
			//////////////////////////////////////////////////////////////////////
	/*csFileName = "F0Contour.NOF"; // NOF = Normalized F0
	if( (fOut = fopen((LPCTSTR)csFileName, "wt")) == NULL ) 
	{
		csFileName = "Can not open file: F0Contour.NOF";
		CPsola::OutputLastError(csFileName);
		return;
	}

	sprintf(text,"Time\tFrequency\n");
	fwrite(text,strlen(text),1,fOut);
		
	dwSize = F0_Contour.GetSize();

	for(int i=0; i<dwSize;i++)
	{
		sprintf(text,"%7.2f\t%6.0f\n",float(i)*0.01f, CPsola::nF0_Begin*F0_Contour.at(i));
		fwrite(text,strlen(text),1,fOut);
	}
	fclose(fOut);*/
	
	// End of Test
	//////////////////////////////////////////////////////////////////////////////////////////////

	F0_Contour.clear();
	F0_Syllable.clear();
	F0_Register_Contour.clear();


}

BOOL CTextHandle::ToneInPhrase(vector<float> &F0Array, BYTE ToneType, float fNorF0, int nSylLen)
{
	if ((ToneType<1) ||(ToneType>8)) return FALSE;
	int nNumOfCtrlPoint = 0;
	int counter = 0;
	
	/*int nValueOfF0_1[4] =	{100,100,95, 85};
	int nValueOfF0_2[4] =	{100, 95, 80, 75};
	//int nValueOfF0_3[8] = 	{100, 95, 85, 50, 50, 95, 120, 125};
	int nValueOfF0_3[8] = 	{100, 95, 85, 70, 70, 95, 120, 125};// for syllables in continuous speech
	//int nValueOfF0_4[5] =	{100, 90, 75, 65, 90};
	int nValueOfF0_4[5] =	{100, 95, 85, 70, 65};
	int nValueOfF0_5[4] =	{100,100,110, 125};
	//int nValueOfF0_6[5] =	{100, 95, 85, 55, 50};
	int nValueOfF0_6[5] =	{100, 95, 90, 80, 55};

	int nValueOfF0_7[3] =	{100,110, 125};
	int nValueOfF0_8[3] =	{100, 88, 65};*/

	//////////////////////////////////////////////////////////////////////////////////////////////////
	// These patterns are used for modeling f0 contours
	int nValueOfF0_1[4] =	{100,100, 96, 90};
	int nValueOfF0_2[4] =	{100, 95, 91, 80};
	int nValueOfF0_3_S[8] = {100, 100, 95, 93, 90, 80, 80, 100}; // S = Short: for a syllable which has a short duration
	int nValueOfF0_3_M[8] = {100, 95, 85, 80, 70, 90, 100, 110}; // M = Medium: for a syllable which has a short duration
	int nValueOfF0_3[8] = 	{100, 95, 85, 70, 70, 95, 120, 125};// for syllables in continuous speech
	
	int nValueOfF0_4[5]  =	{100, 99, 85, 65, 75};
	int nValueOfF0_4M[5] =  {100, 99, 85, 70, 65}; 
	//int nValueOfF0_5_S[4] =	{100,100,102, 105};
	int nValueOfF0_5_S[4] =	{100,100,105, 110};
	int nValueOfF0_5_M[4] =	{100, 99,105, 125};
	//int nValueOfF0_5[4] =	{100,100,105, 125};
	int nValueOfF0_5[4] =	{100,105,120, 130};

	int nValueOfF0_6[5] =	{100, 95, 90, 80, 60};

	int nValueOfF0_7[3] =	{100,110, 125};
	int nValueOfF0_8[3] =	{100, 88, 65};
	///////////////////////////////////////////////////////////////////////////////////////////////////
	

	int nCtrlPosition_1[3] = {33,34,33};
	int nCtrlPosition_2[4] = {25,25,25,25};
	int nCtrlPosition_3[7] = {16, 17,12,10,12,17,16};
	int nCtrlPosition_6[4] = {20,15,15,50};
	int nCtrlPosition_7[2] = {40,60};

	int lTransitionPoint;
	
	int nLenOfSyl;
	float fF0Step,fF0Temp;
	int nPos;
	int nLen, nTotalLenOfSyl;
	float fLen;
	float fF0BigStep =0;
	
	
	//CArray<float, float> OldF0Array;
	vector<float> OldF0Array = F0Array;

	//OldF0Array.Copy(F0Array);
	F0Array.clear();
	
	
	nTotalLenOfSyl = OldF0Array.size();

	lTransitionPoint = int(0.3f*nTotalLenOfSyl);
	
	nLenOfSyl = nTotalLenOfSyl - lTransitionPoint;

	if (ToneType == 1)
	{
		nNumOfCtrlPoint = 4;
		nPos =0;
		
		for(counter = 0; counter < nNumOfCtrlPoint-1;counter++)
		{
			//fF0Step = float(nValueOfF0_1[counter+1] - nValueOfF0_1[counter])/nCtrlPosition_1[counter]/100;

			fLen = float(nLenOfSyl* nCtrlPosition_1[counter])/100;
			nLen = nLenOfSyl* nCtrlPosition_1[counter]/100;
			if((float(nLen) + 0.5f)< fLen) nLen++;
			if(lTransitionPoint + nPos + nLen >= nTotalLenOfSyl) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;
			if((counter == (nNumOfCtrlPoint-2))&& (lTransitionPoint + nPos + nLen < nTotalLenOfSyl)) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;
			
			fF0Step = float(nValueOfF0_1[counter+1] - nValueOfF0_1[counter])/nLen/100;

			for(int i = 0; i <nLen; i++)
			{
				fF0Temp = OldF0Array.at(lTransitionPoint + nPos + i) + fF0Step*i + fF0BigStep;
				OldF0Array.at(lTransitionPoint + nPos + i) = fF0Temp;
			}
			nPos = nPos + nLen;
			fF0BigStep = fF0BigStep + float(nValueOfF0_1[counter+1] - nValueOfF0_1[counter])/100;

		}

	}
	if (ToneType == 2)
	{
		nNumOfCtrlPoint = 4;
		nPos =0;
		
		for(counter = 0; counter < nNumOfCtrlPoint-1;counter++)
		{
			//fF0Step = float(nValueOfF0_2[counter+1] - nValueOfF0_2[counter])/nCtrlPosition_1[counter]/100;

			fLen = float(nLenOfSyl* nCtrlPosition_1[counter])/100;
			nLen = nLenOfSyl* nCtrlPosition_1[counter]/100;
			if((float(nLen) + 0.5f)< fLen) nLen++;
			if(lTransitionPoint + nPos + nLen >= nTotalLenOfSyl) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;
			if((counter == (nNumOfCtrlPoint-2))&& (lTransitionPoint + nPos + nLen <nTotalLenOfSyl)) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;

			fF0Step = float(nValueOfF0_2[counter+1] - nValueOfF0_2[counter])/nLen/100;

			for(int i = 0; i <nLen; i++)
			{
				fF0Temp = OldF0Array.at(lTransitionPoint + nPos + i) + fF0Step*i + fF0BigStep;
				OldF0Array.at(lTransitionPoint + nPos + i) = fF0Temp;
			}
			nPos = nPos + nLen;
			fF0BigStep = fF0BigStep + float(nValueOfF0_2[counter+1] - nValueOfF0_2[counter])/100;
		}
	}

	if (ToneType == 3)
	{
		
		nNumOfCtrlPoint = 8;
		nPos =0;
		if((nSylLen/16) <= 150) for(int k =0; k<8;k++) nValueOfF0_3[k] = nValueOfF0_3_S[k];
		if(((nSylLen/16) > 150)&&((nSylLen/16) <= 250)) for(int k =0; k<8;k++) nValueOfF0_3[k] = nValueOfF0_3_M[k];

		
		
		for(counter = 0; counter < nNumOfCtrlPoint-1;counter++)
		{
			//fF0Step = float(nValueOfF0_3[counter+1] - nValueOfF0_3[counter])/nCtrlPosition_3[counter]/100;

			fLen = float(nLenOfSyl* nCtrlPosition_3[counter])/100;
			nLen = nLenOfSyl* nCtrlPosition_3[counter]/100;
			if((float(nLen) + 0.5f)< fLen) nLen++;
			if(lTransitionPoint + nPos + nLen >= nTotalLenOfSyl) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;
			if((counter == (nNumOfCtrlPoint-2))&& (lTransitionPoint + nPos + nLen <nTotalLenOfSyl)) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;
			
			fF0Step = float(nValueOfF0_3[counter+1] - nValueOfF0_3[counter])/nLen/100;

			for(int i = 0; i <nLen; i++)
			{
				fF0Temp = OldF0Array.at(lTransitionPoint + nPos + i) + fF0Step*i + fF0BigStep;
				OldF0Array.at(lTransitionPoint + nPos + i) = fF0Temp;
			}
			nPos = nPos + nLen;
			fF0BigStep = fF0BigStep + float(nValueOfF0_3[counter+1] - nValueOfF0_3[counter])/100;

		}

	}

	if (ToneType == 4)
	{
		
		nNumOfCtrlPoint = 5;
		nPos =0;
		if((nSylLen/16) <= 250) for(int k =0; k<5;k++) nValueOfF0_4[k] = nValueOfF0_4M[k];
		
		for(counter = 0; counter < nNumOfCtrlPoint-1;counter++)
		{
			//fF0Step = float(nValueOfF0_4[counter+1] - nValueOfF0_4[counter])/nCtrlPosition_2[counter]/100;

			fLen = float(nLenOfSyl* nCtrlPosition_2[counter])/100;
			nLen = nLenOfSyl* nCtrlPosition_2[counter]/100;
			if((float(nLen) + 0.5f)< fLen) nLen++;
			if(lTransitionPoint + nPos + nLen >= nTotalLenOfSyl) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;
			if((counter == (nNumOfCtrlPoint-2))&& (lTransitionPoint + nPos + nLen <nTotalLenOfSyl)) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;

			fF0Step = float(nValueOfF0_4[counter+1] - nValueOfF0_4[counter])/nLen/100;

			for(int i = 0; i <nLen; i++)
			{
				fF0Temp = OldF0Array.at(lTransitionPoint + nPos + i) + fF0Step*i + fF0BigStep;
				OldF0Array.at(lTransitionPoint + nPos + i) = fF0Temp;
			}
			nPos = nPos + nLen;
			fF0BigStep = fF0BigStep + float(nValueOfF0_4[counter+1] - nValueOfF0_4[counter])/100;

		}

		
	}
	
	if (ToneType == 5)
	{
		nNumOfCtrlPoint = 4;
		nPos =0;
		if((nSylLen/16) <= 150) for(int k =0; k<4;k++) nValueOfF0_5[k] = nValueOfF0_5_S[k];
		if(((nSylLen/16) > 150)&&((nSylLen/16) <= 250)) for(int k =0; k<4;k++) nValueOfF0_5[k] = nValueOfF0_5_M[k];
		
		for(counter = 0; counter < nNumOfCtrlPoint-1;counter++)
		{
			//fF0Step = float(nValueOfF0_5[counter+1] - nValueOfF0_5[counter])/nCtrlPosition_1[counter]/100;

			fLen = float(nLenOfSyl* nCtrlPosition_1[counter])/100;
			nLen = nLenOfSyl* nCtrlPosition_1[counter]/100;
			if((float(nLen) + 0.5f)< fLen) nLen++;
			if(lTransitionPoint + nPos + nLen >= nTotalLenOfSyl) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;
			if((counter == (nNumOfCtrlPoint-2))&& (lTransitionPoint + nPos + nLen <nTotalLenOfSyl)) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;

			fF0Step = float(nValueOfF0_5[counter+1] - nValueOfF0_5[counter])/nLen/100;

			for(int i = 0; i <nLen; i++)
			{
				fF0Temp = OldF0Array.at(lTransitionPoint + nPos + i) + fF0Step*i + fF0BigStep;
				OldF0Array.at(lTransitionPoint + nPos + i) = fF0Temp;
			}
			nPos = nPos + nLen;
			fF0BigStep = fF0BigStep + float(nValueOfF0_5[counter+1] - nValueOfF0_5[counter])/100;

		}

	}

	if (ToneType == 6)
	{
		nNumOfCtrlPoint = 5;
		nPos =0;
		
		for(counter = 0; counter < nNumOfCtrlPoint-1;counter++)
		{
			//fF0Step = float(nValueOfF0_6[counter+1] - nValueOfF0_6[counter])/nCtrlPosition_6[counter]/100;

			fLen = float(nLenOfSyl* nCtrlPosition_6[counter])/100;
			nLen = nLenOfSyl* nCtrlPosition_6[counter]/100;
			if((float(nLen) + 0.5f)< fLen) nLen++;
			if(lTransitionPoint + nPos + nLen >= nTotalLenOfSyl) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;
			if((counter == (nNumOfCtrlPoint-2))&& (lTransitionPoint + nPos + nLen <nTotalLenOfSyl)) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;

			fF0Step = float(nValueOfF0_6[counter+1] - nValueOfF0_6[counter])/nLen/100;

			for(int i = 0; i <nLen; i++)
			{
				fF0Temp = OldF0Array.at(lTransitionPoint + nPos + i) + fF0Step*i + fF0BigStep;
				OldF0Array.at(lTransitionPoint + nPos + i) = fF0Temp;
			}
			nPos = nPos + nLen;
			fF0BigStep = fF0BigStep + float(nValueOfF0_6[counter+1] - nValueOfF0_6[counter])/100;

		}

	
	}

	if (ToneType == 7)
	{
		
		nNumOfCtrlPoint = 3;
		nPos =0;
		
		for(counter = 0; counter < nNumOfCtrlPoint-1;counter++)
		{
			//fF0Step = float(nValueOfF0_7[counter+1] - nValueOfF0_7[counter])/nCtrlPosition_7[counter]/100;

			fLen = float(nLenOfSyl* nCtrlPosition_7[counter])/100;
			nLen = nLenOfSyl* nCtrlPosition_7[counter]/100;
			if((float(nLen) + 0.5f)< fLen) nLen++;
			if(lTransitionPoint + nPos + nLen >= nTotalLenOfSyl) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;
			if((counter == (nNumOfCtrlPoint-2))&& (lTransitionPoint + nPos + nLen <nTotalLenOfSyl)) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;

			fF0Step = float(nValueOfF0_7[counter+1] - nValueOfF0_7[counter])/nLen/100;

			for(int i = 0; i <nLen; i++)
			{
				fF0Temp = OldF0Array.at(lTransitionPoint + nPos + i) + fF0Step*i + fF0BigStep;
				OldF0Array.at(lTransitionPoint + nPos + i) = fF0Temp;
			}
			nPos = nPos + nLen;
			fF0BigStep = fF0BigStep + float(nValueOfF0_7[counter+1] - nValueOfF0_7[counter])/100;

		}

	
	}

	if (ToneType == 8)
	{
		nNumOfCtrlPoint = 3;
		nPos =0;
		
		for(counter = 0; counter < nNumOfCtrlPoint-1;counter++)
		{
			//fF0Step = float(nValueOfF0_8[counter+1] - nValueOfF0_8[counter])/nCtrlPosition_7[counter]/100;

			fLen = float(nLenOfSyl* nCtrlPosition_7[counter])/100;
			nLen = nLenOfSyl* nCtrlPosition_7[counter]/100;
			if((float(nLen) + 0.5f)< fLen) nLen++;
			if(lTransitionPoint + nPos + nLen >= nTotalLenOfSyl) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;
			if((counter == (nNumOfCtrlPoint-2))&& (lTransitionPoint + nPos + nLen <nTotalLenOfSyl)) nLen = nTotalLenOfSyl- lTransitionPoint - nPos;

			fF0Step = float(nValueOfF0_8[counter+1] - nValueOfF0_8[counter])/nLen/100;

			for(int i = 0; i <nLen; i++)
			{
				fF0Temp = OldF0Array.at(lTransitionPoint + nPos + i) + fF0Step*i + fF0BigStep;
				OldF0Array.at(lTransitionPoint + nPos + i) = fF0Temp;
			}
			nPos = nPos + nLen;
			fF0BigStep = fF0BigStep + float(nValueOfF0_8[counter+1] - nValueOfF0_8[counter])/100;

		}
		
	
	}


	float fOffset =1;
	float fAverage =0;
	if((ToneType!=3)&&(ToneType!=6))
	{
		for(int j = int(nTotalLenOfSyl*0.3f) ; j<int(nTotalLenOfSyl*0.8f);j++)
			fAverage = OldF0Array.at(j)+ fAverage;
		fAverage = fAverage/ (int(nTotalLenOfSyl*0.8f) - int(nTotalLenOfSyl*0.3f));
		fOffset = fNorF0 - fAverage;
		for(int i=0; i<nTotalLenOfSyl; i ++)
			OldF0Array.at(i) = OldF0Array.at(i) + fOffset;
	}
	

	//F0Array.Copy(OldF0Array);
	F0Array = OldF0Array;
	OldF0Array.clear();
	
	return TRUE;

}

BOOL CTextHandle::ParseSylInfo(UNITINFOFULL &Syllable, SYLLABLESTRUCT *stSyl)
{
	//Tim ten cua diphone thu nhat
	int i = 0;
	//int j = 1;
	//int index = 0;
	
	//MessageBox(::AfxGetMainWnd()->m_hWnd,"1"+cs+"1",0,0);

	if((Syllable.cUnitName =="SILP")||(Syllable.cUnitName =="SILS")||(Syllable.cUnitName =="SIL"))
	{
		stSyl->nAUnit = 0;
		stSyl->nNumberFo = 0;
		stSyl->nFo = NULL;
		stSyl->cFirstAUnit[0] = '_';
		stSyl->cFirstAUnit[1] = '\0';
		stSyl->cSecondAUnit[0]='\0';
		
		stSyl->nSyllableLen = Syllable.dwUnitLen*BYTESPERSAMPLE;
		
		return TRUE;
	}
	else
	{
		stSyl->nAUnit		= Syllable.bNumOfSubUnit;
		stSyl->nTon			= Syllable.bTone;
		stSyl->nSyllableLen	= Syllable.dwUnitLen *BYTESPERSAMPLE;
		stSyl->nEnergy		= Syllable.dwEnergy;
		stSyl->nNumberFo	= Syllable.numOfF0;
		stSyl->nFo			= new int[stSyl->nNumberFo];
		for(i=0; i<stSyl->nNumberFo; i++)
		{
			stSyl->nFo[i] = int(Syllable.fF0[i] * nF0_Begin *fRegister);
			if(stSyl->nFo[i] < int(0.5f* nF0_Begin)) stSyl->nFo[i] = int(0.55f* nF0_Begin);
			//stSyl->bUnitIndex[i] = 1;
		}
		for(i=0; i<stSyl->nAUnit;i++) stSyl->bUnitIndex[i] = 1;

		switch (stSyl->nAUnit)
		{
		case 1: 
			strcpy(stSyl->cFirstAUnit,Syllable.csSubUnit[0]);
			break;
		case 2:
			strcpy(stSyl->cFirstAUnit,Syllable.csSubUnit[0]);
			strcpy(stSyl->cSecondAUnit,Syllable.csSubUnit[1]);
			break;
		case 3:
			strcpy(stSyl->cFirstAUnit,Syllable.csSubUnit[0]);
			strcpy(stSyl->cSecondAUnit,Syllable.csSubUnit[1]);
			strcpy(stSyl->cThirdAUnit,Syllable.csSubUnit[2]);
			break;
		case 4:
			strcpy(stSyl->cFirstAUnit,Syllable.csSubUnit[0]);
			strcpy(stSyl->cSecondAUnit,Syllable.csSubUnit[1]);
			strcpy(stSyl->cThirdAUnit,Syllable.csSubUnit[2]);
			strcpy(stSyl->cFourthAUnit,Syllable.csSubUnit[3]);
			break;
		}
	}
	return TRUE;

}

BYTE CTextHandle::EnergyModel(UNITINFOFULL Unit)
{
	CStdStringA csVowel[16]	= {"a", "A", "B", "E", "e", "i", "O", "o", "7", "Z", "Q", "u", "M", "I", "U", "Y"};
	BYTE SylEnergy[16]	= { 26,  28,  26,  31,  30,  23,  25,  22,  20,  20,  24, 15 ,  17,  32,  19, 18};  
	BYTE bSylEnergy = 32;

	for(int i= 0; i<16; i++)
		if(Unit.csSound[2] == csVowel[i]) 
		{
			bSylEnergy = SylEnergy[i]; break;
		}
	
	switch (Unit.bTone)
	{
		case 1: bSylEnergy = BYTE(bSylEnergy*0.95f);
				break;
		case 2: bSylEnergy = BYTE(bSylEnergy*0.85f);
				break;
		case 4: bSylEnergy = BYTE(bSylEnergy*0.75f);
				break;
		case 5: bSylEnergy = BYTE(bSylEnergy*0.9f);
				break;
		case 6: bSylEnergy = BYTE(bSylEnergy*0.95f);
				break;
	}

	if((Unit.PosInSyntagm ==1)&&(Unit.nPhraseLen>1)) bSylEnergy = BYTE(bSylEnergy*0.8f);

	return bSylEnergy;

}

BOOL CTextHandle::SyllableAnalysis(CStdStringA &csSyllable, UNITINFOFULL &DicSyllable)
{

	int nNumOfVow, nNumOfInPhone, nNumOfMiPhone, nNumOfFiPhone;
	
	// Getting tone information
	int nNumOfVowel = VowelArray.size();//VowelArray.GetSize();
	int nFound;

	// Initial phone	
	DicSyllable.csSound[0]		= "NUL";
	DicSyllable.csSoundType[0]	= "NUL";
	// middle phone
	DicSyllable.csSound[1]		= "NUL";
	DicSyllable.csSoundType[1]	= "NUL";
	// nucleus phone
	DicSyllable.csSound[2]		= "NUL";
	DicSyllable.csSoundType[2]	= "NUL";
	// final phone
	DicSyllable.csSound[3]		= "NUL";
	DicSyllable.csSoundType[3]	= "NUL";

	if((csSyllable =="SIL")|| (csSyllable =="SILP")||(csSyllable =="SILS")) 
	{
		DicSyllable.bTone = 0;
		DicSyllable.bNumOfSound =0;
		return TRUE;
	}
		
	nFound = -1;
	for(int j=0; j< nNumOfVowel; j++)
	{
		nFound = csSyllable.Find(VowelArray.at(j),0);
		
		if(nFound>=0)
		{
			DicSyllable.bTone = ToneArray.at(j);//ToneArray.at(j);
			if (DicSyllable.bTone == 5)
			{
				BYTE SylLen=0,posTemp=0;
				SylLen = csSyllable.GetLength();
				posTemp = csSyllable.Find("ch",1);
				if((csSyllable.at(SylLen-1) =='c')||(csSyllable.at(SylLen-1) =='t')
							||(csSyllable.at(SylLen-1) =='p')||(posTemp == (SylLen-2)))
					DicSyllable.bTone = 7;
			}
			if (DicSyllable.bTone == 6)
			{
				BYTE SylLen=0,posTemp=0;
				SylLen = csSyllable.GetLength();
				posTemp = csSyllable.Find("ch",1);

				if((csSyllable.at(SylLen-1) =='c')||(csSyllable.at(SylLen-1) =='t')
						||(csSyllable.at(SylLen-1) =='p')||(posTemp == (SylLen-2)))
						DicSyllable.bTone = 8;
			}

			if(DicSyllable.bTone >1)  
			{
				//char *cSyllabeTemp;
				CStdStringA vowel;

				//cSyllabeTemp = new char[csSyllable.GetLength()];
				int startIndex = csSyllable.Find(VowelArray.at(j));
				//memcpy(cSyllabeTemp,VowelNoToneArray.at(j),startIndex);
				//vowel.copy(LPTSTR(VowelNoToneArray.at(j)));
				vowel = VowelNoToneArray.at(j);

				CStdStringA str1 = csSyllable.Left(startIndex);
				int oldLen = VowelArray.at(j).GetLength();
				CStdStringA str2 = csSyllable.Right(csSyllable.GetLength()- startIndex -oldLen);
				CStdStringA strTemp = str1 + vowel + str2;
				//csSyllable.Replace(VowelArray.at(j),VowelNoToneArray.at(j));
				csSyllable = strTemp;
				;
			}
			

			break;
		}
	}
	if(nFound == -1) DicSyllable.bTone =1;

	// Getting other information
	DicSyllable.bNumOfSound = 0;
	nNumOfVow		= VoArray.size();
	nNumOfInPhone	= InPhoneArray.size();
	nNumOfMiPhone	= MiPhoneArray.size();
	nNumOfFiPhone	= FiPhoneArray.size();

	CStdStringA csLeft, csRight;

	int	i,j,k;// Bo sung ngay 02/08/2011 cho phu hop voi C++ moi
//	BYTE bTone;
	BYTE bPhoneLen;
	BYTE bSyllableLen;
	nFound = -1;
	
	for(i=0 ; i< nNumOfVow; i++)
	{
		CStdStringA csVow;
		csVow = VoArray.at(i).csCharId;
		//nFound = csSyllable.Find(VoArray.at(i).csCharId,0);
		nFound = csSyllable.Find(csVow,0);

		//if(nFound== -1) bTone = 1;
		//else
		if(nFound !=-1)
		{
			bSyllableLen = csSyllable.GetLength();
			//Vowell No 1
			if(VoArray.at(i).csPhoneId == "M7") // it does exist the Semivowel for middle phone in this case.
			{
				//nucleous phone
				DicSyllable.csSound[2]		= "M7";
				DicSyllable.csSoundType[2]	= VoArray.at(i).csPhoneType;
				DicSyllable.bNumOfSound++;
				
				// For the initial and final phones
				csLeft= csSyllable.Left(nFound);
				bPhoneLen = VoArray.at(i).csCharId.GetLength();
				csRight = csSyllable.Right(bSyllableLen - nFound -bPhoneLen);
				
				// Checking Left Size of the Syllable
				
				if(csLeft.GetLength()>0)
				{
					for(k=0; k<InPhoneArray.size(); k++)
						if(InPhoneArray.at(k).csCharId == csLeft)
						{
							DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
							DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
							DicSyllable.bNumOfSound++;
							break;
						}
					if(k==InPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
				}
				
				// Checking Right Size of the Syllable
				if(csRight.GetLength()>0)
				{
					for(j=0; j< FiPhoneArray.size();j++)
						if(FiPhoneArray.at(j).csCharId == csRight)
						{
							DicSyllable.csSound[3]		= FiPhoneArray.at(j).csPhoneId;
							DicSyllable.csSoundType[3]	= FiPhoneArray.at(j).csPhoneType;
							DicSyllable.bNumOfSound++;
							break;
						}
					if(j==FiPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csRight);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
					
				}
					
				break;
			}
			//Vowell No 2
			if(VoArray.at(i).csPhoneId == "uo")
			{
				//nucleous phone
				DicSyllable.csSound[2]		= "uo";
				DicSyllable.csSoundType[2]	= VoArray.at(i).csPhoneType;
				DicSyllable.bNumOfSound++;
				
				// For the initial and final phones
				csLeft= csSyllable.Left(nFound);
				bPhoneLen = VoArray.at(i).csCharId.GetLength();
				csRight = csSyllable.Right(bSyllableLen - nFound -bPhoneLen);
				
				// Checking Left Size of the Syllable
				if(csLeft.GetLength()>0)
				{
					if((csLeft == "q")&&(VoArray.at(i).csCharId = "ua")) 
					{
						//nucleous phone
						DicSyllable.csSound[2]		= "a";
						DicSyllable.csSoundType[2]	= "VM";
				
						// middle phone
						DicSyllable.csSound[1]		= "w";
						DicSyllable.csSoundType[1]	= "SV";

						// initial phone
						DicSyllable.csSound[0]		= "k";
						DicSyllable.csSoundType[0]	= "CSU";

					}
					else
					{
						for(k=0; k<InPhoneArray.size(); k++)
							if(InPhoneArray.at(k).csCharId == csLeft)
							{
								DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
								DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
								DicSyllable.bNumOfSound++;
								break;
							}

						if(k==InPhoneArray.size())
						{
							CStdStringA csStrOut;
							csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
							//CPsola::OutputLastError(csStrOut);
							return FALSE;
						}
					}
				}
				
				// Checking Right Size of the Syllable
				if(csRight.GetLength()>0)
				{
					
					for(j=0; j< FiPhoneArray.size();j++)
						if(FiPhoneArray.at(j).csCharId == csRight)
						{
							DicSyllable.csSound[3]		= FiPhoneArray.at(j).csPhoneId;
							DicSyllable.csSoundType[3]	= FiPhoneArray.at(j).csPhoneType;
							DicSyllable.bNumOfSound++;
							break;
						}
					if(j==FiPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csRight);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
					
				}
				break;
			}
			//Vowell No 3
			if(VoArray.at(i).csPhoneId == "ie")
			{
				//nucleous phone
				DicSyllable.csSound[2]		= "ie";
				DicSyllable.csSoundType[2]	= VoArray.at(i).csPhoneType;
				DicSyllable.bNumOfSound++;
				
				// For the initial and final phones
				csLeft= csSyllable.Left(nFound);
				bPhoneLen = VoArray.at(i).csCharId.GetLength();
				csRight = csSyllable.Right(bSyllableLen - nFound -bPhoneLen);
				
				// Checking Left Size of the Syllable
				if(csLeft.GetLength()>0)
				{
					if(csLeft == "g") 
					{
						if(VoArray.at(i).csCharId == "ia")
						{
							DicSyllable.csSound[2]		= "NUL";
							DicSyllable.csSoundType[2]	= "NUL";
							continue;
						}
						else
						{
							// initial phone
							DicSyllable.csSound[0]		="z";
							DicSyllable.csSoundType[0]	= "CFV";
						}
					}
					else
					{
						int nMidFound = -1;
					
						nMidFound = csLeft.Find(MiPhoneArray.at(0).csCharId,0);
						if(nMidFound == -1)	nMidFound = csLeft.Find(MiPhoneArray.at(1).csCharId,0);

						if(nMidFound == -1)
						{
							
							for(k=0; k<InPhoneArray.size(); k++)
								if(InPhoneArray.at(k).csCharId == csLeft)
								{
									DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
									DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
									DicSyllable.bNumOfSound++;
									break;
								}

							if(k==InPhoneArray.size())
							{
								CStdStringA csStrOut;
								csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
								//CPsola::OutputLastError(csStrOut);
								return FALSE;
							}
						}
						else
						{
							DicSyllable.csSound[1]		= "w";
							DicSyllable.csSoundType[1]	= "SV";
							DicSyllable.bNumOfSound++;
							csLeft = csLeft.Left(nMidFound);
							if(csLeft.GetLength()>0)
							{
								for(k=0; k<InPhoneArray.size(); k++)
									if(InPhoneArray.at(k).csCharId == csLeft)
									{
										DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
										DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
										DicSyllable.bNumOfSound++;
										break;
									}
								if(k==InPhoneArray.size())
								{
									CStdStringA csStrOut;
									csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
									//CPsola::OutputLastError(csStrOut);
									return FALSE;
								}
							}
						}
					}
				}
			
				// Checking Right Size of the Syllable
				if(csRight.GetLength()>0)
				{
					for(j=0; j< FiPhoneArray.size();j++)
						if(FiPhoneArray.at(j).csCharId == csRight)
						{
							DicSyllable.csSound[3]		= FiPhoneArray.at(j).csPhoneId;
							DicSyllable.csSoundType[3]	= FiPhoneArray.at(j).csPhoneType;
							DicSyllable.bNumOfSound++;
							break;
						}
					if(j==FiPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csRight);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
				}
				break;
			}
			//Vowell No 4, Vowell No 5, Vowell No 6
			if((VoArray.at(i).csPhoneId == "M")||(VoArray.at(i).csPhoneId == "7")||(VoArray.at(i).csPhoneId == "o"))
			{
				// nucleous phone
				DicSyllable.csSound[2]		= VoArray.at(i).csPhoneId; //"M";
				DicSyllable.csSoundType[2]	= VoArray.at(i).csPhoneType;
				DicSyllable.bNumOfSound++;
				
				// For the initial and final phones
				csLeft= csSyllable.Left(nFound);
				bPhoneLen = VoArray.at(i).csCharId.GetLength();
				csRight = csSyllable.Right(bSyllableLen - nFound -bPhoneLen);
				
				// Checking Left Size of the Syllable
				if(csLeft.GetLength()>0)
				{
					for(k=0; k<InPhoneArray.size(); k++)
						if(InPhoneArray.at(k).csCharId == csLeft)
						{
							DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
							DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
							DicSyllable.bNumOfSound++;
							break;
						}
					if(k==InPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
				}

				// Checking Right Size of the Syllable
				if(csRight.GetLength()>0)
				{
					for(j=0; j< FiPhoneArray.size();j++)
						if(FiPhoneArray.at(j).csCharId == csRight)
						{
							DicSyllable.csSound[3]		= FiPhoneArray.at(j).csPhoneId;
							DicSyllable.csSoundType[3]	= FiPhoneArray.at(j).csPhoneType;
							DicSyllable.bNumOfSound++;
							break;
						}
					if(j==FiPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csRight);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
					
				}
				break;
			}
		
			//Vowell No 7, Vowell No 8, Vowell No 9, Vowell No 10
			if((VoArray.at(i).csPhoneId == "e")||(VoArray.at(i).csPhoneId == "E")||(VoArray.at(i).csPhoneId == "7X")||(VoArray.at(i).csPhoneId == "aX"))
			{
				DicSyllable.csSound[2]		= VoArray.at(i).csPhoneId;//"E";
				DicSyllable.csSoundType[2]	= VoArray.at(i).csPhoneType;
				DicSyllable.bNumOfSound++;
				
				// For the initial and final phones
				csLeft= csSyllable.Left(nFound);
				bPhoneLen = VoArray.at(i).csCharId.GetLength();
				csRight = csSyllable.Right(bSyllableLen - nFound -bPhoneLen);
				
				// Checking Left Size of the Syllable
				if(csLeft.GetLength()>0)
				{
					int nMidFound = -1;
					
					nMidFound = csLeft.Find(MiPhoneArray.at(0).csCharId,0);
					if(nMidFound == -1)	nMidFound = csLeft.Find(MiPhoneArray.at(1).csCharId,0);

					if(nMidFound == -1)
					{
						for(k=0; k<InPhoneArray.size(); k++)
							if(InPhoneArray.at(k).csCharId == csLeft)
							{
								DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
								DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
								DicSyllable.bNumOfSound++;
								break;
							}
						if(k==InPhoneArray.size())
						{
							CStdStringA csStrOut;
							csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
							//CPsola::OutputLastError(csStrOut);
							return FALSE;
						}
					}
					else
					{
						DicSyllable.csSound[1]		= "w";
						DicSyllable.csSoundType[1]	= "SV";
						DicSyllable.bNumOfSound++;
						csLeft = csLeft.Left(nMidFound);
						if(csLeft.GetLength()>0)
						{
							for(k=0; k<InPhoneArray.size(); k++)
								if(InPhoneArray.at(k).csCharId == csLeft)
								{
									DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
									DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
									DicSyllable.bNumOfSound++;
									break;
								}
							if(k==InPhoneArray.size())
							{
								CStdStringA csStrOut;
								csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
								//CPsola::OutputLastError(csStrOut);
								return FALSE;
							}
						}
					}
				}
				
				// Checking Right Size of the Syllable

				if(csRight.GetLength()>0)
				{
					for(j=0; j< FiPhoneArray.size();j++)
						if(FiPhoneArray.at(j).csCharId == csRight)
						{
							DicSyllable.csSound[3]		= FiPhoneArray.at(j).csPhoneId;
							DicSyllable.csSoundType[3]	= FiPhoneArray.at(j).csPhoneType;
							DicSyllable.bNumOfSound++;
							break;
						}
					if(j==FiPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csRight);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
				}

				break;
			}

			//Vowell No 11
			if(VoArray.at(i).csPhoneId == "a")
			{
				DicSyllable.csSound[2]		= "a";
				DicSyllable.csSoundType[2]	= VoArray.at(i).csPhoneType;
				DicSyllable.bNumOfSound++;

				// For the initial and final phones
				csLeft= csSyllable.Left(nFound);
				bPhoneLen = VoArray.at(i).csCharId.GetLength();
				csRight = csSyllable.Right(bSyllableLen - nFound -bPhoneLen);
				
				// Checking Left Size of the Syllable
				
				if(csLeft.GetLength()>0)
				{
					int nMidFound = -1;
					
					nMidFound = csLeft.Find(MiPhoneArray.at(0).csCharId,0);
					
					if(nMidFound == -1)	nMidFound = csLeft.Find(MiPhoneArray.at(1).csCharId,0);

					if(nMidFound == -1)
					{
						for(k=0; k<InPhoneArray.size(); k++)
							if(InPhoneArray.at(k).csCharId == csLeft)
							{
								DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
								DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
								DicSyllable.bNumOfSound++;
								break;
							}
						if(k==InPhoneArray.size())
						{
							CStdStringA csStrOut;
							csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
							//CPsola::OutputLastError(csStrOut);
							return FALSE;
						}
					}
					else
					{
						DicSyllable.csSound[1]		= "w";
						DicSyllable.csSoundType[1]	= "SV";
						DicSyllable.bNumOfSound++;
						csLeft = csLeft.Left(nMidFound);
						if(csLeft.GetLength()>0)
						{
							for(k=0; k<InPhoneArray.size(); k++)
								if(InPhoneArray.at(k).csCharId == csLeft)
								{
									DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
									DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
									DicSyllable.bNumOfSound++;
									break;
								}
							if(k==InPhoneArray.size())
							{
								CStdStringA csStrOut;
								csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
								//CPsola::OutputLastError(csStrOut);
								return FALSE;
							}
						}
					}
				}
				// Checking Right Size of the Syllable

				if(csRight.GetLength()>0)
				{
					for(j=0; j< FiPhoneArray.size();j++)
						if(FiPhoneArray.at(j).csCharId == csRight)
						{
							DicSyllable.csSound[3]		= FiPhoneArray.at(j).csPhoneId;
							DicSyllable.csSoundType[3]	= FiPhoneArray.at(j).csPhoneType;
							DicSyllable.bNumOfSound++;
							if((FiPhoneArray.at(j).csCharId == "nh")||(FiPhoneArray.at(j).csCharId == "ch"))
							{
								DicSyllable.csSound[2]		= "EX";
								DicSyllable.csSoundType[2]	= "VFC";
							}
							if((FiPhoneArray.at(j).csCharId =="u")||(FiPhoneArray.at(j).csCharId == "y"))
							{
								DicSyllable.csSound[2]		= "aX";
								DicSyllable.csSoundType[2]	= "VMC";
							}
							break;
						}
					if(j==FiPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csRight);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
				}
				break;
			}
			//Vowell No 12
			if(VoArray.at(i).csPhoneId == "O")
			{
				DicSyllable.csSound[2]		= "O";
				DicSyllable.csSoundType[2]	= VoArray.at(i).csPhoneType;
				DicSyllable.bNumOfSound++;
				
				// For the initial and final phones
				csLeft= csSyllable.Left(nFound);
				bPhoneLen = VoArray.at(i).csCharId.GetLength();
				csRight = csSyllable.Right(bSyllableLen - nFound -bPhoneLen);
				
				// Checking Left Size of the Syllable
				if(csLeft.GetLength()>0)
				{
					for(k=0; k<InPhoneArray.size(); k++)
						if(InPhoneArray.at(k).csCharId == csLeft)
						{
							DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
							DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
							DicSyllable.bNumOfSound++;
							break;
						}
					if(k==InPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
				}
			
				// Checking Right Size of the Syllable
				if(csRight.GetLength()>0)
				{
					for(j=0; j< FiPhoneArray.size();j++)
						if(FiPhoneArray.at(j).csCharId == csRight)
						{
							DicSyllable.csSound[3]		= FiPhoneArray.at(j).csPhoneId;
							DicSyllable.csSoundType[3]	= FiPhoneArray.at(j).csPhoneType;
							DicSyllable.bNumOfSound++;
							if(((DicSyllable.csSound[3] == "NG")||(DicSyllable.csSound[3] == "k"))&&(VoArray.at(i).csCharId!="oo"))
							{
								DicSyllable.csSound[2]		= "OX";
								DicSyllable.csSoundType[2]	= "VBC";
							}
							break;
						}
					if(j==FiPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csRight);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
				}
				break;
			}

			//Vowell No 16
			if(VoArray.at(i).csPhoneId == "u")
			{
				DicSyllable.csSound[2]		= "u";
				DicSyllable.csSoundType[2]	= VoArray.at(i).csPhoneType;
				DicSyllable.bNumOfSound++;

				// For the initial and final phones
				csLeft= csSyllable.Left(nFound);
				bPhoneLen = VoArray.at(i).csCharId.GetLength();
				csRight = csSyllable.Right(bSyllableLen - nFound -bPhoneLen);
				
				// Checking Left Size of the Syllable
				if(csLeft.GetLength()>0)
				{
					
					int nMidFound = -1;
					nMidFound = csLeft.Find("i",0);
					
					if(nMidFound == -1)
					{
						for(k=0; k<InPhoneArray.size(); k++)
							if(InPhoneArray.at(k).csCharId == csLeft)
							{
								DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
								DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
								DicSyllable.bNumOfSound++;
								break;
							}
						if(k==InPhoneArray.size())
						{
							CStdStringA csStrOut;
							csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
							//CPsola::OutputLastError(csStrOut);
							return FALSE;
						}
					}
					else
					{
						csLeft = csLeft.Left(nMidFound);
						if(csLeft.GetLength()>0)
						{
							if(csLeft == "g")
							{
								DicSyllable.csSound[0]		="z";
								DicSyllable.csSoundType[0]	= "CFV";
							}
							else
							{
								DicSyllable.csSound[2]		= "i";
								DicSyllable.csSoundType[2]	= "VF";
														
								for(k=0; k<InPhoneArray.size(); k++)
									if(InPhoneArray.at(k).csCharId == csLeft)
									{
										DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
										DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
										DicSyllable.bNumOfSound++;
										break;
									}
								if(k==InPhoneArray.size())
								{
									CStdStringA csStrOut;
									csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
									//CPsola::OutputLastError(csStrOut);
									return FALSE;
								}

								DicSyllable.csSound[3]		= "w";
								DicSyllable.csSoundType[3]	= "SV";
								DicSyllable.bNumOfSound++;
								return TRUE;
							}
						}
						
					}
				}
				
				// Checking Right Size of the Syllable
				if(csRight.GetLength()>0)
				{
					if(csRight !="y")
					{
						for(j=0; j< FiPhoneArray.size();j++)
							if(FiPhoneArray.at(j).csCharId == csRight)
							{
								DicSyllable.csSound[3]		= FiPhoneArray.at(j).csPhoneId;
								DicSyllable.csSoundType[3]	= FiPhoneArray.at(j).csPhoneType;
								DicSyllable.bNumOfSound++;
								break;
							}
						if(j==FiPhoneArray.size())
						{
							CStdStringA csStrOut;
							csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csRight);
							//CPsola::OutputLastError(csStrOut);
							return FALSE;
						}
					}
					else
					{
						DicSyllable.csSound[1]		= "w";
						DicSyllable.csSoundType[1]	= "SV";
						DicSyllable.bNumOfSound++;

						DicSyllable.csSound[2]		= "i";
						DicSyllable.csSoundType[2]	= "VF";

					}
				}
				break;
			}
			//Vowell No 13
			if(VoArray.at(i).csPhoneId == "i")
			{
				DicSyllable.csSound[2]		= "i";
				DicSyllable.csSoundType[2]	= VoArray.at(i).csPhoneType;
				DicSyllable.bNumOfSound++;

				// For the initial and final phones
				csLeft= csSyllable.Left(nFound);
				bPhoneLen = VoArray.at(i).csCharId.GetLength();
				csRight = csSyllable.Right(bSyllableLen - nFound -bPhoneLen);
				
				// Checking Left Size of the Syllable
				if(csLeft.GetLength()>0)
				{
					if(csLeft == "g") 
					{
						// initial phone
						DicSyllable.csSound[0]		="z";
						DicSyllable.csSoundType[0]	= "CFV";
					}
					else
					{
						for(k=0; k<InPhoneArray.size(); k++)
							if(InPhoneArray.at(k).csCharId == csLeft)
							{
								DicSyllable.csSound[0]		= InPhoneArray.at(k).csPhoneId;
								DicSyllable.csSoundType[0]	= InPhoneArray.at(k).csPhoneType;
								DicSyllable.bNumOfSound++;
								break;
							}
						if(k==InPhoneArray.size())
						{
							CStdStringA csStrOut;
							csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csLeft);
							//CPsola::OutputLastError(csStrOut);
							return FALSE;
						}
					}
				}
				
				// Checking Right Size of the Syllable
				if(csRight.GetLength()>0)
				{
					for(j=0; j< FiPhoneArray.size();j++)
						if(FiPhoneArray.at(j).csCharId == csRight)
						{
							DicSyllable.csSound[3]		= FiPhoneArray.at(j).csPhoneId;
							DicSyllable.csSoundType[3]	= FiPhoneArray.at(j).csPhoneType;
							DicSyllable.bNumOfSound++;
							break;
						}
					if(j==FiPhoneArray.size())
					{
						CStdStringA csStrOut;
						csStrOut.Format("Acoustic unit : %s does not exist in Vietnamese!\n",csRight);
						//CPsola::OutputLastError(csStrOut);
						return FALSE;
					}
					
				}
				break;
			}
			
		}
	}

	return TRUE;

}

/*
	CString	csPhoneId;		// Name of Acoustic Unit
	CString	csPhoneType;	// type of AU
	CString	csCharId;		// Character of AU
	BYTE	ToneId;
*/