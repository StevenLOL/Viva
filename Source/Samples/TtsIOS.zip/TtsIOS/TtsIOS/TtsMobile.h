#ifndef  _TTS_MOBILE_
#define  _TTS_MOBILE_

//#include "cocos2d.h"
#include "stdstring.h"
//using namespace cocos2d;
class TtsMobile
{
public:
	TtsMobile();
	static bool Start(const char* input);
	static void setResourcePath(const char* path);
	static void setParams(float f0_begin,float speakRate);
    static void setF0(float f0);
    static void setSpeakingRate(float spr);
    static void setWavPath(const char* path);
	
private:
		static CStdStringA wavFile;
		static bool dbValid;
};

#endif