#include "TtsMobile.h"
//#include "cocos2d.h"
#include <jni.h>
#include <android/log.h>

#define  LOG_TAG    "main"
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)


//using namespace cocos2d;

#ifdef __cplusplus
extern "C" {
#endif

bool Java_com_mica_ttsandroid_TtsAndroid_nativeStart(JNIEnv*  env, jobject thiz, jstring javaInput)
	{
		bool mRet = false;
		const char *nativeString = env->GetStringUTFChars(javaInput, 0);
		if (TtsMobile::Start(nativeString))
		{
			mRet = true;
		}
		env->ReleaseStringUTFChars(javaInput, nativeString);
		return mRet;
	}
	bool Java_com_mica_ttsandroid_NotificationDialog_nativeStart(JNIEnv*  env, jobject thiz, jstring javaInput)
	{
		bool mRet = false;
		const char *nativeString = env->GetStringUTFChars(javaInput, 0);
		if (TtsMobile::Start(nativeString))
		{
			mRet = true;
		}
		env->ReleaseStringUTFChars(javaInput, nativeString);
		return mRet;
	}
	
	bool Java_com_mica_ttsandroid_ServiceReadSMS_nativeStart(JNIEnv*  env, jobject thiz, jstring javaInput)
	{
		bool mRet = false;
		const char *nativeString = env->GetStringUTFChars(javaInput, 0);
		if (TtsMobile::Start(nativeString))
		{
			mRet = true;
		}
		env->ReleaseStringUTFChars(javaInput, nativeString);
		return mRet;
	}
	
	bool Java_com_mica_ttsandroid_SMSReceiver_nativeStart(JNIEnv*  env, jobject thiz, jstring javaInput)
	{
		bool mRet = false;
		const char *nativeString = env->GetStringUTFChars(javaInput, 0);
		if (TtsMobile::Start(nativeString))
		{
			mRet = true;
		}
		env->ReleaseStringUTFChars(javaInput, nativeString);
		return mRet;
	}
	
	void Java_com_mica_ttsandroid_TtsAndroid_setResourcePath(JNIEnv*  env, jobject thiz, jstring javaPath)
	{
		const char* navtivePath = env->GetStringUTFChars(javaPath, 0);
		TtsMobile::setResourcePath(navtivePath);
		env->ReleaseStringUTFChars(javaPath, navtivePath);
	}
	
	void Java_com_mica_ttsandroid_TtsAndroid_setParams(JNIEnv*  env, jobject thiz, jfloat f0_begin,jfloat speakingRate)
	{
		TtsMobile::setParams(f0_begin,speakingRate);
	}
	


#ifdef __cplusplus
}
#endif

