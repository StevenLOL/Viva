// WaveFile.h: interface for the CWaveFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WAVEFILE_H__7C368708_C056_4AFA_AE8E_3E1382838C70__INCLUDED_)
#define AFX_WAVEFILE_H__7C368708_C056_4AFA_AE8E_3E1382838C70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//#include "Mmsystem.h"
#include "MyConstants.h"

 class CWaveFile      
{
public:
	static BOOL Convert16To8MuLaw(char *lpSrc, char *lpDst, DWORD dwDataSize);
	static BOOL CreateAuFile(AUDIOHEADER &hdr);
	static BOOL AppendToWaveFile(APPENDWAVESTRUCT &stAppWave);
	//friend void CALLBACK waveOutProc(HWAVEOUT hwo,UINT uMsg,DWORD dwInstance,  
	//	DWORD dwParam1, DWORD dwParam2);
	//static BOOL PlayFile(LPCTSTR lpszFileName);
	//static int Stop();
	//static BOOL PlayBuffer(WAVEFORMATEX wofx,LPSTR lpSignal,DWORD dwFrom,DWORD dwLen);
	static BOOL CreateWaveFile(LPCTSTR lpszFileName,UINT uSampleRate,
						WORD wBitsPerSample,
						WORD wNumberChannels,DWORD dwDataSize,
						LPSTR lpChannel1,LPSTR lpChannel2 = NULL);
	void Close();
	BOOL SeparateData(LPSTR m_cSignalChannel1,LPSTR m_cSignalChannel2,DWORD dwCount);
	CStdStringA GetFilePath();
	CStdStringA GetFileName();
	DWORD GetDataSize();
	UINT GetSampleRate();
	WORD GetNumberChannels();
	DWORD GetFileSize();
	WORD GetBitsPerSample();
	static CStdStringA GetLastError(int *ErrorCode = NULL);
	BOOL Attach(LPCTSTR	lpszFileName);
	CWaveFile();
	virtual ~CWaveFile();

protected:
	static BOOL m_hPlay;
	static BOOL m_bOnStopFunction;
	//static WAVEHDR m_whdr;
	//static HWAVEOUT m_hwo;
	//static WAVEFORMATEX m_wfx;
	static char *m_cTempBuffer;
	void UnsignedToSigned(char *m_cSignal,DWORD dwCount);
	char *m_cContent;
	DWORD m_dwDataSize;
	CStdStringA m_csFullPath;
	CStdStringA m_csTitle;
	WORD	m_wBitsPerSample;
	UINT	m_uSampleRate;
	WORD	m_wNumberChannels;
	BOOL	m_bDirty;
	DWORD	m_dwFileSize;
	static	int	m_nFileOpenState;
};

#endif // !defined(AFX_WAVEFILE_H__7C368708_C056_4AFA_AE8E_3E1382838C70__INCLUDED_)
