//
//  ViewController.m
//  TtsIOS
//
//  Created by Lion User on 28/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "ttsIOS.h"
#import "TtsMobile.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize textFieldData;
@synthesize textFieldF0;
@synthesize textFieldSpR;
@synthesize btnStart;
@synthesize slider;
@synthesize f0Slide;
@synthesize steper;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    TtsIOS t = TtsIOS();
    NSString * path = [[NSBundle mainBundle] resourcePath];
    
    

    TtsMobile::setParams(210, 1.2f);
    TtsMobile::setResourcePath([path UTF8String]);
    
    [textFieldSpR setText:[NSString stringWithFormat:@"%3.2f",slider.value]];
    [textFieldF0 setText:[NSString stringWithFormat:@"%3.2f",f0Slide.value]];
    
    //[slider setValue:210];
    //[self removeData];
    
}
- (void) removeData
{
    
    NSArray *ars = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask , YES);
    NSString *documentDir = [ars objectAtIndex:0];
    
    NSFileManager *fileMan = [[[NSFileManager alloc] init] autorelease];
    NSError *error = nil;
    NSArray *docContents = [fileMan contentsOfDirectoryAtPath:documentDir error:&error];
    for (NSString *file in docContents){
        NSString *fullPath = [NSString stringWithFormat:@"%@%@%@", documentDir, @"/",file];
        [fileMan removeItemAtPath:fullPath error:&error];
    }

}
- (void)viewDidUnload
{
    [self setTextFieldData:nil];
    [self setTextFieldF0:nil];
    [self setTextFieldSpR:nil];
    [self setBtnStart:nil];
    [self setSlider:nil];
    [self setSteper:nil];
    [self setF0Slide:nil];
    [super viewDidUnload];
    //[self removeData];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (void)dealloc {
    [textFieldData release];
    [textFieldF0 release];
    [textFieldSpR release];
    [btnStart release];
    [slider release];
    [steper release];
    [f0Slide release];
    [super dealloc];
}
- (IBAction)btnStartPerform:(id)sender {
    
    NSString *userInput = textFieldData.text;
    if (userInput.length > 0)
    {
        
        NSArray *ars = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask , YES);
        NSString *documentDir = [ars objectAtIndex:0];

 
        NSString *path = [NSString stringWithFormat:@"%@%@%@%@", documentDir, @"/",userInput,@".wav"];
        
        NSLog(@"path to wav file=%@",path);
        TtsMobile::setWavPath([path UTF8String]);
        if (TtsMobile::Start([userInput UTF8String]))
        {
            
            SystemSoundID soundID;
      
          
            
            NSURL *filePath = [NSURL fileURLWithPath:path isDirectory:NO];
            AudioServicesCreateSystemSoundID((CFURLRef)filePath, &soundID);
       
            
            AudioServicesPlaySystemSound(soundID); 
            //[self removeData];
         
        }
    }
    
}

- (IBAction)f0submit:(id)sender {
    float f0 = [textFieldF0.text floatValue];
    if ((f0>150 ) && (f0 <250))
    {
        TtsMobile::setF0(f0);
        [f0Slide setValue:f0];
        if ([textFieldF0 isFirstResponder])
        {
            [textFieldF0 resignFirstResponder];
        }

    }
}

- (IBAction)sprSubmit:(id)sender {
    float spr = [textFieldSpR.text floatValue];
    if ((spr>0 ) && (spr<2))
    {
        TtsMobile::setSpeakingRate(spr);
        [slider setValue:spr];
        if ([textFieldSpR isFirstResponder])
        {
            [textFieldSpR resignFirstResponder];
        }
    }

}

- (IBAction)btnStartdown:(id)sender {
    if ([textFieldData isFirstResponder])
    {
        [textFieldData resignFirstResponder];
    }
}

- (IBAction)onSlide:(id)sender {
    //NSLog(@"%3.1f",slider.value);
    [textFieldSpR setText:[NSString stringWithFormat:@"%3.2f",slider.value]];
    TtsMobile::setSpeakingRate(slider.value);
}

- (IBAction)onF0Change:(id)sender {
    //NSLog(@"%3.1f",f0Slide.value);
    [textFieldF0 setText:[NSString stringWithFormat:@"%3.2f",f0Slide.value]];
    TtsMobile::setF0(f0Slide.value);
}

@end
